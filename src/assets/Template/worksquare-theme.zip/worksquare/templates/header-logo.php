<?php
/**
 * Header / Logo
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define vars
$logo_size = '';
$logo_url = home_url( '/' );
$logo_title = get_bloginfo( 'name' );

// Get header style from Customizer and Metabox
$header_style = worksquare_get_mod( 'header_site_style', 'style-1' );
if ( is_page() && worksquare_metabox('header_style') )
	$header_style = worksquare_metabox('header_style');

// Get logos base on header styles
switch ( $header_style ) {
    case "style-2":
		$logo_img = worksquare_get_mod( 'custom_logotwo' );
		$logo_width = worksquare_get_mod( 'logotwo_width' );
        break;
    case "style-3":
		$logo_img = worksquare_get_mod( 'custom_logothree' );
		$logo_width = worksquare_get_mod( 'logothree_width' );
        break;
    default:
		$logo_img = worksquare_get_mod( 'custom_logo' );
		$logo_width = worksquare_get_mod( 'logo_width' );
}

// if page has custom logo
if ( is_page() && $custom_logo = worksquare_metabox('custom_header_logo') ) {
	$logo_img = $custom_logo['full_url'];
	$logo_width = worksquare_metabox('header_logo_width');
}

if ( $logo_width ) $logo_size .= 'max-width:'. intval( $logo_width ) .'px;';
?>

<div id="site-logo">
	<div id="site-logo-inner" style="<?php echo esc_attr( $logo_size ); ?>">
		<?php if ( $logo_img ) : ?>
			<a class="main-logo" href="<?php echo esc_url( $logo_url ); ?>" title="<?php echo esc_attr( $logo_title ); ?>" rel="home" ><img src="<?php echo esc_url( $logo_img ); ?>" alt="<?php echo esc_attr( $logo_title ); ?>" /></a>
		<?php else : ?>
			<a class="site-logo-text" href="<?php echo esc_url( $logo_url ); ?>" title="<?php echo esc_attr( $logo_title ); ?>" rel="home"><?php echo esc_html( $logo_title ); ?></a>
		<?php endif; ?>
	</div>
</div><!-- #site-logo -->
