<?php
/**
 * Header
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$topbar_css = '';
$topbar = worksquare_get_mod( 'topbar' );
$topbar_height = worksquare_get_mod( 'topbar_height' );
$topbar_color = worksquare_get_mod( 'topbar_color' );
$topbar_divider = worksquare_get_mod( 'topbar_divider' );
$topbar_divider_color = worksquare_get_mod( 'topbar_divider_color' );

// Override by metabox
if ( worksquare_metabox( 'topbar_background' ) ) $topbar_color = worksquare_metabox( 'topbar_background' );


if ( $topbar_height ) $topbar_css .= 'height:'. intval( $topbar_height ) .'px;';
if ( $topbar_color ) $topbar_css .= 'background-color:'. $topbar_color  .';';

if ( $topbar_divider_color ) $topbar_css .= 'border-bottom-color:'. $topbar_divider_color .';';

if ( $topbar && ! worksquare_metabox( 'hide_topbar' ) ) :
?>
	<div id="topbar" <?php if ( $topbar_css ) echo 'style="'. esc_attr( $topbar_css ) .'"'; ?>>
		<div class="topbar-inner worksquare-container clearfix">
			<div class="topbar-left">
				<?php get_template_part( 'templates/topbar-link'); ?>
			</div>

			<div class="topbar-right">
				<?php get_template_part( 'templates/topbar-social'); ?>
			</div>			
		</div><!-- /.topbar-inner -->
	</div><!-- /#topbar -->
<?php endif; ?>