<?php 

$title = $desc = $bg = $css ='';
$title = worksquare_get_mod('footer_newsletter_title');
$desc = worksquare_get_mod('footer_newsletter_desc');
$bg = worksquare_get_mod('footer_newsletter_bg', null);

if ( $bg ) $css .= 'background-image: url(' . esc_url( $bg ) .');';
?>

<div class="newsletter-box clearfix" style="<?php echo esc_html($css); ?>">
	<div class="content">
		<h3 class="title wow fadeInDown" data-wow-delay="0.3s"><?php echo esc_html($title); ?></h3>
	</div>
	<div class="newsletter-form wow fadeInUp" data-wow-delay="0.6s">
		<?php echo do_shortcode('[mc4wp_form id="111"]'); ?>
	</div>
	<div class="desc wow fadeInUp" data-wow-delay="1s"><?php echo esc_html($desc); ?></div>
</div>