<?php
/**
 * Header / Button
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Get defaults from Customizer
$css = $cls = $button_wrap_css = '';

$text = worksquare_get_mod( 'header_button_text', '' );
$url = worksquare_get_mod( 'header_button_url', '' );

$button_cls = worksquare_get_mod( 'header_button_class', '' );
$button_font_size = worksquare_get_mod( 'header_button_font_size', '' );
$button_line_height = worksquare_get_mod( 'header_button_line_height', '' );
$button_padding = worksquare_get_mod( 'header_button_padding', '' );
$button_margin = worksquare_get_mod( 'header_button_margin', '' );

// Override option by metabox
if ( worksquare_metabox( 'header_button_color') ) {
	// Accent Color is Default
	if ( worksquare_metabox( 'header_button_color') != 'accent-color' ) $cls .= worksquare_metabox( 'header_button_color');
} else {
	if ( $button_cls ) $cls .= ' '. $button_cls;
	if ( $button_margin ) $button_wrap_css .= 'margin:'. $button_margin .';';
	if ( $button_font_size ) $css .= 'font-size:'. intval( $button_font_size ) .'px;';
	if ( $button_line_height ) $css .= 'line-height:'. intval( $button_line_height ) .'px;';
	if ( $button_padding ) $css .= 'padding:'. $button_padding .';';
}

if ( $text && $url ) : ?>
	<div class="header-button<?php if ( $cls ) echo esc_html( $cls ); ?>" 
		<?php if ( $button_wrap_css ) echo 'style="'. esc_attr( $button_wrap_css ) .'"'; ?>>
	    <?php
	    if ( $text && $url ) : ?>
	        <a href="<?php echo esc_url( do_shortcode( $url ) ); ?>" <?php if ( $css ) echo 'style="'. esc_attr( $css ) .'"'; ?>><span><?php echo do_shortcode( $text ); ?></span></a>
	    <?php endif; ?>
	</div><!-- /.header-info -->
<?php endif; ?>