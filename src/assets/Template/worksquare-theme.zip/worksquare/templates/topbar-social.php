<?php
/**
 * Header / Social
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$css = $cls = '';
$social_style = worksquare_get_mod( 'topbar_socials_style', '' );
$social_margin = worksquare_get_mod( 'topbar_socials_margin', '' );

if ( $social_style ) $cls .= ' '. $social_style;
if ( $social_margin ) $css .= 'margin:'. $social_margin .';';

if ( worksquare_get_mod( 'topbar_socials', false ) ) { ?>
	<div class="topbar-socials <?php echo esc_html( $cls ); ?>" <?php if ( $css ) echo ' style="'. esc_attr( $css ) .'"'; ?>>
		<div class="topbar-socials-inner">
	    <?php
	    $profiles =  worksquare_get_mod( 'topbar_social_profiles' );
	    $social_options = worksquare_topbar_social_options();

	    foreach ( $social_options as $key => $val ) :
	        $url = isset( $profiles[$key] ) ? $profiles[$key] : '';

	        if ( $url ) :
	            echo '<a href="'. esc_url( $url ) .'" title="'. esc_attr( $val['label'] ) .'"><span class="'. esc_attr( $val['icon_class'] ) .'" aria-hidden="true"></span><span class="screen-reader-text">'. $val['label'] .' '. esc_html__( 'Profile', 'worksquare' ) .'</span></a>';
	        endif;
	    endforeach; ?>
		</div>
	</div><!-- /.topbar-socials -->
<?php }