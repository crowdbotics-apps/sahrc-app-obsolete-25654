<?php
/**
 * Bottom Bar
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Exit if disabled via Customizer
if ( ! worksquare_get_mod( 'bottom_bar', true ) ) return false;

// Default
$copyright = esc_html( 'Worksquare - Creative Multipurpose WordPress Theme.', 'worksquare' );
if ( worksquare_get_mod( 'bottom_copyright' ) )
    $copyright = worksquare_get_mod( 'bottom_copyright' );

$css = worksquare_element_bg_css('bottom_background_img');
$bottom_style = worksquare_get_mod( 'bottom_bar_style', 'style-1' ); 
if ( is_page() && $bottom_bg = worksquare_metabox('bottom_bg') )
    $css .= 'background-color:'. $bottom_bg .';';
?>

<div id="bottom" class="<?php echo worksquare_element_classes( 'bottom_bar_style' ); ?>" style="<?php echo esc_attr( $css ); ?>">
    <div class="worksquare-container">
        <div class="bottom-bar-inner-wrap">
            <div class="bottom-bar-copyright clearfix">
                <?php
                if ( $copyright ) : ?>
                    <div id="copyright">
                        <?php printf( '%s', do_shortcode( $copyright ) ); ?>
                    </div>
                <?php endif; ?>

                <?php get_template_part( 'templates/bottom-nav' ); ?>
            </div><!-- /.bottom-bar-copyright -->
        </div>
    </div>
</div><!-- /#bottom -->