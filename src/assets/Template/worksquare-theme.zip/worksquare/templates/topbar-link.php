<?php
/**
 * Topbar / Link
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Get defaults from Customizer

$text_one = worksquare_get_mod( 'topbar_link_text_one', '' );
$url_one = worksquare_get_mod( 'topbar_link_url_one', '' );

$text_two = worksquare_get_mod( 'topbar_link_text_two', '' );
$url_two = worksquare_get_mod( 'topbar_link_url_two', '' );

$text_three = worksquare_get_mod( 'topbar_link_text_three', '' );
$url_three = worksquare_get_mod( 'topbar_link_url_three', '' );
?>

<div class="topbar-link">
	<?php
	if ( $text_one && $url_one  ) : ?>
        <a href="<?php echo esc_url( do_shortcode( $url_one ) ); ?>"><span><?php echo do_shortcode( $text_one ); ?></span></a>
    <?php endif;

    if ( $text_two && $url_two ) : ?>
        <a href="<?php echo esc_url( do_shortcode( $url_two ) ); ?>"><span><?php echo do_shortcode( $text_two ); ?></span></a>
    <?php endif;

	if ( $text_three && $url_three ) : ?>
        <a href="<?php echo esc_url( do_shortcode( $url_three ) ); ?>"><span><?php echo do_shortcode( $text_three ); ?></span></a>
    <?php endif; ?>
</div><!-- /.topbar-link -->
