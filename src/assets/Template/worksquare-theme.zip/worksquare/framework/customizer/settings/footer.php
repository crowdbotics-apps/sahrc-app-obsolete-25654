<?php
/**
 * Footer setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Footer General
$this->sections['worksquare_footer_general'] = array(
	'title' => esc_html__( 'General', 'worksquare' ),
	'panel' => 'worksquare_footer',
	'settings' => array(
		array(
			'id' => 'footer_style',
			'default' => 'style-1',
			'control' => array(
				'label' => esc_html__( 'Footer Style', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'style-1' => 'Style 1',
					'style-2' => 'Style 2',
					'style-3' => 'Style 3',
				),
			),
		),
		array(
			'id' => 'footer_newsletter_title',
			'control' => array(
				'label' => esc_html__( 'Newsletter Title', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_footer_three',
			),
		),
		array(
			'id' => 'footer_newsletter_desc',
			'control' => array(
				'label' => esc_html__( 'Newsletter Description', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_footer_three',
			),
		),
		array(
			'id' => 'footer_newsletter_bg',
			'control' => array(
				'label' => esc_html__( 'Newsletter Background', 'worksquare' ),
				'type' => 'image',
				'active_callback' => 'worksquare_cac_has_footer_three',
			),
		),
		array(
			'id' => 'footer_columns',
			'default' => '4',
			'control' => array(
				'label' => esc_html__( 'Footer Column(s)', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'5' => '2-1-1-1-2',
					'4' => '3-3-3-3',
					'3' => '4-4-4',
					'2' => '6-6',
					'1' => '12',
				),
			),
		),
		array(
			'id' => 'footer_column_gutter',
			'default' => '30',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Footer Column Gutter', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'5'    => '5px',
					'10'   => '10px',
					'15'   => '15px',
					'20'   => '20px',
					'25'   => '25px',
					'30'   => '30px',
					'35'   => '35px',
					'40'   => '40px',
					'45'   => '45px',
					'50'   => '50px',
					'60'   => '60px',
					'70'   => '70px',
					'80'   => '80px',
				),
				'active_callback' => 'worksquare_cac_has_footer_simple',
			),
		),
		array(
			'id' => 'footer_text_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Text Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '#footer-widgets .widget',
				'alter' => 'color',
			),
		),
		array(
			'id' => 'footer_background',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Background Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '#footer',
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'footer_bg_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Background Image', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '#footer',
				'alter' => 'background-image',
			),
		),
		array(
			'id' => 'footer_bg_img_style',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Background Image Style', 'worksquare' ),
				'type'  => 'image',
				'type'  => 'select',
				'choices' => array(
					''             => esc_html__( 'Default', 'worksquare' ),
					'cover'        => esc_html__( 'Cover', 'worksquare' ),
					'center-top'        => esc_html__( 'Center Top', 'worksquare' ),
					'fixed-top'    => esc_html__( 'Fixed Top', 'worksquare' ),
					'fixed'        => esc_html__( 'Fixed Center', 'worksquare' ),
					'fixed-bottom' => esc_html__( 'Fixed Bottom', 'worksquare' ),
					'repeat'       => esc_html__( 'Repeat', 'worksquare' ),
					'repeat-x'     => esc_html__( 'Repeat-x', 'worksquare' ),
					'repeat-y'     => esc_html__( 'Repeat-y', 'worksquare' ),
				),
			),
				'inline_css' => array(
				'target' => '#footer',
				'alter' => 'background',
			),
		),
		array(
			'id' => 'footer_top_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Top Padding', 'worksquare' ),
				'description' => esc_html__( 'Example: 60px.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '#footer',
				'alter' => 'padding-top',
			),
		),
		array(
			'id' => 'footer_bottom_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Bottom Padding', 'worksquare' ),
				'description' => esc_html__( 'Example: 60px.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '#footer',
				'alter' => 'padding-bottom',
			),
		),
	),
);