<?php
/**
 * Header setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Header General
$this->sections['worksquare_header_general'] = array(
	'title' => esc_html__( 'General', 'worksquare' ),
	'panel' => 'worksquare_header',
	'settings' => array(
		// Header 1 - Basic
		array(
			'id' => 'header_background',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_one',
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-1 #site-header:after'
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'header_background_opacity',
			'transport' => 'postMessage',
			'default' => '1',
			'control' => array(
				'label'  => esc_html__( 'Background Opacity', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_one',
				'type' => 'select',
				'choices' => array(
					'1' => esc_html__( '1', 'worksquare' ),
					'0.9' => esc_html__( '0.9', 'worksquare' ),
					'0.8' => esc_html__( '0.8', 'worksquare' ),
					'0.7' => esc_html__( '0.7', 'worksquare' ),
					'0.6' => esc_html__( '0.6', 'worksquare' ),
					'0.5' => esc_html__( '0.5', 'worksquare' ),
					'0.4' => esc_html__( '0.4', 'worksquare' ),
					'0.3' => esc_html__( '0.3', 'worksquare' ),
					'0.2' => esc_html__( '0.2', 'worksquare' ),
					'0.1' => esc_html__( '0.1', 'worksquare' ),
					'0.0001' => esc_html__( '0', 'worksquare' ),
				),
			),
			'inline_css' => array(
				'target' => '.header-style-1 #site-header:after',
				'alter' => 'opacity',
			),
		),
		array(
			'id' => 'header_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_one',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 1199px)',
				'target' => '.header-style-1 .site-header-inner',
				'alter' => 'padding',
			),
			'sanitize_callback' => 'esc_url',
		),
		// Header 2
		array(
			'id' => 'header_two_background',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_two',
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-2 #site-header'
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'header_two_background_opacity',
			'transport' => 'postMessage',
			'default' => '1',
			'control' => array(
				'label'  => esc_html__( 'Background Opacity', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_two',
				'type' => 'select',
				'choices' => array(
					'1' => esc_html__( '1', 'worksquare' ),
					'0.9' => esc_html__( '0.9', 'worksquare' ),
					'0.8' => esc_html__( '0.8', 'worksquare' ),
					'0.7' => esc_html__( '0.7', 'worksquare' ),
					'0.6' => esc_html__( '0.6', 'worksquare' ),
					'0.5' => esc_html__( '0.5', 'worksquare' ),
					'0.4' => esc_html__( '0.4', 'worksquare' ),
					'0.3' => esc_html__( '0.3', 'worksquare' ),
					'0.2' => esc_html__( '0.2', 'worksquare' ),
					'0.1' => esc_html__( '0.1', 'worksquare' ),
					'0.0001' => esc_html__( '0', 'worksquare' ),
				),
			),
			'inline_css' => array(
				'target' => '.header-style-2 #site-header:after',
				'alter' => 'opacity',
			),
		),
		array(
			'id' => 'header_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_two',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 1199px)',
				'target' => '.header-style-2 .site-header-inner',
				'alter' => 'padding',
			),
			'sanitize_callback' => 'esc_url',
		),
		// Header 3
		array(
			'id' => 'header_three_background',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_three',
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-3 #site-header'
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'header_three_background_opacity',
			'transport' => 'postMessage',
			'default' => '1',
			'control' => array(
				'label'  => esc_html__( 'Background Opacity', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_three',
				'type' => 'select',
				'choices' => array(
					'1' => esc_html__( '1', 'worksquare' ),
					'0.9' => esc_html__( '0.9', 'worksquare' ),
					'0.8' => esc_html__( '0.8', 'worksquare' ),
					'0.7' => esc_html__( '0.7', 'worksquare' ),
					'0.6' => esc_html__( '0.6', 'worksquare' ),
					'0.5' => esc_html__( '0.5', 'worksquare' ),
					'0.4' => esc_html__( '0.4', 'worksquare' ),
					'0.3' => esc_html__( '0.3', 'worksquare' ),
					'0.2' => esc_html__( '0.2', 'worksquare' ),
					'0.1' => esc_html__( '0.1', 'worksquare' ),
					'0.0001' => esc_html__( '0', 'worksquare' ),
				),
			),
			'inline_css' => array(
				'target' => '.header-style-3 #site-header:after',
				'alter' => 'opacity',
			),
		),
		array(
			'id' => 'header_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_three',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 1199px)',
				'target' => '.header-style-3 .site-header-inner',
				'alter' => 'padding',
			),
			'sanitize_callback' => 'esc_url',
		),
		// Header 4
		array(
			'id' => 'header_four_background',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_four',
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-4 #site-header'
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'header_four_background_opacity',
			'transport' => 'postMessage',
			'default' => '1',
			'control' => array(
				'label'  => esc_html__( 'Background Opacity', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_four',
				'type' => 'select',
				'choices' => array(
					'1' => esc_html__( '1', 'worksquare' ),
					'0.9' => esc_html__( '0.9', 'worksquare' ),
					'0.8' => esc_html__( '0.8', 'worksquare' ),
					'0.7' => esc_html__( '0.7', 'worksquare' ),
					'0.6' => esc_html__( '0.6', 'worksquare' ),
					'0.5' => esc_html__( '0.5', 'worksquare' ),
					'0.4' => esc_html__( '0.4', 'worksquare' ),
					'0.3' => esc_html__( '0.3', 'worksquare' ),
					'0.2' => esc_html__( '0.2', 'worksquare' ),
					'0.1' => esc_html__( '0.1', 'worksquare' ),
					'0.0001' => esc_html__( '0', 'worksquare' ),
				),
			),
			'inline_css' => array(
				'target' => '.header-style-4 #site-header:after',
				'alter' => 'opacity',
			),
		),
		array(
			'id' => 'header_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_four',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 1199px)',
				'target' => '.header-style-4 .site-header-inner',
				'alter' => 'padding',
			),
			'sanitize_callback' => 'esc_url',
		),
		// Header 5
		array(
			'id' => 'header_five_background',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_five',
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-5 #site-header'
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'header_three_background_opacity',
			'transport' => 'postMessage',
			'default' => '1',
			'control' => array(
				'label'  => esc_html__( 'Background Opacity', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_five',
				'type' => 'select',
				'choices' => array(
					'1' => esc_html__( '1', 'worksquare' ),
					'0.9' => esc_html__( '0.9', 'worksquare' ),
					'0.8' => esc_html__( '0.8', 'worksquare' ),
					'0.7' => esc_html__( '0.7', 'worksquare' ),
					'0.6' => esc_html__( '0.6', 'worksquare' ),
					'0.5' => esc_html__( '0.5', 'worksquare' ),
					'0.4' => esc_html__( '0.4', 'worksquare' ),
					'0.3' => esc_html__( '0.3', 'worksquare' ),
					'0.2' => esc_html__( '0.2', 'worksquare' ),
					'0.1' => esc_html__( '0.1', 'worksquare' ),
					'0.0001' => esc_html__( '0', 'worksquare' ),
				),
			),
			'inline_css' => array(
				'target' => '.header-style-5 #site-header:after',
				'alter' => 'opacity',
			),
		),
		array(
			'id' => 'header_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_five',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 1199px)',
				'target' => '.header-style-5 .site-header-inner',
				'alter' => 'padding',
			),
			'sanitize_callback' => 'esc_url',
		),
		// Header 6
		array(
			'id' => 'header_six_background',
			'transport' => 'postMessage',
			'control' => array(
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_six',
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-6 #site-header'
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'header_six_background_opacity',
			'transport' => 'postMessage',
			'default' => '1',
			'control' => array(
				'label'  => esc_html__( 'Background Opacity', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_six',
				'type' => 'select',
				'choices' => array(
					'1' => esc_html__( '1', 'worksquare' ),
					'0.9' => esc_html__( '0.9', 'worksquare' ),
					'0.8' => esc_html__( '0.8', 'worksquare' ),
					'0.7' => esc_html__( '0.7', 'worksquare' ),
					'0.6' => esc_html__( '0.6', 'worksquare' ),
					'0.5' => esc_html__( '0.5', 'worksquare' ),
					'0.4' => esc_html__( '0.4', 'worksquare' ),
					'0.3' => esc_html__( '0.3', 'worksquare' ),
					'0.2' => esc_html__( '0.2', 'worksquare' ),
					'0.1' => esc_html__( '0.1', 'worksquare' ),
					'0.0001' => esc_html__( '0', 'worksquare' ),
				),
			),
			'inline_css' => array(
				'target' => '.header-style-6 #site-header:after',
				'alter' => 'opacity',
			),
		),
		array(
			'id' => 'header_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_six',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 1199px)',
				'target' => '.header-style-6 .site-header-inner',
				'alter' => 'padding',
			),
			'sanitize_callback' => 'esc_url',
		),
	)
);

// Header Logo
$this->sections['worksquare_header_logo'] = array(
	'title' => esc_html__( 'Logo', 'worksquare' ),
	'panel' => 'worksquare_header',
	'settings' => array(
		// Logo 1
		array(
			'id' => 'logo_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Logo Margin', 'worksquare' ),
		 		'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
		 		'active_callback' => 'worksquare_cac_has_header_one',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 992px)',
				'target' => '.header-style-1 #site-logo-inner',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'custom_logo',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'worksquare' ),
				'type' => 'image',
				'active_callback' => 'worksquare_cac_has_header_one',
			),
		),
		array(
			'id' => 'logo_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_header_one',
			),
		),
		// Logo 2
		array(
			'id' => 'logotwo_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Logo Margin', 'worksquare' ),
		 		'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
		 		'active_callback' => 'worksquare_cac_has_header_two',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 992px)',
				'target' => '.header-style-2 #site-logo-inner',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'custom_logotwo',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'worksquare' ),
				'type' => 'image',
				'active_callback' => 'worksquare_cac_has_header_two',
			),
		),
		array(
			'id' => 'logotwo_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_header_two',
			),
		),
		// Logo 3
		array(
			'id' => 'logothree_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Logo Margin', 'worksquare' ),
		 		'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
		 		'active_callback' => 'worksquare_cac_has_header_three',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 992px)',
				'target' => '.header-style-3 #site-logo-inner',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'custom_logothree',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'worksquare' ),
				'type' => 'image',
				'active_callback' => 'worksquare_cac_has_header_three',
			),
		),
		array(
			'id' => 'logothree_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_header_three',
			),
		),
		// Logo 4
		array(
			'id' => 'logofour_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Logo Margin', 'worksquare' ),
		 		'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
		 		'active_callback' => 'worksquare_cac_has_header_four',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 992px)',
				'target' => '.header-style-4 #site-logo-inner',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'custom_logofour',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'worksquare' ),
				'type' => 'image',
				'active_callback' => 'worksquare_cac_has_header_four',
			),
		),
		array(
			'id' => 'logofour_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_header_four',
			),
		),
		// Logo 5
		array(
			'id' => 'logofive_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Logo Margin', 'worksquare' ),
		 		'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
		 		'active_callback' => 'worksquare_cac_has_header_five',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 992px)',
				'target' => '.header-style-5 #site-logo-inner',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'custom_logofive',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'worksquare' ),
				'type' => 'image',
				'active_callback' => 'worksquare_cac_has_header_five',
			),
		),
		array(
			'id' => 'logofive_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_header_five',
			),
		),
		// Logo 6
		array(
			'id' => 'logosix_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Logo Margin', 'worksquare' ),
		 		'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
		 		'active_callback' => 'worksquare_cac_has_header_six',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 992px)',
				'target' => '.header-style-6 #site-logo-inner',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'custom_logosix',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Logo Image', 'worksquare' ),
				'type' => 'image',
				'active_callback' => 'worksquare_cac_has_header_six',
			),
		),
		array(
			'id' => 'logosix_width',
			'control' => array(
				'label' => esc_html__( 'Logo Width', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_header_six',
			),
		),
	)
);

// Header Menu
$this->sections['worksquare_header_menu'] = array(
	'title' => esc_html__( 'Menu', 'worksquare' ),
	'panel' => 'worksquare_header',
	'settings' => array(
		// General
		array(
			'id' => 'menu_link_spacing',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Link Spacing', 'worksquare' ),
				'description' => esc_html__( 'Example: 20px', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'#main-nav > ul > li',
				),
				'alter' => array(
					'padding-left',
					'padding-right',
				),
			),
		),
		array(
			'id' => 'menu_height',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Menu Height', 'worksquare' ),
				'description' => esc_html__( 'Example: 100px', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'#site-header #main-nav > ul > li > a',
				),
				'alter' => array(
					'height',
					'line-height',
				),
			),
		),
		// Header 1
		array(
			'id' => 'menu_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_one',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-1 #main-nav > ul > li > a',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'menu_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_one',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-1 #main-nav > ul > li > a:hover',
				),
				'alter' => 'color',
			),
		),
		// Header 2
		array(
			'id' => 'menu_two_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_two',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-2 #main-nav > ul > li > a',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'menu_two_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_two',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-2 #main-nav > ul > li > a:hover',
				),
				'alter' => 'color',
			),
		),
		// Header 3
		array(
			'id' => 'menu_three_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_three',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-3 #main-nav > ul > li > a',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'menu_three_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_three',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-3 #main-nav > ul > li > a:hover',
				),
				'alter' => 'color',
			),
		),
		// Header 4
		array(
			'id' => 'menu_four_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_four',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-4 #main-nav > ul > li > a',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'menu_four_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_four',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-4 #main-nav > ul > li > a:hover',
				),
				'alter' => 'color',
			),
		),
		// Header 5
		array(
			'id' => 'menu_five_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_five',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-5 #main-nav > ul > li > a',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'menu_five_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_five',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-5 #main-nav > ul > li > a:hover',
				),
				'alter' => 'color',
			),
		),
		// Header 5
		array(
			'id' => 'menu_six_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_six',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-6 #main-nav > ul > li > a',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'menu_six_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_header_six',
			),
			'inline_css' => array(
				'target' => array(
					'.header-style-6 #main-nav > ul > li > a:hover',
				),
				'alter' => 'color',
			),
		),
	)
);

// Search & Cart
$this->sections['worksquare_header_search_cart'] = array(
	'title' => esc_html__( 'Search & Cart', 'worksquare' ),
	'panel' => 'worksquare_header',
	'settings' => array(
		// Search Icon
		array(
			'id' => 'header_search_icon',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Search Icon', 'worksquare' ),
				'type' => 'checkbox',
			),
		),
		// Cart Icon
		array(
			'id' => 'header_cart_icon',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Cart Icon', 'worksquare' ),
				'type' => 'checkbox',
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
	)
);

// Header Button
$this->sections['worksquare_header_button'] = array(
	'title' => esc_html__( 'Header Button', 'worksquare' ),
	'panel' => 'worksquare_header',
	'settings' => array(
		array(
			'id' => 'header_button_text',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Text', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'header_button_url',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Url', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'header_button_font_size',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Font Size', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'header_button_line_height',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Line Height', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'header_button_padding',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Button Padding', 'worksquare' ),
				'type' => 'text',
				'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
			),
		),
		array(
			'id' => 'header_button_margin',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Button Margin', 'worksquare' ),
				'type' => 'text',
				'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
			),
		),
		array(
			'id' => 'header_button_extra',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Extra Class', 'worksquare' ),
				'type' => 'text',
			),
		),
	),
);

// Socials
$this->sections['worksquare_header_socials'] = array(
	'title' => esc_html__( 'Social', 'worksquare' ),
	'panel' => 'worksquare_header',
	'settings' => array(
		array(
			'id' => 'header_socials',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
			),
		),
	),
);

// Social settings
$social_options = worksquare_header_social_options();
foreach ( $social_options as $key => $val ) {
	$this->sections['worksquare_header_socials']['settings'][] = array(
		'id' => 'header_social_profiles[' . $key .']',
		'control' => array(
			'label' => $val['label'],
			'type' => 'text',
			'active_callback' => 'worksquare_cac_has_header_socials',
		),
	);
}

// Remove var from memory
unset( $social_options );
