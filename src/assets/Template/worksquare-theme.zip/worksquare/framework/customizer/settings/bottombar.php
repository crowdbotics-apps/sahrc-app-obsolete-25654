<?php
/**
 * Bottom Bar setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Bottom Bar General
$this->sections['worksquare_bottombar_general'] = array(
	'title' => esc_html__( 'General', 'worksquare' ),
	'panel' => 'worksquare_bottombar',
	'settings' => array(
		array(
			'id' => 'bottom_bar',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
			),
		),

		array(
			'id' => 'bottom_bar_style',
			'default' => 'style-1',
			'control' => array(
				'label' => esc_html__( 'Style', 'worksquare' ),
				'type' => 'select',
				'active_callback' => 'worksquare_cac_has_bottombar',
				'choices' => array(
					'style-1' => esc_html__( 'Default', 'worksquare' ),
					'style-2' => esc_html__( 'Centered', 'worksquare' ),
				),
			),
		),
		array(
			'id' => 'bottom_copyright',
			'transport' => 'postMessage',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Copyright', 'worksquare' ),
				'type' => 'worksquare_textarea',
				'active_callback' => 'worksquare_cac_has_bottombar',
			),
		),
		array(
			'id' => 'bottom_padding',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback'=> 'worksquare_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom .bottom-bar-inner-wrap',
				'alter' => 'padding',
			),
		),
		array(
			'id' => 'bottom_background',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'color',
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback'=> 'worksquare_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom',
				'alter' => 'background',
			),
		),
		array(
			'id' => 'bottom_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Background Image', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_bottombar',
			),
		),
		array(
			'id' => 'bottom_background_img_style',
			'default' => 'repeat',
			'control' => array(
				'label' => esc_html__( 'Background Image Style', 'worksquare' ),
				'type'  => 'image',
				'type'  => 'select',
				'choices' => array(
					''             => esc_html__( 'Default', 'worksquare' ),
					'cover'        => esc_html__( 'Cover', 'worksquare' ),
					'center-top'        => esc_html__( 'Center Top', 'worksquare' ),
					'fixed-top'    => esc_html__( 'Fixed Top', 'worksquare' ),
					'fixed'        => esc_html__( 'Fixed Center', 'worksquare' ),
					'fixed-bottom' => esc_html__( 'Fixed Bottom', 'worksquare' ),
					'repeat'       => esc_html__( 'Repeat', 'worksquare' ),
					'repeat-x'     => esc_html__( 'Repeat-x', 'worksquare' ),
					'repeat-y'     => esc_html__( 'Repeat-y', 'worksquare' ),
				),
				'active_callback' => 'worksquare_cac_has_bottombar',
			),
		),
		array(
			'id' => 'bottom_color',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'color',
				'label' => esc_html__( 'Color', 'worksquare' ),
				'active_callback'=> 'worksquare_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom',
				'alter' => 'color',
			),
		),
		array(
			'id' => 'line_color',
			'transport' => 'postMessage',
			'control' =>  array(
				'type' => 'color',
				'label' => esc_html__( 'Line Color', 'worksquare' ),
				'active_callback'=> 'worksquare_cac_has_bottombar',
			),
			'inline_css' => array(
				'target' => '#bottom .bottom-bar-inner-wrap:before',
				'alter' => 'background-color',
			),
		),
	),
);