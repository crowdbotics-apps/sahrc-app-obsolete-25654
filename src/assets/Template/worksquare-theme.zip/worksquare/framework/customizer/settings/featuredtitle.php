<?php
/**
 * Featured Title setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Featured Title General
$this->sections['worksquare_featuredtitle_general'] = array(
	'title' => esc_html__( 'General', 'worksquare' ),
	'panel' => 'worksquare_featuredtitle',
	'settings' => array(
		array(
			'id' => 'featured_title',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
			),
		),
		array(
			'id' => 'featured_title_style',
			'default' => 'heading_breadcrumbs',
			'control' => array(
				'label'  => esc_html__( 'Style', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'heading_breadcrumbs' => esc_html__( 'Simple', 'worksquare' ),
					'heading_breadcrumbs_centered' => esc_html__( 'Centered', 'worksquare' ),
				),
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
		),
		array(
			'id' => 'featured_title_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Example: 250px 0px 150px 0px', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
			'inline_css' => array(
				'media_query' => '(min-width: 992px)',
				'target' => '#featured-title .inner-wrap',
				'alter' => 'padding',
			),
		),
		array(
			'id' => 'featured_title_background',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
			'inline_css' => array(
				'target' => '#featured-title',
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'featured_title_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Background Image', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
		),
		array(
			'id' => 'featured_title_background_img_style',
			'default' => 'repeat',
			'control' => array(
				'label' => esc_html__( 'Background Image Style', 'worksquare' ),
				'type'  => 'image',
				'type'  => 'select',
				'choices' => array(
					''             => esc_html__( 'Default', 'worksquare' ),
					'cover'        => esc_html__( 'Cover', 'worksquare' ),
					'center-top'        => esc_html__( 'Center Top', 'worksquare' ),
					'fixed-top'    => esc_html__( 'Fixed Top', 'worksquare' ),
					'fixed'        => esc_html__( 'Fixed Center', 'worksquare' ),
					'fixed-bottom' => esc_html__( 'Fixed Bottom', 'worksquare' ),
					'repeat'       => esc_html__( 'Repeat', 'worksquare' ),
					'repeat-x'     => esc_html__( 'Repeat-x', 'worksquare' ),
					'repeat-y'     => esc_html__( 'Repeat-y', 'worksquare' ),
				),
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
		),
	),
);

// Featured Title Headings
$this->sections['worksquare_featuredtitle_heading'] = array(
	'title' => esc_html__( 'Headings', 'worksquare' ),
	'panel' => 'worksquare_featuredtitle',
	'settings' => array(
		array(
			'id' => 'featured_title_heading',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
		),
		array(
			'id' => 'featured_title_heading_bottom_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Heading Bottom Margin', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title_center',
				'description' => esc_html__( 'Example: 5px.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '#featured-title.centered .title-group',
				'alter' => 'margin-bottom',
			),
		),
		array(
			'id' => 'featured_title_heading_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Title Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title_heading',
			),
			'inline_css' => array(
				'target' => '#featured-title .main-title',
				'alter' => 'color',
			),
		),
	),
);

// Featured Title Breadcrumbs
$this->sections['worksquare_featuredtitle_breadcrumbs'] = array(
	'title' => esc_html__( 'Breadcrumbs', 'worksquare' ),
	'panel' => 'worksquare_featuredtitle',
	'settings' => array(
		array(
			'id' => 'featured_title_breadcrumbs',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
		),
		array(
			'id' => 'featured_title_breadcrumbs_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Text Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title_breadcrumbs',
			),
			'inline_css' => array(
				'target' => array(
					'#featured-title #breadcrumbs',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'featured_title_breadcrumbs_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title_breadcrumbs',
			),
			'inline_css' => array(
				'target' => '#featured-title #breadcrumbs a',
				'alter' => 'color',
			),
		),
		array(
			'id' => 'featured_title_breadcrumbs_link_hover_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color: Hover', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title_breadcrumbs',
			),
			'inline_css' => array(
				'target' => '#featured-title #breadcrumbs a:hover',
				'alter' => 'color',
			),
		),
	),
);