<?php
/**
 * Shop setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Main Shop
$this->sections['worksquare_shop_general'] = array(
	'title' => esc_html__( 'Main Shop', 'worksquare' ),
	'panel' => 'worksquare_shop',
	'settings' => array(
		array(
			'id' => 'shop_layout_position',
			'default' => 'no-sidebar',
			'control' => array(
				'label' => esc_html__( 'Shop Layout Position', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'sidebar-right' => esc_html__( 'Right Sidebar', 'worksquare' ),
					'sidebar-left'  => esc_html__( 'Left Sidebar', 'worksquare' ),
					'no-sidebar'    => esc_html__( 'No Sidebar', 'worksquare' ),
				),
				'desc' => esc_html__( 'Specify layout for main shop page.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_featured_title',
			'default' => esc_html__( 'Our Shop', 'worksquare' ),
			'control' => array(
				'label' => esc_html__( 'Shop: Featured Title', 'worksquare' ),
				'type' => 'worksquare_textarea',
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_featured_title_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Shop: Featured Title Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_products_per_page',
			'default' => 6,
			'control' => array(
				'label' => esc_html__( 'Products Per Page', 'worksquare' ),
				'type' => 'number',
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_columns',
			'default' => '3',
			'control' => array(
				'label' => esc_html__( 'Shop Columns', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'2' => '2',
					'3' => '3',
					'4' => '4',
				),
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_item_bottom_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Item Bottom Margin', 'worksquare' ),
				'description' => esc_html__( 'Example: 30px.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_woo',
			),
			'inline_css' => array(
				'target' => '.products li',
				'alter' => 'margin-top',
			),
		),
	),
);

// Single Shop
$this->sections['worksquare_single_shop_general'] = array(
	'title' => esc_html__( 'Single Shop', 'worksquare' ),
	'panel' => 'worksquare_shop',
	'settings' => array(
		array(
			'id' => 'shop_single_layout_position',
			'default' => 'no-sidebar',
			'control' => array(
				'label' => esc_html__( 'Shop Single Layout Position', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'sidebar-right' => esc_html__( 'Right Sidebar', 'worksquare' ),
					'sidebar-left'  => esc_html__( 'Left Sidebar', 'worksquare' ),
					'no-sidebar'    => esc_html__( 'No Sidebar', 'worksquare' ),
				),
				'desc' => esc_html__( 'Specify layout on the shop single page.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_single_featured_title',
			'default' => esc_html__( 'Our Shop', 'worksquare' ),
			'control' => array(
				'label' => esc_html__( 'Shop Single: Featured Title', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_single_featured_title_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Shop Single: Featured Title Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_single_pre_heading',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Shop Single: Pre Heading', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
		array(
			'id' => 'shop_single_button_text',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Shop Single: Button Text', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_woo',
			),
		),
	),
);