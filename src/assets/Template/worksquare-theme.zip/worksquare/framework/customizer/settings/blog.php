<?php
/**
 * Blog setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Blog Posts General
$this->sections['worksquare_blog_post'] = array(
	'title' => esc_html__( 'General', 'worksquare' ),
	'panel' => 'worksquare_blog',
	'settings' => array(
		array(
			'id' => 'blog_featured_title',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Blog Featured Title', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'blog_entry_content_background',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Entry Content Background Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.post-content-wrap',
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'blog_entry_content_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Entry Content Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-content-wrap',
				'alter' => 'padding',
			),
		),
		array(
			'id' => 'blog_entry_bottom_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Entry Bottom Margin', 'worksquare' ),
				'description' => esc_html__( 'Example: 30px.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry',
				'alter' => 'margin-top',
			),
		),
		array(
			'id' => 'blog_entry_border_width',
			'transport' => 'postMessage',
			'control' => array (
				'type' => 'text',
				'label' => esc_html__( 'Entry Border Width', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left. Example: 0px 2px 0px 0px', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-content-wrap',
				'alter' => 'border-width',
			),
		),
		array(
			'id' => 'blog_entry_border_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Entry Border Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-content-wrap',
				'alter' => 'border-color',
			),
		),
		array(
			'id' => 'blog_entry_composer',
			'default' => 'title,meta,excerpt_content,readmore',
			'control' => array(
				'label' => esc_html__( 'Entry Content Elements', 'worksquare' ),
				'type' => 'worksquare-sortable',
				'object' => 'Worksquare_Customize_Control_Sorter',
				'choices' => array(
					'title'           => esc_html__( 'Title', 'worksquare' ),
					'meta'            => esc_html__( 'Meta', 'worksquare' ),
					'excerpt_content' => esc_html__( 'Excerpt', 'worksquare' ),
					'readmore'        => esc_html__( 'Read More', 'worksquare' ),

				),
				'desc' => esc_html__( 'Drag and drop elements to re-order.', 'worksquare' ),
			),
		),
	),
);

// Blog Custom Date
$this->sections['worksquare_blog_post_custom_date'] = array(
	'title' => esc_html__( 'Blog Post - Custom Date', 'worksquare' ),
	'panel' => 'worksquare_blog',
	'settings' => array(
		array(
			'id' => 'blog_custom_date',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Enable Custom Date on Posts', 'worksquare' ),
				'type' => 'checkbox',
			),
		),
	),
);

// Blog Posts Media
$this->sections['worksquare_blog_post_media'] = array(
	'title' => esc_html__( 'Blog Post - Media', 'worksquare' ),
	'panel' => 'worksquare_blog',
	'settings' => array(
		array(
			'id' => 'blog_media_margin_bottom',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Bottom Margin', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-media',
				'alter' => 'margin-bottom',
			),
		),
	),
);

// Blog Posts Title
$this->sections['worksquare_blog_post_title'] = array(
	'title' => esc_html__( 'Blog Post - Title', 'worksquare' ),
	'panel' => 'worksquare_blog',
	'settings' => array(
		array(
			'id' => 'blog_title_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Margin', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-title',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'blog_title_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'.hentry .post-title a',
				),
				'alter' => 'color',
			),
		),
		array(
			'id' => 'blog_title_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Color Hover', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-title a:hover',
				'alter' => 'color',
			),
		),
	),
);

// Blog Posts Meta
$this->sections['worksquare_blog_post_meta'] = array(
	'title' => esc_html__( 'Blog Post - Meta', 'worksquare' ),
	'panel' => 'worksquare_blog',
	'settings' => array(
		array(
			'id' => 'blog_entry_meta_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Meta Margin', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left. Example: 0 0 20px 0.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-meta',
				'alter' => 'margin',
			),
		),
		array(
			'id'  => 'blog_entry_meta_items',
			'default' => array( 'author', 'date' ),
			'control' => array(
				'label' => esc_html__( 'Meta Items', 'worksquare' ),
				'desc' => esc_html__( 'Click and drag and drop elements to re-order them.', 'worksquare' ),
				'type' => 'worksquare-sortable',
				'object' => 'Worksquare_Customize_Control_Sorter',
				'choices' => array(
					'author'     => esc_html__( 'Author', 'worksquare' ),
					'date'       => esc_html__( 'Date', 'worksquare' ),
					'comments' => esc_html__( 'Comments', 'worksquare' ),
					'categories' => esc_html__( 'Categories', 'worksquare' ),
				),
			),
		),
		array(
			'id' => 'heading_blog_entry_meta_item',
			'control' => array(
				'type' => 'worksquare-heading',
				'label' => esc_html__( 'Item Meta', 'worksquare' ),
			),
		),
		array(
			'id' => 'blog_entry_meta_item_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Text Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-meta .item',
				'alter' => 'color',
			),
		),
		array(
			'id' => 'blog_entry_meta_item_link_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-meta .item a',
				'alter' => 'color',
			),
		),
		array(
			'id' => 'blog_entry_meta_item_link_color_hover',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Link Color Hover', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-meta .item a:hover',
				'alter' => 'color',
			),
		),
	),
);

// Blog Posts Excerpt
$this->sections['worksquare_blog_post_excerpt'] = array(
	'title' => esc_html__( 'Blog Post - Excerpt', 'worksquare' ),
	'panel' => 'worksquare_blog',
	'settings' => array(
		array(
			'id' => 'blog_content_style',
			'default' => 'style-1',
			'control' => array(
				'label' => esc_html__( 'Content Style', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'style-1' => esc_html__( 'Normal', 'worksquare' ),
					'style-2' => esc_html__( 'Excerpt', 'worksquare' ),
				),
			),
		),
		array(
			'id' => 'blog_excerpt_length',
			'default' => '50',
			'control' => array(
				'label' => esc_html__( 'Excerpt length', 'worksquare' ),
				'type' => 'text',
				'desc' => esc_html__( 'This option only apply for Content Style: Excerpt.', 'worksquare' )
			),
		),
		array(
			'id' => 'blog_excerpt_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Margin', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left. Example: 0 0 30px 0.', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-excerpt',
				'alter' => 'margin',
			),
		),
		array(
			'id' => 'blog_excerpt_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => '.hentry .post-excerpt',
				'alter' => 'color',
			),
		),
	),
);

// Blog Posts Read More
$this->sections['worksquare_blog_post_read_more'] = array(
	'title' => esc_html__( 'Blog Post - Read More', 'worksquare' ),
	'panel' => 'worksquare_blog',
	'settings' => array(
		array(
			'id' => 'blog_entry_button_read_more_text',
			'default' => esc_html__( 'Read More', 'worksquare' ),
			'control' => array(
				'label' => esc_html__( 'Button Text', 'worksquare' ),
				'type' => 'text',
			),
		),
	),
);

