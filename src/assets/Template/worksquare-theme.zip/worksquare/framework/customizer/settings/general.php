<?php
/**
 * General setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Accent Colors
$this->sections['worksquare_accent_colors'] = array(
	'title' => esc_html__( 'Accent Colors', 'worksquare' ),
	'panel' => 'worksquare_general',
	'settings' => array(
		array(
			'id' => 'accent_color',
			'default' => '#4a83fb',
			'control' => array(
				'label' => esc_html__( 'Accent Color', 'worksquare' ),
				'type' => 'color',
			),
		),
	)
);

// Favicon
$this->sections['worksquare_favicon'] = array(
	'title' => esc_html__( 'Favicon', 'worksquare' ),
	'panel' => 'worksquare_general',
	'settings' => array(
		array(
			'id' => 'favicon',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Site Icon', 'worksquare' ),
				'type' => 'image',
				'description' => esc_html__( 'The Site Icon is used as a browser and app icon for your site. Icons must be square, and at least 512 pixels wide and tall.', 'worksquare' ),
			),
		),
	)
);

// PreLoader
$this->sections['worksquare_preloader'] = array(
	'title' => esc_html__( 'PreLoader', 'worksquare' ),
	'panel' => 'worksquare_general',
	'settings' => array(
		array(
			'id' => 'preloader',
			'default' => 'animsition',
			'control' => array(
				'label' => esc_html__( 'Preloader Option', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'animsition' => esc_html__( 'Enable','worksquare' ),
					'' => esc_html__( 'Disable','worksquare' )
				),
			),
		),
		array(
			'id' => 'preload_color_1',
			'default' => '#4a83fb',
			'control' => array(
				'label' => esc_html__( 'Color 1', 'worksquare' ),
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => '.animsition-loading',
				'alter' => 'border-top-color',
			),
		),
		array(
			'id' => 'preload_color_2',
			'default' => '#4a83fb',
			'control' => array(
				'label' => esc_html__( 'Color 2', 'worksquare' ),
				'type' => 'color',
			),
			'inline_css' => array(
				'target' => '.animsition-loading:before',
				'alter' => 'border-top-color',
			),
		),
	)
);

// Header Site
$this->sections['worksquare_header_site'] = array(
	'title' => esc_html__( 'Header Site', 'worksquare' ),
	'panel' => 'worksquare_general',
	'settings' => array(
		array(
			'id' => 'header_site_style',
			'default' => 'style-1',
			'control' => array(
				'label' => esc_html__( 'Header Style', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'style-1' => esc_html__( 'Style 1 (Basic)', 'worksquare' ),
					'style-2' => esc_html__( 'Style 2', 'worksquare' ),
					'style-3' => esc_html__( 'Style 3', 'worksquare' ),
					'style-4' => esc_html__( 'Style 4', 'worksquare' ),
					'style-5' => esc_html__( 'Style 5', 'worksquare' ),
					'style-6' => esc_html__( 'Style 6', 'worksquare' ),
				),
				'desc' => esc_html__( 'Header Style for all pages on website. (e.g. pages, blog posts, single post, archives, etc ). Single page can override this setting in Page Settings metabox when edit.', 'worksquare' )
			),
		),
		array(
			'id' => 'header_fixed',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Header Fixed: Enable', 'worksquare' ),
				'type' => 'checkbox',
			),
		),
	),
);

// Scroll to top
$this->sections['worksquare_scroll_top'] = array(
	'title' => esc_html__( 'Scroll Top Button', 'worksquare' ),
	'panel' => 'worksquare_general',
	'settings' => array(
		array(
			'id' => 'scroll_top',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
			),
		),
	),
);

// Forms
$this->sections['worksquare_general_forms'] = array(
	'title' => esc_html__( 'Forms', 'worksquare' ),
	'panel' => 'worksquare_general',
	'settings' => array(
		array(
			'id' => 'input_border_rounded',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Border Rounded', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'border-radius',
			),
		),
		array(
			'id' => 'input_background_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Background', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'background-color',
			),
		),
		array(
			'id' => 'input_border_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Border Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'border-color',
			),
		),
		array(
			'id' => 'input_border_width',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Border Width', 'worksquare' ),
				'description' => esc_html__( 'Enter a value in pixels. Example: 1px', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'border-width',
			),
		),
		array(
			'id' => 'input_color',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'color',
				'label' => esc_html__( 'Color', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'textarea,input[type="text"],input[type="password"],input[type="datetime"],input[type="datetime-local"],input[type="date"],input[type="month"],input[type="time"],input[type="week"],input[type="number"],input[type="email"],input[type="url"],input[type="search"],input[type="tel"],input[type="color"]',
				),
				'alter' => 'color',
			),
		),
	),
);

// Responsive
$this->sections['worksquare_responsive'] = array(
	'title' => esc_html__( 'Responsive', 'worksquare' ),
	'panel' => 'worksquare_general',
	'settings' => array(
		// Mobile Logo
		array(
			'id' => 'heading_mobile_logo',
			'control' => array(
				'type' => 'worksquare-heading',
				'label' => esc_html__( 'Mobile Logo', 'worksquare' ),
			),
		),
		array(
			'id' => 'mobile_logo_width',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Mobile Logo: Width', 'worksquare' ),
				'description' => esc_html__( 'Example: 150px', 'worksquare' ),
			),
			'inline_css' => array(
				'media_query' => '(max-width: 991px)',
				'target' => '#site-logo',
				'alter' => 'max-width',
			),
		),
		array(
			'id' => 'mobile_logo_margin',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Mobile Logo: Margin', 'worksquare' ),
				'description' => esc_html__( 'Example: 20px 0px 20px 0px', 'worksquare' ),
			),
			'inline_css' => array(
				'media_query' => '(max-width: 991px)',
				'target' => '#site-logo-inner',
				'alter' => 'margin',
			),
		),
		// Mobile Menu
		array(
			'id' => 'heading_mobile_menu',
			'control' => array(
				'type' => 'worksquare-heading',
				'label' => esc_html__( 'Mobile Menu', 'worksquare' ),
			),
		),
		array(
			'id' => 'mobile_menu_item_height',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Item Height', 'worksquare' ),
				'description' => esc_html__( 'Example: 40px', 'worksquare' ),
			),
			'inline_css' => array(
				'target' => array(
					'#main-nav-mobi ul > li > a',
					'#main-nav-mobi .menu-item-has-children .arrow'
				),
				'alter' => 'line-height'
			),
		),
		array(
			'id' => 'mobile_menu_logo',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Mobile Menu Logo', 'worksquare' ),
				'type' => 'image',
			),
		),
		array(
			'id' => 'mobile_menu_logo_width',
			'control' => array(
				'label' => esc_html__( 'Mobile Menu Logo: Width', 'worksquare' ),
				'type' => 'text',
			),
		),
		// Featured Title
		array(
			'id' => 'heading_featured_title',
			'control' => array(
				'type' => 'worksquare-heading',
				'label' => esc_html__( 'Mobile Featured Title', 'worksquare' ),
			),
		),
		array(
			'id' => 'mobile_featured_title_padding',
			'transport' => 'postMessage',
			'control' => array(
				'type' => 'text',
				'label' => esc_html__( 'Padding', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_featured_title',
			),
			'inline_css' => array(
				'media_query' => '(max-width: 991px)',
				'target' => '#featured-title .inner-wrap',
				'alter' => 'padding',
			),
		),
	)
);