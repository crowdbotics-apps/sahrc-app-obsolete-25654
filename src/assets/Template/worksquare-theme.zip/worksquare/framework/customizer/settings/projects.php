<?php
/**
 * Projects setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Project Related General
$this->sections['worksquare_projects_general'] = array(
	'title' => esc_html__( 'General', 'worksquare' ),
	'panel' => 'worksquare_projects',
	'settings' => array(
		array(
			'id' => 'project_related',
			'default' => true,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
				'active_callback' => 'worksquare_cac_has_single_project',
			),
		),
		array(
			'id' => 'project_single_featured_title_background_img',
			'control' => array(
				'type' => 'image',
				'label' => esc_html__( 'Single Project: Featured Title Background', 'worksquare' ),
				'active_callback' => 'worksquare_cac_has_related_project',
			),
		),
		array(
			'id' => 'related_pre_title', 
			'default' => esc_html__( 'EXPLORE PROJECTS', 'worksquare' ),
			'control' => array(
				'label' => esc_html__( 'Project Related Pre-Title', 'worksquare' ),
				'type' => 'worksquare_textarea',
				'rows' => 3,
				'active_callback' => 'worksquare_cac_has_related_project',
			),
		),
		array(
			'id' => 'related_title',
			'default' => esc_html__( 'OUR RECENT PROJECTS', 'worksquare' ),
			'control' => array(
				'label' => esc_html__( 'Project Related Title', 'worksquare' ),
				'type' => 'worksquare_textarea',
				'rows' => 3,
				'active_callback' => 'worksquare_cac_has_related_project',
			),
		),
		array(
			'id' => 'project_related_query',
			'default' => 7,
			'control' => array(
				'label' => esc_html__( 'Number of items', 'worksquare' ),
				'type' => 'number',
				'active_callback' => 'worksquare_cac_has_related_project',
			),
		),
		array(
			'id' => 'project_related_column',
			'default' => '3',
			'control' => array(
				'label' => esc_html__( 'Columns', 'worksquare' ),
				'type' => 'select',
				'choices' => array(
					'4' => '4',
					'3' => '3',
					'2' => '2',
				),
				'active_callback' => 'worksquare_cac_has_related_project',
			),
		),
		array(
			'id' => 'project_related_item_spacing',
			'default' => 30,
			'control' => array(
				'label' => esc_html__( 'Spacing between items', 'worksquare' ),
				'type' => 'number',
				'active_callback' => 'worksquare_cac_has_related_project',
			),
		),
	),
);