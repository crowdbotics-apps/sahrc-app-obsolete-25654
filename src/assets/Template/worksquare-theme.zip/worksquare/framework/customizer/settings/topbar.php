<?php
/**
 * Top Bar setting for Customizer
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// General
$this->sections['worksquare_topbar_general'] = array(
	'title' => esc_html__( 'General', 'worksquare' ),
	'panel' => 'worksquare_topbar',
	'settings' => array(
		array(
			'id' => 'topbar',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Active', 'worksquare' ),
				'type' => 'checkbox',
			),
			'inline_css' => array(
				'target' => '#topbar',
			),
		),
		array(
			'id' => 'topbar_height',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Height', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_topbar',
			),
		),		
		array(
			'id' => 'topbar_color',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Top Bar Background Color', 'worksquare' ),
				'type' => 'color',
				'active_callback' => 'worksquare_cac_has_topbar',
			),
		),
		array(
			'id' => 'topbar_divider_color',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Top Bar Divider Color', 'worksquare' ),
				'type' => 'color',
				'active_callback' => 'speedy_cac_has_topbar_divider',
			),
		),
	)
);

// Top Bar Socials
$this->sections['worksquare_topbar_socials'] = array(
	'title' => esc_html__( 'Top Bar Social', 'worksquare' ),
	'panel' => 'worksquare_topbar',
	'settings' => array(
		array(
			'id' => 'topbar_socials',
			'default' => false,
			'control' => array(
				'label' => esc_html__( 'Enable', 'worksquare' ),
				'type' => 'checkbox',
				'active_callback' => 'worksquare_cac_has_topbar',
			),
		),
		array(
			'id' => 'topbar_socials_margin',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Socials Margin', 'worksquare' ),
				'description' => esc_html__( 'Top Right Bottom Left. Example: 30px 0px 0px 0px.', 'worksquare' ),
				'type' => 'text',
				'active_callback' => 'worksquare_cac_has_topbar',
			),
		),
	),
);

// Social settings
$social_options = worksquare_topbar_social_options();
foreach ( $social_options as $key => $val ) {
	$this->sections['worksquare_topbar_socials']['settings'][] = array(
		'id' => 'topbar_social_profiles[' . $key .']',
		'control' => array(
			'label' => $val['label'],
			'type' => 'text',
			'active_callback' => 'worksquare_cac_has_topbar_socials',
		),
	);
}

// Remove var from memory
unset( $social_options );

// Topbar Link
$this->sections['worksquare_topbar_link'] = array(
	'title' => esc_html__( 'Topbar Link', 'worksquare' ),
	'panel' => 'worksquare_topbar',
	'settings' => array(
		array(
			'id' => 'topbar_link_text_one',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Link one', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'topbar_link_url_one',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Url one', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'topbar_link_text_two',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Link two', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'topbar_link_url_two',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Url two', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'topbar_link_text_three',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Link three', 'worksquare' ),
				'type' => 'text',
			),
		),
		array(
			'id' => 'topbar_link_url_three',
			'default' => '',
			'control' => array(
				'label' => esc_html__( 'Url three', 'worksquare' ),
				'type' => 'text',
			),
		),
	),
);

