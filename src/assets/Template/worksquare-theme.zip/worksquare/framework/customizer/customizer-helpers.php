<?php

/* Topbar */
function worksquare_cac_has_topbar() {
	return get_theme_mod( 'topbar', true );
}

function worksquare_cac_has_topbar_socials() {
	return get_theme_mod( 'topbar_socials', true );
}

function worksquare_cac_has_topbar_link() {
	return get_theme_mod( 'topbar_link', true );
}

function speedy_cac_has_topbar_divider() {
	if ( get_theme_mod( 'topbar', true ) ) {
		return get_theme_mod( 'topbar_divider', true );
	} else {
		return false;
	}
}

/* Headers */
function worksquare_cac_has_header_one() {
	$header_style = worksquare_get_mod( 'header_site_style', 'style-1' );
	if ( is_page() && worksquare_metabox( 'header_style' ) )
		$header_style = worksquare_metabox( 'header_style' );

	if ( 'style-1' == $header_style ) { return true;
	} else { return false; }
}

function worksquare_cac_has_header_two() {
	$header_style = worksquare_get_mod( 'header_site_style', 'style-2' );
	if ( is_page() && worksquare_metabox( 'header_style' ) )
		$header_style = worksquare_metabox( 'header_style' );

	if ( 'style-2' == $header_style ) { return true;
	} else { return false; }
}

function worksquare_cac_has_header_three() {
	$header_style = worksquare_get_mod( 'header_site_style', 'style-3' );
	if ( is_page() && worksquare_metabox( 'header_style' ) )
		$header_style = worksquare_metabox( 'header_style' );

	if ( 'style-3' == $header_style ) { return true;
	} else { return false; }
}

function worksquare_cac_has_header_four() {
	$header_style = worksquare_get_mod( 'header_site_style', 'style-4' );
	if ( is_page() && worksquare_metabox( 'header_style' ) )
		$header_style = worksquare_metabox( 'header_style' );

	if ( 'style-4' == $header_style ) { return true;
	} else { return false; }
}

function worksquare_cac_has_header_five() {
	$header_style = worksquare_get_mod( 'header_site_style', 'style-5' );
	if ( is_page() && worksquare_metabox( 'header_style' ) )
		$header_style = worksquare_metabox( 'header_style' );

	if ( 'style-5' == $header_style ) { return true;
	} else { return false; }
}

function worksquare_cac_has_header_six() {
	$header_style = worksquare_get_mod( 'header_site_style', 'style-6' );
	if ( is_page() && worksquare_metabox( 'header_style' ) )
		$header_style = worksquare_metabox( 'header_style' );

	if ( 'style-6' == $header_style ) { return true;
	} else { return false; }
}

function worksquare_cac_header_search_icon() {
	return get_theme_mod( 'header_search_icon', true );
}

function worksquare_cac_header_cart_icon() {
	if ( class_exists( 'woocommerce' ) && get_theme_mod( 'header_cart_icon', true ) ) {
		return true;	
	} else {
		return false;
	}
}

function worksquare_cac_has_header_button() {
	return get_theme_mod( 'header_button', true );
}

function worksquare_cac_has_header_socials() {
	return get_theme_mod( 'header_socials', true );
}

function worksquare_cac_has_header_fixed() {
	return get_theme_mod( 'header_fixed', true );
}

/* WooCommerce */
function worksquare_cac_has_woo() {
	if ( class_exists( 'woocommerce' ) ) { return true;	}
	else { return false; }
}

/* Scroll Top Button */
function worksquare_cac_has_scroll_top() {
	return get_theme_mod( 'scroll_top', true );
}

/* Layout */
function worksquare_cac_has_boxed_layout() {
	if ( 'boxed' == get_theme_mod( 'site_layout_style', 'full-width' ) ) {
		return true;
	} else {
		return false;
	}
}

/* Featured Title */
function worksquare_cac_has_featured_title() {
	return get_theme_mod( 'featured_title', true );
}

function worksquare_cac_has_featured_title_center() {
	if ( worksquare_cac_has_featured_title_heading()
		&& 'centered' == get_theme_mod( 'featured_title_style' ) ) {
		return true;
	} else {
		return false;
	}
}

function worksquare_cac_has_featured_title_breadcrumbs() {
	if ( worksquare_cac_has_featured_title() && get_theme_mod( 'featured_title_breadcrumbs' ) ) {
		return true;
	} else {
		return false;
	}
}

function worksquare_cac_has_featured_title_heading() {
	if ( worksquare_cac_has_featured_title() && get_theme_mod( 'featured_title_heading' ) ) {
		return true;
	} else {
		return false;
	}
}

/* Project Single */
function worksquare_cac_has_single_project() {
	if ( is_singular( 'project' ) ) {
		return true;
	} else {
		return false;
	}
}

function worksquare_cac_has_related_project() {
	if ( worksquare_get_mod( 'project_related', true ) && worksquare_cac_has_single_project() ) {
		return true;
	};
}

/* Footer
-------------------------------------------------------------- */
function worksquare_cac_has_footer_two() {
	$footer_style = worksquare_get_mod( 'footer_style' );
	if ( is_page() && worksquare_metabox( 'footer_style' ) )
		$footer_style = worksquare_metabox( 'footer_style' );

	if ( 'style-2' == $footer_style ) { return true;
	} else { return false; }
}

function worksquare_cac_has_footer_three() {
	$footer_style = worksquare_get_mod( 'footer_style' );
	if ( is_page() && worksquare_metabox( 'footer_style' ) )
		$footer_style = worksquare_metabox( 'footer_style' );

	if ( 'style-3' == $footer_style ) { return true;
	} else { return false; }
}

function worksquare_cac_has_footer_widgets() {
	return get_theme_mod( 'footer_widgets', true );
}

function worksquare_cac_has_footer_simple() {
	$fcol = worksquare_get_mod( 'footer_columns', '4' );

	if ( '5' != $fcol ) { return true;
	} else { return false; }
}


/* Bottom Bar
-------------------------------------------------------------- */
function worksquare_cac_has_bottombar() {
	return get_theme_mod( 'bottom_bar', true );
}