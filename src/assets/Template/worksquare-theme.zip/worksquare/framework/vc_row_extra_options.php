<?php
if ( function_exists('vc_add_param') ) {
    vc_add_param(
        'vc_column_inner',
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Half Background?', 'worksquare' ),
            'param_name' => 'halfbg',
            'value' => array(
                esc_html__( 'Disable', 'worksquare' ) => '',
                esc_html__( 'Background Color', 'worksquare' ) => 'color',
            ),
            'description' => esc_html__( 'Put a background left or right side of row', 'worksquare' ),
        )
    );
    vc_add_param(
        'vc_column_inner',
        array(
            'type' => 'colorpicker',
            'heading' => esc_html__( 'Background Color', 'worksquare' ),
            'param_name' => 'halfbg_color',
            'value' => '',
            'dependency' => array(
                'element' => 'halfbg',
                'value' => array( 'color' ),
            ),
        )
    );
    vc_add_param(
        'vc_column_inner',
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Background Position', 'worksquare' ),
            'param_name' => 'halfbg_position',
            'value' => array(
                esc_html__( 'Left', 'worksquare' ) => 'left',
                esc_html__( 'Right', 'worksquare' ) => 'right',                
            ),
            'dependency' => array(
                'element' => 'halfbg',
                'value' => array( 'color', 'image' ),
            ),
        )
    );
    vc_add_param(
        'vc_column_inner',
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Background Rounded', 'worksquare' ),
            'param_name' => 'halfbg_rounded',
            'dependency' => array(
                'element' => 'halfbg',
                'value' => array( 'color', 'image' ),
            ),
            'description' => esc_html__( 'Top Right Bottom Left.', 'worksquare' ),
        )
    );
} 