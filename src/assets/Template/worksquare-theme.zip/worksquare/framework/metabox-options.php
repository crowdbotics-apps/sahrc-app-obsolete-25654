<?php
/**
 * Metabox Options
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return the registered-widget array
function worksquare_get_widget_registered() {
	global $wp_registered_sidebars;

	$widgets_areas = array();
	if ( ! empty( $wp_registered_sidebars ) ) {
		foreach ( $wp_registered_sidebars as $widget_area ) {
			$name = isset ( $widget_area['name'] ) ? $widget_area['name'] : '';
			$id = isset ( $widget_area['id'] ) ? $widget_area['id'] : '';
			if ( $name && $id ) {
				$widgets_areas[$id] = $name;
			}
		}
	}

	return $widgets_areas;
}

// Return the all-widget array
function worksquare_get_widget_mods() {
	$new_arr = array();
	$widget_areas_mod = worksquare_get_mod( 'widget_areas' );
	
	if (is_array($widget_areas_mod) || is_object($widget_areas_mod)) {
		foreach( $widget_areas_mod as $key ) {
			$new_arr[sanitize_key($key)] = $key;
		}
	}
	
	$widget_areas = worksquare_get_widget_registered() + $new_arr;

	return $widget_areas;
}

// Registering meta boxes. Using Meta Box plugin: https://metabox.io/
function worksquare_register_meta_boxes( $meta_boxes ) {
	// Element Thumbnail
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Element Thumbnail', 'worksquare' ),
		'id'     => 'opt-meta-box-element-thumbnail',
		'pages'  => array( 'post' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Image', 'worksquare' ),
				'id'   => 'element_thumbnail',
				'type' => 'image_advanced',
				'max_file_uploads' => 1
			),
		),
	);
	// Post Format Gallery
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Post Format: Gallery', 'worksquare' ),
		'id'     => 'opt-meta-box-post-format-gallery',
		'pages'  => array( 'post' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Images', 'worksquare' ),
				'id'   => 'gallery_images',
				'type' => 'image_advanced',
			),
		),
	);

	// Post Custom Title
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Custom Post Title', 'worksquare' ),
		'id'     => 'opt-meta-box-custom-post-title',
		'pages'  => array( 'post' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Custom Post Title', 'worksquare' ),
				'id'   => 'custom_post_title',
				'type' => 'textarea',
			),
		)
	);

	// Post Format Video
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Post Format: Video ( Embeded video from youtube, vimeo...)', 'worksquare' ),
		'id'     => 'opt-meta-box-post-format-video',
		'pages'  => array( 'post' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Video URL or Embeded Code', 'worksquare' ),
				'id'   => 'video_url',
				'type' => 'textarea',
			),
		)
	);

	// Partner
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Partner Settings', 'worksquare' ),
		'id'     => 'opt-meta-box-partner',
		'pages'  => array( 'partner' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Hyperlink', 'worksquare' ),
				'id'   => 'partner_hyperlink',
				'type'       => 'text',
				'desc'  => esc_html__( "Partne's URL. Leave blank to disable (please 'http://' included).", 'worksquare' )
			),
		)
	);

	// Portfolio
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Project Settings', 'worksquare' ),
		'id'     => 'opt-meta-box-project',
		'pages'  => array( 'project' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Custom Title', 'worksquare' ),
				'id'   => 'custom_project_title',
				'type' => 'textarea',
			),
			array(
				'name' => esc_html__( 'Short Description', 'worksquare' ),
				'id'   => 'project_desc',
				'type' => 'textarea',
			),
			array(
				'name' => esc_html__( 'Price', 'worksquare' ),
				'id'   => 'project_price',
				'type' => 'text',
			),
			array(
				'name'    => esc_html__( 'Image Cropping', 'worksquare' ),
				'id'      => 'image_crop',
				'type'    => 'select',
				'options' => array(
					'full' => esc_html__( 'Full', 'worksquare' ),
					'std1' => esc_html__( '870 x 500', 'worksquare' ),
					'std2' => esc_html__( '570 x 500', 'worksquare' ),
					'std3' => esc_html__( '570 x 430', 'worksquare' ),
					'std4' => esc_html__( '535 x 700', 'worksquare' ),
				),
				'std'     => 'full',
			),
		)
	);

	// Member
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Member Information', 'worksquare' ),
		'id'     => 'opt-meta-box-pages',
		'pages'  => array( 'member' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Name', 'worksquare' ),
				'id'   => 'name',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Position', 'worksquare' ),
				'id'   => 'position',
				'type'       => 'textarea',
			),
			array(
				'name' => esc_html__( 'Text', 'worksquare' ),
				'id'   => 'text',
				'type'       => 'textarea',
			),
			array(
				'name' => esc_html__( 'Facebook', 'worksquare' ),
				'id'   => 'facebook',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Twitter', 'worksquare' ),
				'id'   => 'twitter',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Linkedin', 'worksquare' ),
				'id'   => 'linkedin',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Instagram', 'worksquare' ),
				'id'   => 'instagram',
				'type'       => 'text',
			),
		)
	);

	// Testimonials
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Testimonials Information', 'worksquare' ),
		'id'     => 'opt-meta-box-pages',
		'pages'  => array( 'testimonials' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Name', 'worksquare' ),
				'id'   => 'name',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Position', 'worksquare' ),
				'id'   => 'position',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Text', 'worksquare' ),
				'id'   => 'text',
				'type' => 'textarea',
			),
		)
	);

	// Event
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Event Information', 'worksquare' ),
		'id'     => 'opt-meta-box-pages',
		'pages'  => array( 'event' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Sub Title', 'worksquare' ),
				'id'   => 'event_sub_title',
				'type'       => 'textarea',
			),
			array(
				'name' => esc_html__( 'Event Time', 'worksquare' ),
				'id'   => 'event_time',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Event Day', 'worksquare' ),
				'id'   => 'event_day',
				'type'       => 'text',
			),
			array(
				'name' => esc_html__( 'Event Month', 'worksquare' ),
				'id'   => 'event_month',
				'type'       => 'text',
			),
		)
	);

	// TopBar Settings
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Top Bar Settings', 'worksquare' ),
		'id'     => 'opt-meta-box-topbar',
		'pages'  => array( 'page' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Hide?', 'worksquare' ),
				'id'   => 'hide_topbar',
				'type' => 'checkbox',
			),
			array(
			    'name'	=> esc_html__( 'Background', 'worksquare' ),
			    'id'	=> 'topbar_background',
			    'type'	=> 'color',
			    'alpha_channel' => true,
			    'js_options'    => array(
			        'palettes' => array( '#000000', '#ffffff', '#fd5a5a', '#0fc392', '#f37a32', '#bb5bd6', '#32b1f3', '#f87055' )
			    ),
			),
		)
	);

	// Header Settings
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Header Settings', 'worksquare' ),
		'id'     => 'opt-meta-box-header',
		'pages'  => array( 'page' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Custom Logo', 'worksquare' ),
			    'type' => 'single_image',
			    'id'   => 'custom_header_logo',
			),
			array(
				'type'		=>	'text',
				'name'		=>	esc_html__( 'Logo Width', 'worksquare' ),
				'id'		=>	'header_logo_width',
				'std'		=> 	'',
			),
			array(
				'name'    => esc_html__( 'Style', 'worksquare' ),
				'id'      => 'header_style',
				'type'    => 'select',
				'options' => array(
					'style-1' => esc_html__( 'Style 1 (Basic)', 'worksquare' ),
					'style-2' => esc_html__( 'Style 2', 'worksquare' ),
					'style-3' => esc_html__( 'Style 3', 'worksquare' ),
					'style-4' => esc_html__( 'Style 4', 'worksquare' ),
					'style-5' => esc_html__( 'Style 5', 'worksquare' ),
					'style-6' => esc_html__( 'Style 6', 'worksquare' ),
				),
				'std'     => 'style-1',
			),
			array(
			    'name'	=> esc_html__( 'Background', 'worksquare' ),
			    'id'	=> 'header_background',
			    'type'	=> 'color',
			    'alpha_channel' => true,
			    'js_options'    => array(
			        'palettes' => array( '#000000', '#ffffff', '#dd3333', '#dd9933', '#eeee22', '#81d742', '#1e73be', '#8224e3' )
			    ),
			),
			array(
			    'name'	=> esc_html__( 'Border Color', 'worksquare' ),
			    'id'	=> 'header_border_color',
			    'type'	=> 'color',
			    'alpha_channel' => true,
			    'js_options'    => array(
			        'palettes' => array( '#000000', '#ffffff', '#dd3333', '#dd9933', '#eeee22', '#81d742', '#1e73be', '#8224e3' )
			    ),
			),
		)
	);

	// Featured Title Settings
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Featured Title Settings', 'worksquare' ),
		'id'     => 'opt-meta-box-featured-title',
		'pages'  => array( 'page' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Hide?', 'worksquare' ),
				'id'   => 'hide_featured_title',
				'type' => 'checkbox',
			),
			array(
				'type'		=>	'image_advanced',
				'name'		=>	esc_html__( 'Background', 'worksquare' ),
				'id'		=>	'featured_title_bg',
			    'max_file_uploads' => 1,
			),
			array(
				'type'		=>	'textarea',
				'name'		=>	esc_html__( 'Custom Title', 'worksquare' ),
				'id'		=>	'custom_featured_title',
			),
		)
	);

	// Main Content Settings
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Main Content Settings', 'worksquare' ),
		'id'     => 'opt-meta-box-main-content',
		'pages'  => array( 'page' ),
		'fields' => array(
			array(
				'name'    => esc_html__( 'Layout Position', 'worksquare' ),
				'id'      => 'page_layout',
				'type'    => 'image_select',
				'options' => array(
					'no-sidebar'  => get_template_directory_uri() . '/assets/admin/img/full-content.png',
					'sidebar-left'  => get_template_directory_uri() . '/assets/admin/img/sidebar-left.png',
					'sidebar-right' => get_template_directory_uri() . '/assets/admin/img/sidebar-right.png',
				),
				'std' 		=> 'no-sidebar',
			),
			array(
				'name'    => esc_html__( 'Sidebar', 'worksquare' ),
				'id'      => 'page_sidebar',
				'type'    => 'select',
				'options' => worksquare_get_widget_mods(),
				'std'     => 'sidebar-page',
				'desc'    => esc_html__( 'This option do not apply if Layout Position is full-width.', 'worksquare' )
			),
			array(
			    'name'          => 'Background Color',
			    'id'            => 'main_content_bg',
			    'type'          => 'color',
			    'alpha_channel' => true,
			),
			array(
				'type'		=>	'image_advanced',
				'name'		=>	esc_html__( 'Background Image', 'worksquare' ),
				'id'		=>	'main_content_bg_img',
			    'max_file_uploads' => 1,
			),
			array(
				'name' => esc_html__( 'Remove: Top & Bottom Padding?', 'worksquare' ),
				'id'   => 'hide_padding_content',
				'type' => 'checkbox',
			),
		)
	);

	// Footer Settings
	$meta_boxes[] = array(
		'title'  => esc_html__( 'Footer Settings', 'worksquare' ),
		'id'     => 'opt-meta-box-footer',
		'pages'  => array( 'page' ),
		'fields' => array(
			array(
				'name' => esc_html__( 'Hide: Footer?', 'worksquare' ),
				'id'   => 'hide_footer',
				'type' => 'checkbox',
			),
			array(
			    'name'          => 'Footer Widget: Background',
			    'id'            => 'footer_bg',
			    'type'          => 'color',
			    'alpha_channel' => true,
			),
			array(
				'type'		=>	'image_advanced',
				'name'		=>	esc_html__( 'Footer Widget: Image Background', 'worksquare' ),
				'id'		=>	'footer_bg_img',
			    'max_file_uploads' => 1,
			),
			array(
			    'name'          => 'Bottom Bar: Background',
			    'id'            => 'bottom_bg',
			    'type'          => 'color',
			    'alpha_channel' => true,
			),

			array(
			    'name'          => 'Footer Style',
			    'id'            => 'footer_style',
			    'type'          => 'select',
			    'options' => array(
					'' => esc_html__( 'Default', 'worksquare' ),
					'style-1' => esc_html__( 'Style 1 (Basic)', 'worksquare' ),
					'style-2' => esc_html__( 'Style 2', 'worksquare' ),
					'style-3' => esc_html__( 'Style 3', 'worksquare' ),
				),
				'std'     => '',
			),
		)
	);

	return $meta_boxes;
}
add_filter( 'rwmb_meta_boxes', 'worksquare_register_meta_boxes' );