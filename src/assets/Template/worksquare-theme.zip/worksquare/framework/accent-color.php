<?php
/**
 * Accent color
 *
 * @package worksquare
 * @version 3.6.8
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Start class
if ( ! class_exists( 'Worksquare_Accent_Color' ) ) {
	class Worksquare_Accent_Color {
		// Main constructor
		function __construct() {
			add_filter( 'worksquare_custom_colors_css', array( 'Worksquare_Accent_Color', 'head_css' ), 999 );
		}

		// Generates arrays of elements to target
		public static function arrays( $return ) {
			// Color
			$texts = apply_filters( 'worksquare_accent_texts', array(
				'a','.text-accent-color','.link-dark:hover,.link-gray:hover','.post.sticky .post-title .sticky-post','#site-logo .site-logo-text:hover','#main-nav .sub-menu li a:hover','.mobi-overlay .close:hover:after','#main-nav-mobi ul>li>a:hover','.search-style-fullscreen .search-submit:hover:after','.search-style-fullscreen .search-close:hover:before','.header-info>.content:before','.header-style-1 #site-header .header-search-trigger:hover,.header-style-1 #site-header .nav-top-cart-wrapper .nav-cart-trigger:hover','.hentry .page-links a span,.hentry .page-links span','.hentry .post-title a:hover','.hentry .post-meta .item.post-by-author a,.hentry .post-meta .item.post-comment a,.hentry .post-meta .item.post-meta-categories a','.hentry .post-tags a:first-child,.hentry .post-tags a:hover','.hentry .post-author .author-socials .socials a','.related-news .related-title','.related-news .post-item .post-categories a:hover','.related-news .post-item .text-wrap h3 a:hover','.related-news .related-post .slick-next:hover:before,.related-news .related-post .slick-prev:hover:before','#cancel-comment-reply-link,.comment-reply a','.comment-edit-link','.unapproved','#comments .comment-respond .form-submit input[type="submit"]','.logged-in-as a','#footer-widgets .widget.widget_archive ul li a:hover,#footer-widgets .widget.widget_categories ul li a:hover,#footer-widgets .widget.widget_meta ul li a:hover,#footer-widgets .widget.widget_nav_menu ul li a:hover,#footer-widgets .widget.widget_pages ul li a:hover,#footer-widgets .widget.widget_recent_comments ul li a:hover,#footer-widgets .widget.widget_recent_entries ul li a:hover,#footer-widgets .widget.widget_rss ul li a:hover','.widget.widget_archive ul li a:hover,.widget.widget_categories ul li a:hover,.widget.widget_meta ul li a:hover,.widget.widget_nav_menu ul li a:hover,.widget.widget_pages ul li a:hover,.widget.widget_recent_comments ul li a:hover,.widget.widget_recent_entries ul li a:hover,.widget.widget_rss ul li a:hover','.widget.widget_calendar a,.widget.widget_calendar tbody #today,.widget.widget_calendar tbody #today a','#footer-widgets .widget.widget_calendar a:hover,#footer-widgets .widget.widget_calendar tbody #today a:hover,#footer-widgets .widget.widget_calendar tbody #today:hover','.widget.widget_nav_menu .menu>li.current-menu-item,.widget.widget_nav_menu .menu>li.current-menu-item>a','#sidebar .widget_information ul li.accent-icon i','.widget.widget_search .search-form .search-submit:before','.widget.widget_recent_news h3 a:hover','#footer-widgets .widget.widget_tag_cloud .tagcloud a','.worksquare-pagination ul li .page-numbers,.woocommerce-pagination .page-numbers li .page-numbers','.no-results-content .search-form .search-submit:before','.deeper-link.style-3:hover','.deeper-link.style-3:hover:after,.deeper-link.style-4:hover:after','.special-link ul li a:hover','.deeper-button.outline.outline-accent','.deeper-counter .icon.accent,.deeper-counter .number.accent,.deeper-counter .prefix.accent,.deeper-counter .suffix.accent','.deeper-counter.style-2 .heading','.deeper-divider.has-icon .icon-wrap>span.accent','.deeper-special-text .heading.accent','.custom-content .pre-heading','.deeper-icon.accent .icon','.deeper-image-box .item .title a:hover','.deeper-image-box.image-hover:hover .title','.deeper-news.style-1 .item-flickity.is-selected .texts .title','.deeper-news.style-2 .item-flickity:first-child .texts .title','#project-filter .cbp-filter-item.cbp-filter-item-active,#project-filter .cbp-filter-item:hover','.project-related-wrap .title-wrap .pre-title','.deeper-portfolio .project-item:hover .title','.project-information ul .item.category,.project-information ul .item.skills','.deeper-progress .perc.accent','.deeper-subscribe.style-2 .mc4wp-form-fields .submit-wrap button:before','.deeper-testimonial-box.style-1 .author-name','.deeper-video-icon.style-1','.deeper-list .icon.accent','.deeper-person-info .name','.woocommerce a','.woocommerce-page .content-woocommerce .pre-heading','.woocommerce-page .woocommerce-MyAccount-content .woocommerce-info .button','.woocommerce-page .products li .product-cat','.woocommerce .products li .product-cat:hover,.woocommerce-page .products li .product-cat:hover','.woocommerce .products li h2:hover,.woocommerce-page .products li h2:hover','.woo-single-post-class .woocommerce-grouped-product-list-item__label a:hover','.woo-single-post-class .summary .product_meta>span a','.woo-single-post-class .woocommerce-tabs ul li>a','.woo-single-post-class .woocommerce-tabs .panel .product-meta:after','.woo-single-post-class .woocommerce-tabs .entry-content .meta .woocommerce-review__published-date','.woocommerce .shop_table.cart .product-name a:hover,.woocommerce-page .shop_table.cart .product-name a:hover','.woocommerce-MyAccount-navigation ul li a:hover','.product_list_widget .product-title:hover,.widget_recent_reviews .product_list_widget a:hover','.widget_product_categories ul li a:hover','.widget.widget_product_search .woocommerce-product-search .search-submit:hover:before','.widget_shopping_cart_content ul li a:hover', '.deeper-price-box .plan-name',
			) );

			// Background color
			$backgrounds = apply_filters( 'worksquare_accent_backgrounds', array(
				'blockquote:before','.button,button,input[type="button"],input[type="reset"],input[type="submit"]','.bg-accent','.rs-layer .pre-heading .tag','.slider-form .submit-wrap button:hover','#main-nav-mobi::-webkit-scrollbar','#main-nav-mobi::-webkit-scrollbar-thumb','.header-button a','.header-socials a:hover','.hentry .post-media .post-date-custom','.post-media .slick-next:hover,.post-media .slick-prev:hover','.post-media .slick-dots li.slick-active button','.hentry .post-link a','#comments .comment-respond .form-submit input[type="submit"]:hover','.widget.widget_archive ul li>span,.widget.widget_categories ul li>span','.widget_mc4wp_form_widget .mc4wp-form .submit-wrap button','#footer-widgets .widget_mc4wp_form_widget .mc4wp-form .submit-wrap button:hover','.widget.widget_socials .socials a:hover','#footer-widgets .widget.widget_socials .socials a:hover','.widget.widget_tag_cloud .tagcloud a:hover,.widget_product_tag_cloud .tagcloud a:hover','#footer-widgets .widget.widget_tag_cloud .tagcloud a:hover','.newsletter-box .newsletter-form button','#scroll-top:hover:before','.worksquare-pagination ul li .page-numbers.current,.worksquare-pagination ul li .page-numbers:hover,.woocommerce-pagination .page-numbers li .page-numbers.current,.woocommerce-pagination .page-numbers li .page-numbers:hover','.deeper-accordions.style-1 .item.active .heading,.deeper-accordions.style-3 .item.active .heading','.deeper-button.button-accent','.deeper-button.outline.outline-accent:hover','.deeper-button.button-green:hover','.deeper-button.button-dark:hover','.deeper-content-box>.inner.accent,.deeper-content-box>.inner.dark-accent,.deeper-content-box>.inner.light-accent','.deeper-adv-tabs .tab-title .item-title.active>.anchor-link','.deeper-special-text .line.accent','.deeper-icon-box .icon-number','.deeper-icon-box:hover .icon-number','.deeper-icon.accent-bg .icon','.deeper-image-box .item .thumb .hover-image .arrow','.deeper-image-box.style-2 .url-wrap .arrow','.deeper-share-social.style-1 li a:hover','.deeper-share-social.style-2 li a:hover','.deeper-images-grid .zoom-popup:after','.project-box .project-text .button a','.project-box .project-text .arrow a','.deeper-progress .progress-animate.accent','.deeper-images-carousel.has-borders:after','.deeper-images-carousel.has-borders:before','.deeper-images-carousel.has-arrows.arrow-bottom .owl-nav','.deeper-images-carousel .item-wrap .popup-image:hover:after','.deeper-subscribe.style-2 .mc4wp-form-fields:before','.button.mfp-close:hover,button.mfp-arrow:hover','.member-item .socials li a:hover','.rs-layer .video-icon-2','.deeper-contact-form.button-accent .wrap-submit input','.deeper-contact-form.button-green .wrap-submit input:hover','.owl-theme .owl-nav [class*=owl-]','.product .onsale,.woocommerce-page .woo-single-post-class .summary .stock.in-stock','.woo-single-post-class .images .woocommerce-product-gallery__trigger:hover:after','.woo-single-post-class .summary .cart .single_add_to_cart_button','.woocommerce-page .wc-proceed-to-checkout .button','.woocommerce-page .return-to-shop a','#payment #place_order','.woocommerce-MyAccount-navigation ul li.is-active','.widget_price_filter .price_slider_amount .button:hover','.widget_shopping_cart_content .buttons a.checkout','.deeper-button.button-green:hover','.flickity-page-dots .dot.is-selected',
			) );

			// Border color
			$borders = apply_filters( 'worksquare_accent_borders', array(
				'.widget_mc4wp_form_widget .mc4wp-form .email-wrap input:focus',
				'#footer-widgets .widget.widget_socials .socials a:hover',
				'.widget.widget_tag_cloud .tagcloud a:hover',
				'.widget_product_tag_cloud .tagcloud a:hover',
				'#footer-widgets .widget.widget_tag_cloud .tagcloud a:hover',
				'no-results-content .search-form .search-field:focus',
				'.deeper-button.outline.outline-accent',
				'.deeper-button.outline.outline-accent:hover',
				'.divider-icon-before.accent',
				'.divider-icon-after.accent',
				'.deeper-divider.has-icon .divider-double.accent',
				'.woo-single-post-class .summary .cart .single_add_to_cart_button',
				'.flickity-page-dots .dot.is-selected',
				'#comments .comment-respond .form-submit input[type="submit"]'
			) );

			// Gradient color
			$gradients = apply_filters( 'worksquare_accent_gradient', array(
				'.worksquare-progress .progress-animate.accent.gradient'
			) );

			// Return array
			if ( 'texts' == $return ) {
				return $texts;
			} elseif ( 'backgrounds' == $return ) {
				return $backgrounds;
			} elseif ( 'borders' == $return ) {
				return $borders;
			} elseif ( 'gradients' == $return ) {
				return $gradients;
			}
		}

		// Generates the CSS output
		public static function head_css( $output ) {
			// Get custom accent
			$default_accent = '#4a83fb';
			$custom_accent  = worksquare_get_mod( 'accent_color' );

			// Return if accent color is empty or equal to default
			if ( ! $custom_accent || ( $default_accent == $custom_accent ) )
				return $output;

			// Define css var
			$css = '';

			// Get arrays
			$texts       = self::arrays( 'texts' );
			$backgrounds = self::arrays( 'backgrounds' );
			$borders     = self::arrays( 'borders' );
			$gradients    = self::arrays( 'gradients' );

			// Texts
			if ( ! empty( $texts ) )
				$css .= implode( ',', $texts ) .'{color:'. $custom_accent .';}';

			// Backgrounds
			if ( ! empty( $backgrounds ) )
				$css .= implode( ',', $backgrounds ) .'{background-color:'. $custom_accent .';}';

			// Borders
			if ( ! empty( $borders ) ) {
				foreach ( $borders as $key => $val ) {
					if ( is_array( $val ) ) {
						$css .= $key .'{';
						foreach ( $val as $key => $val ) {
							$css .= 'border-'. $val .'-color:'. $custom_accent .';';
						}
						$css .= '}'; 
					} else {
						$css .= $val .'{border-color:'. $custom_accent .';}';
					}
				}
			}

			// Gradients
			if ( ! empty( $gradients ) )
				$css .= implode( ',', $gradients ) .'{background: '. worksquare_hex2rgba($custom_accent, 1) .';background: -moz-linear-gradient(left, '. worksquare_hex2rgba($custom_accent, 1) .' 0%, '. worksquare_hex2rgba($custom_accent, 0.3) .' 100%);background: -webkit-linear-gradient( left, '. worksquare_hex2rgba($custom_accent, 1) .' 0%, '. worksquare_hex2rgba($custom_accent, 0.3) .' 100% );background: linear-gradient(to right, '. worksquare_hex2rgba($custom_accent, 1) .' 0%, '. worksquare_hex2rgba($custom_accent, 0.3) .' 100%) !important;}';

			// Return CSS
			if ( ! empty( $css ) )
				$output .= '/*ACCENT COLOR*/'. $css;

			// Return output css
			return $output;
		}
	}
}

new Worksquare_Accent_Color();
