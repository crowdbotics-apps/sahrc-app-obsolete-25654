jQuery( function($) {
	var page = 1;

	$('.project-loadmore').on( 'click', function() {
        var 
        $this = $(this),
        wrap = $this.prev( '.worksquare-portfolio' ),
        container = $this.prev( '.worksquare-portfolio' ).find( '#portfolio' ),
        query = $this.attr( 'data-query' );

		$.ajax({
			type: 'POST',
			url: ajax_params.ajaxurl,
			data: {
				'action': 'loadmore',
				'query': query,
				'page': page,
				'nonce': ajax_params.nonce
			},
			beforeSend: function( xhr ) {
				$this.addClass( 'loading' ).text( 'Loading...' );
			},
			success: function( data ) {
				if ( data ) {
					//$(data).hide().appendTo( wrap ).fadeIn();
					$(container).cubeportfolio( 'appendItems', data );

					$this.removeClass( 'loading' ).text( 'More Posts' );
 					page++;
				} else {
					$this.removeClass( 'loading' ).text( 'No More Posts' );
				}
			}
		});

	} );
} );