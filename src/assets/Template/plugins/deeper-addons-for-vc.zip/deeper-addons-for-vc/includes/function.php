<?php

// Get Shortcode String
if ( ! function_exists('deeper_get_shortcode') ) {
	function deeper_get_shortcode( $shortcode_name, $atts, $prefix ) {
		$params = '';
		$length = strlen( $prefix );

		foreach( $atts as $key => $value ) {
			if ( substr( $key, 0, $length ) == $prefix ) {
				$params .= ' '. $key .'="'. $value .'"';
			}
		}

		return sprintf( '[%1$s %2$s]', $shortcode_name, $params );
	}
}

// Accent Color
if ( ! function_exists('deeper_get_accent_color') ) {
	function deeper_get_accent_color() {
		return '#0f66dc';
	}
}

// Return list of contact form 7
if ( ! function_exists('deeper_list_contact_form_7') ) {
	function deeper_list_contact_form_7() {
		$forms = array();
	    $posts = get_posts(array(
	        'post_type'     => 'wpcf7_contact_form',
	        'numberposts'   => -1
	    ));

	    foreach ( $posts as $p ) {
	        $forms[$p->post_title] = $p->ID;
	    }

		return $forms;
	}
}

