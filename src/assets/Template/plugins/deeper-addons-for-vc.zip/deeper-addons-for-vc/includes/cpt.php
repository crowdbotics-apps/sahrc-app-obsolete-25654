<?php 
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Deeper_Custom_Post_Type' ) ) {

	// Class Deeper_Custom_Post_Type
	class Deeper_Custom_Post_Type {
		function __construct() {
			require_once __DIR__ .'/post-type/project.php';
			require_once __DIR__ .'/post-type/team.php';
			require_once __DIR__ .'/post-type/partner.php';
			require_once __DIR__ .'/post-type/event.php';
	    }
	}

	new Deeper_Custom_Post_Type;
}