<?php
/**
 * GridBox shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_gridbox extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_GridBox_Shortcode' ) ) {

	class Deeper_GridBox_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_gridbox', array( 'Deeper_GridBox_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_gridbox', array( 'Deeper_GridBox_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract( shortcode_atts( array(
			    'column' => '4',
			    'column2' => '1',
			    'column3' => '1',
			    'column4' => '1',
			    'style' => 'default',
			    'gapv' => '',
			    'gaph' => '',
			    'class'	=> '',
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$cls = $data = '';
			
			$cls .= ' grid' . $column . ' '. $style . ' ' . $gapv . ' '. $gaph . ' ' . $class;
			$cls .= ' grid-lg-' . $column2 . ' grid-md-' . $column3 . ' grid-sm-' . $column4;

			$data .= 'data-column="' . $column . '"';

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			return sprintf(
				'<div class="deeper-gridbox clearfix %2$s" %3$s>%1$s</div>',
				do_shortcode( $content ),
				$cls,
				$data
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Grid Box', 'deeper' ),
		        'description' => __( 'Divide container inside with same width.', 'deeper' ),
		        'base' => 'gridbox',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/gridbox.png', __FILE__ ),
		        'as_parent' => array('except' => 'deeper_gridbox'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'js_view' => 'VcColumnView',
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
			        array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Number of Columns ?', 'deeper' ),
						'param_name'  => 'column',
						'value'       => array(
							'2 Columns' => '2',
							'3 Columns' => '3',
							'4 Columns' => '4',
						),
						'std'		=> '4',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Number of Columns ? ( Tablet < 1024px )', 'deeper' ),
						'param_name'  => 'column2',
						'value'       => array(
							'1 Column' => '1',
							'2 Columns' => '2',
							'3 Columns' => '3',
						),
						'std'		=> '1',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Number of Columns ? ( Mobile < 991px )', 'deeper' ),
						'param_name'  => 'column3',
						'value'       => array(
							'1 Column' => '1',
							'2 Columns' => '2',
							'3 Columns' => '3',
						),
						'std'		=> '1',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Number of Columns ? ( Small Mobile < 767px )', 'deeper' ),
						'param_name'  => 'column4',
						'value'       => array(
							'1 Column' => '1',
							'2 Columns' => '2',
						),
						'std'		=> '1',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Style', 'deeper' ),
						'param_name'  => 'style',
						'value'       => array(
							'Default' => 'default',
							'No Borders' => 'no-borders',
							'Seperate by border' => 'grib-border',
							'Has Shadow' => 'grib-shadown',							
						),
						'std'		=> 'default',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Grid Item Spacing : Vertical', 'deeper' ),
						'param_name'  => 'gapv',
						'value'       => array(
							'0px' => '',
							'5px' => 'v-5',
							'10px' => 'v-10',
							'15px' => 'v-15',
							'20px' => 'v-20',
							'25px' => 'v-25',
							'30px' => 'v-30',
							'35px' => 'v-35',
							'40px' => 'v-40',
							'45px' => 'v-45',
							'50px' => 'v-50',
							'55px' => 'v-55',
							'60px' => 'v-60',
							'70px' => 'v-70',
							'80px' => 'v-80',
						),
						'std'		=> '',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Grid Item Spacing : Horizontal', 'deeper' ),
						'param_name'  => 'gaph',
						'value'       => array(
							'0px' => '',
							'5px' => 'h-5',
							'10px' => 'h-10',
							'15px' => 'h-15',
							'20px' => 'h-20',
							'25px' => 'h-25',
							'30px' => 'h-30',
							'35px' => 'h-35',
							'40px' => 'h-40',
							'45px' => 'h-45',
							'50px' => 'h-50',
						),
						'std'		=> '',
					),
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class', 'deeper' ),
						'param_name'  => 'class',
						'value'       => ''
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}
}

new Deeper_GridBox_Shortcode;