<?php
/**
 * Text shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Text_Shortcode' ) ) {

	class Deeper_Text_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_text', array( 'Deeper_Text_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_text', array( 'Deeper_Text_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			$cls = $css = $data = '';

			extract( shortcode_atts( array(
				'text_align' 		=> 'align-center',
			    'text_tag' 			=> 'h2',
			    'text_has_color' 	=> '',
				'text_font_size' 	=> '',
				'font_size_mobile' => '',
				'text_line_height' 	=> '',
			    'text_color' 		=> '',
			    'text_bg'			=> '',
			    'text_width' 		=> '',
			    'text_extra' 		=> '',
				'text_font_family' 	=> '',
				'text_font_weight' 	=> '',
				'text_letter_spacing' => '',
				'text_margin_bottom'  => '',
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			if ( $content ) {
				$content = wpb_js_remove_wpautop( $content, true );
				// Change <p> tag to <span>
				$content = str_replace( '<p>', '<span>', $content );
				$content = str_replace( '</p>', '</span>', $content );
				
				$accent = deeper_get_accent_color();

				$cls = $text_align . ' ' . $text_extra;

				if ( $text_width ) $cls .= ' text-has-width';

				if ( $text_font_size ) $css .= 'font-size:'. intval( $text_font_size ) .'px;';
				if ( $text_font_weight ) $css .= 'font-weight:'. intval( $text_font_weight ) .';';
				if ( $text_line_height ) $css .= 'line-height:'. intval( $text_line_height ) .'px;';
				if ( $text_letter_spacing ) $css .= 'letter-spacing:'. $text_letter_spacing . 'px;';
				if ( $text_margin_bottom != '' ) $css .= 'margin-bottom:'. intval( $text_margin_bottom ) .'px;';
				if ( $text_width ) $css .= 'max-width:'. intval( $text_width ) .'px;';
				if ( $text_color == $accent ) { $cls .= ' accent-color';
				} else { if ( $text_color ) $css .= 'color:'. $text_color .';'; }

				if ( $font_size_mobile ) $cls .= ' mobi-size-'. $font_size_mobile;

				if ( $text_font_family ) {
					deeper_enqueue_google_font( $text_font_family );
					$css .= 'font-family:'. $text_font_family .';';
				}

				if ( $text_bg ) $css .= '-webkit-text-fill-color:transparent;-webkit-background-clip:text;background-image: url(' . 
					esc_url( wp_get_attachment_image_src( $text_bg, 'full' )[0] ) . ');';

				//Animation
				if ( $animation ) {
				    $cls .= ' wow '. $animation_effect;
				    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
				}

				return sprintf(
					'<%1$s class="deeper-text %4$s" style="%3$s" %5$s>%2$s</%1$s>',
					$text_tag,
					$content,
					$css,
					$cls,
					$data
				);
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Text', 'deeper' ),
		        'description' => __( 'Group of text with some styles..', 'deeper' ),
		        'base' => 'heading',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/singleheading.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
			        array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'text_align',
						'value'      => array(
							'Align Left' => 'align-left',
							'Align Right' => 'align-right',
							'Align Center' => 'align-center',
						),
						'std'		=> 'align-center',
					),
					array(
						'type' => 'textarea_html',
						'holder' => 'div',
						'heading' => __( 'Text Content', 'deeper' ),
						'param_name' => 'content',
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Text Color', 'deeper' ),
						'param_name' => 'text_color',
						'value' => '',
		            ),
		            array(
						'type' => 'attach_image',
						'heading' => esc_html__('Background Image', 'deeper'),
						'param_name' => 'text_bg',
						'value' => '',
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Text Max-Width', 'deeper' ),
						'param_name' => 'text_width',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Text Margin Bottom', 'deeper' ),
						'param_name' => 'text_margin_bottom',
						'value' => '',
			        ),		
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'text_extra',
						'value' => '',
			        ),           
			        // Typography
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Font Family', 'deeper' ),
						'param_name' => 'text_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Text Tag', 'deeper' ),
						'param_name' => 'text_tag',
						'value'      => array(
							'H1' => 'h1',
							'H2' => 'h2',
							'H3' => 'h3',
							'H4' => 'h4',
							'H5' => 'h5',
							'H6' => 'h6',
							'Div' => 'div',
						),
						'std'		=> 'h2',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Text: Font Weight', 'deeper' ),
						'param_name' => 'text_font_weight',
						'value'      => array(
							'Default'		=> '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> '',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Text: Font Size', 'deeper' ),
						'param_name' => 'text_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Font Size on Mobile', 'deeper' ),
						'param_name' => 'font_size_mobile',
						'value'      => array(
							'Disable' => '',
							'10px' => '10',
							'12px' => '12',
							'14px' => '14',
							'16px' => '16',
							'18px' => '18',
							'20px' => '20',
							'22px' => '22',
							'24px' => '24',
							'26px' => '26',
							'28px' => '28',
							'30px' => '30',
							'32px' => '32',
							'34px' => '34',
							'36px' => '36',
							'38px' => '38',
							'40px' => '40',
						),
						'std'		=> '',
						'group' => esc_html__( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Text: Line Height', 'deeper' ),
						'param_name' => 'text_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'deeper_number',
						'heading' => __( 'Text: Letter Spacing', 'deeper' ),
						'param_name' => 'text_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}
}

new Deeper_Text_Shortcode;
