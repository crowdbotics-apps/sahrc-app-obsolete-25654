<?php
/**
 * Icon shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Icon_Shortcode' ) ) {

	class Deeper_Icon_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_icon', array( 'Deeper_Icon_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_icon', array( 'Deeper_Icon_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$cls = $css = $data = $text_html = '';
			$heading_css = $desc_css = '';
			$url_wrap_css = $url_css = $link_html = $link_cls = '';
			$button_cls = $button_data = '';
			$icon_html = $icon = $icon_css = $cls = $icon_data = $icon_string = '';

			extract( shortcode_atts( array(
				'icon_display' => 'icon_display',
				'icon_style' => 'icon-top',
				'icon_align' => 'align-left',
				'icon_display' => 'icon-font',

				'icon_image' => '',
				'icon_image_width' => '',

				'icon_text' => '',

				'icon' => '',
				'icon_type' => '',
				'icon_font_size' => '',
				'icon_width' => '',
				'icon_height' => '',
				'icon_line_height' => '',
				'icon_rounded' => '',

				'icon_color' => '',
				'icon_background' => '',
				'icon_border_width' => '',
				'icon_border_style' => 'solid',
				'icon_border' => '',
				'icon_color_hover' => '',
				'icon_background_hover' => '',
				'icon_border_hover' => '',
				'icon_shadow' => '',
				'icon_shadow_hover' => '',
				'icon_parent_hover' => '',
				'icon_margin' => '',	
				'icon_extra'	=> '',	
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',	
			), $atts ) );
			$content = wpb_js_remove_wpautop( $content, true );
			$accent = deeper_get_accent_color();
			$cls = $icon_style . ' ' . $icon_align;
			$bg_cls = '';

			if ( $icon_display == 'icon-font' || $icon_display == 'icon-text' ) {
				$ico_config = array();
				$cls = $icon_display . ' icon-' . rand();
				if ( $icon_extra ) $cls .= ' ' . $icon_extra;

				if ( $icon_display == 'icon-font' && $icon_type ) {
					if ( isset( $atts["icon_{$icon_type}"] ) )
						$icon = $atts["icon_{$icon_type}"];
					vc_icon_element_fonts_enqueue( $icon_type );

					$icon_string = '<i class="' . $icon . '"></i>';
				}

				if ( $icon_display == 'icon-text' ) $icon_string = $icon_text;
				if ( $icon_width ) $cls .= ' icon-has-width';

				if ( $icon_color == $accent ) {
					$cls .= ' text-accent-color';
				} else if ( $icon_color ) {
					$ico_config['color'] = $icon_color;
				}

			    if ( $icon_background == $accent ) {
			        $bg_cls .= ' bg-accent';
			    } else if ( $icon_background ) {
			    	$ico_config['bg'] = $icon_background;
			    }

				if ( $icon_font_size ) $ico_config['fontSize'] = $icon_font_size;
				if ( $icon_width ) $ico_config['width'] = $icon_width;
				if ( $icon_height ) $ico_config['height'] = $icon_height;
				if ( $icon_line_height ) $ico_config['lineHeight'] = $icon_line_height;
			   	if ( $icon_rounded ) $ico_config['rounded'] = $icon_rounded;
			   	if ( $icon_shadow ) $ico_config['shadow'] = $icon_shadow;
			   	if ( $icon_margin ) $ico_config['margin'] = $icon_margin;

			    if ( $icon_border_width ) {
			        if ( $icon_border == $accent ) {
			            $cls .= ' accent-border';
			            $ico_config['border'] = intval( $icon_border_width ) . 'px ' . $icon_border_style;
			        } else if ( $icon_border ) {
			        	$ico_config['border'] = intval( $icon_border_width ) . 'px ' . $icon_border_style . ' ' . $icon_border;
			        }

			        if ( $icon_border_hover ) $ico_config['borderHover'] = intval( $icon_border_width ) . 'px ' . $icon_border_style . ' ' . $icon_border_hover;
			    }

				if ( $icon_color_hover ) $ico_config['colorHover'] = $icon_color_hover;
				if ( $icon_background_hover ) $ico_config['bgHover'] = $icon_background_hover;
				if ( $icon_shadow_hover ) $ico_config['shadowHover'] = $icon_shadow_hover;
				
				if ( $icon_parent_hover ) $ico_config['parentHover'] = $icon_parent_hover;
				
				if ( $ico_config )
					$icon_data = 'data-config=\'' . json_encode( $ico_config ) . '\'';

				//Animation
				if ( $animation ) {
				    $cls .= ' wow '. $animation_effect;
				    $icon_data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
				}

				if ( $icon_string )
					return sprintf(
						'<div class="deeper-icon %2$s" %3$s>
							<span class="icon-wrap %4$s">%1$s</span>
						</div>',
						$icon_string,
						$cls,
						$icon_data,
						$bg_cls
					);
				
			} else {
				if ( $icon_image_width ) $icon_css = 'width:' . intval( $icon_image_width ) . 'px;';
				if ( $icon_margin ) $icon_css .= 'margin:' . $icon_margin . ';';

				//Animation
				if ( $animation ) {
				    $cls .= ' wow '. $animation_effect;
				    $icon_data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
				}

				if ( $icon_image )
					return sprintf(
						'<div class="image-wrap %3$s" style="%2$s" %4$s>
							<img alt="image" src="%1$s">
						</div>',
						esc_url( wp_get_attachment_image_src( $icon_image, 'full' )[0] ),
						$icon_css,
						$cls,
						$icon_data
					);
			}
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => __( 'Icon', 'deeper' ),
		        'description' => __( 'Displays an Icon.', 'deeper' ),
				'base' => 'deeper_icon',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/icons.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
				'params' => array(
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'icon_style',
						'value'      => array(
							'Icon Top' => 'icon-top',
							'Icon Left' => 'icon-left',
							'Icon Right' => 'icon-right',
						),
						'std'		=> 'icon-top',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'icon_align',
						'value'      => array(
							'Left' => 'align-left',
							'Center' => 'align-center',
							'Right' => 'align-right',
						),
						'std'		=> 'align-left',
						'dependency' => array( 'element' => 'style', 'value' => 'icon-top' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon to Display', 'deeper' ),
						'param_name' => 'icon_display',
						'value'      => array(
							'Icon Font' => 'icon-font',
							'Icon Image' => 'icon-image',
							'Icon Text' => 'icon-text'
						),
						'std'		=> 'icon-font',
					),
			        // Image
					array(
						'type' => 'attach_image',
						'heading' => __( 'Image', 'deeper' ),
						'param_name' => 'icon_image',
						'value' => '',
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Image Width', 'deeper' ),
						'param_name' => 'icon_image_width',
						'value' => '',
						'description'	=> __( 'Example: 100px', 'deeper' ),
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
			        ),
			        // Icon Text
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Text', 'deeper' ),
						'param_name' => 'icon_text',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-text' ),
			        ),
			        					// Icon
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Icon library', 'deeper' ),
						'param_name' => 'icon_type',
						'description' => esc_html__( 'Select icon library.', 'deeper' ),
						'value' => array(
							'' => '',
							esc_html__( 'Basic', 'deeper' ) => 'basic',
							esc_html__( 'Corporate', 'deeper' ) => 'corporate',
							esc_html__( 'Stroke 7 Icons', 'deeper' ) => '7stroke',
							esc_html__( 'FontAwesome', 'deeper' ) => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_basic',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'basic',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'basic',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_corporate',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'corporate',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'corporate',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_7stroke',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => '7stroke',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => '7stroke',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon',
						'settings' => array(
							'emptyIcon' => true,
							'iconsPerPage' => 200,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Icon Font Size', 'deeper' ),
						'param_name' => 'icon_font_size',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Width', 'deeper' ),
						'param_name' => 'icon_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Height', 'deeper' ),
						'param_name' => 'icon_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Line Height', 'deeper' ),
						'param_name' => 'icon_line_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Rounded', 'deeper' ),
						'param_name' => 'icon_rounded',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Color', 'deeper' ),
						'param_name' => 'icon_color',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Background', 'deeper' ),
						'param_name' => 'icon_background',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Border Width', 'deeper' ),
						'param_name' => 'icon_border_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon Border Style', 'deeper' ),
						'param_name' => 'icon_border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Border', 'deeper' ),
						'param_name' => 'icon_border',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Shadow', 'deeper' ),
						'param_name' => 'icon_shadow',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Icon Hover', 'deeper' ),
						'param_name' => 'icon_typograpy',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Color: Hover', 'deeper' ),
						'param_name' => 'icon_color_hover',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Background: Hover', 'deeper' ),
						'param_name' => 'icon_background_hover',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Border: Hover', 'deeper' ),
						'param_name' => 'icon_border_hover',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Shadow Hover', 'deeper' ),
						'param_name' => 'icon_shadow_hover',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'icon_parent_hover',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-icon-box', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Extra Class', 'deeper' ),
						'param_name' => 'icon_extra',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
			        ),
			        // Background
			        array(
						'type' => 'attach_image',
						'heading' => __( 'Background', 'deeper' ),
						'param_name' => 'bg_image',
						'value' => '',
						'group' => __( 'Background', 'deeper' ),
						'dependency' => array( 'element' => 'style', 'value' => 'icon-left-2' ),
					),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'nusafe' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'value'      => array( esc_html__( 'Yes, please.', 'nusafe' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'nusafe' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'nusafe'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'nusafe'),
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'nusafe'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'nusafe'),
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				)
			);

		}
	}

	new Deeper_Icon_Shortcode;
}
