<?php
/**
 * Price_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Price_Box_Shortcode' ) ) {

	class Deeper_Price_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_pricebox', array( 'Deeper_Price_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_pricebox', array( 'Deeper_Price_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$price_css = $plan_name_css = $plan_desc_css = $features_css = '';
			$price_cls = $plan_name_cls = $plan_desc_cls = '';
			$prefix_html = $suffix_html = '';
			$css = $cls = $data = '';
			$html = '';
			$url_string = '';

			extract( shortcode_atts( array(
			    'align' => 'align-left',
			    'plan_name' => '',
			    'plan_name_color' => '',
			    'plan_desc' => '',
			    'plan_desc_color' => '',
			    'price' => '',
			    'price_text_color' => '',
			    'price_pre' => '',
			    'price_pre_color' => '',
			    'price_suf' => '',
			    'price_suf_color' => '',    
			    'list_style' => '',
			    'url_showcase'			=> '',
				// Button General
				'button_align'			=> 'align-left',
				'button_style'			=> 'button-accent',
				'button_size'			=> 'medium',
				'button_text' 			=> 'Read More',
				'button_url' 			=> '',
				'button_margin' 		=> '',
				'button_extra'			=> '',
				// Button Custom 
				'button_padding' 		=> '14px 20px 14px 20px',
				'button_rounded' 		=> '',
				'button_text_color'	 	=> '',
				'button_background' 	=> '',
			    'button_border_width' 	=> '',
			    'button_border_style' 	=> 'solid',
				'button_border' 		=> '',
				'button_shadow' 		=> '',
				'button_text_hover' 	=> '',
				'button_background_hover' => '',
				'button_border_hover' 	=> '',
				'button_shadow_hover' 	=> '',
				'button_parent_hover' 	=> '',
				// Button Typography
				'button_font_family' 	=> '',
				'button_font_weight' 	=> '',
				'button_font_size' 		=> '',
				'button_line_height' 	=> '',
				'button_letter_spacing' 	=> '',
				// Link General
				'link_align'			=> 'align-left',
				'link_style'			=> 'style-1',
				'link_text' 			=> 'Read More',
				'link_url' 				=> '',
				'link_margin' 			=> '',
				'link_extra'			=> '',
				// Link Typography
				'link_font_family' 		=> '',
				'link_font_weight' 		=> '',
				'link_font_size' 		=> '',
				'link_line_height' 		=> '',
				'link_letter_spacing' 	=> '',
				'link_color'			=> '',
				'link_line_color'		=> '',
				'link_icon_color'		=> '',
				'link_hover_color'			=> '',
				'link_hover_line_color'		=> '',
				'link_hover_icon_color'		=> '',
				'link_parent_hover'			=> '',
				// Design
				'bg_color'	=> '',
				'border'	=> '',
				'rounded'	=> '',
				'shadow'	=> '',
				// Typography
				'plan_name_font_family' => '',
				'plan_name_font_weight' => '',
				'plan_name_font_size' => '',
				'plan_name_line_height' => '',
				'plan_name_letter_spacing' => '',
				'plan_desc_font_family' => '',
				'plan_desc_font_weight' => '',
				'plan_desc_font_size' => '',
				'plan_desc_line_height' => '',
				'plan_desc_letter_spacing' => '',
				'price_font_family' => '',
				'price_font_weight' => '',
				'price_font_size' => '',
				'price_line_height' => '',
				'price_letter_spacing' => '',
				'price_pre_font_family' => '',
				'price_pre_font_weight' => '',
				'price_pre_font_size' => '',
				'price_pre_line_height' => '',
				'price_pre_letter_spacing' => '',
				'price_suf_font_family' => '',
				'price_suf_font_weight' => '',
				'price_suf_font_size' => '',
				'price_suf_line_height' => '',
				'price_suf_letter_spacing' => '',
				// Spacing
				'padding' => '',
				'plan_name_margin' => '',
				'plan_desc_margin' => '',
				'price_margin' => '',
				'features_margin' => '',
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
				// Extra Class
				'class' => '',
			), $atts ) );
			$content = wpb_js_remove_wpautop( $content, true );
			$accent = deeper_get_accent_color();
			
			$cls = $align . ' ' . $class;
			if ( $padding ) $css .= 'padding:' . $padding . ';';

			if ( $bg_color ) $css .= 'background-color:' . $bg_color . ';';
			if ( $border ) $css .= 'border:' . $border . ';';
			if ( $rounded ) $css .= 'overflow:hidden;border-radius:' . $rounded . ';';
			if ( $shadow ) $css .= 'box-shadow:' . $shadow . ';';

			// Plan name 
			if ( $plan_name ) {
				if ( $plan_name_margin )$plan_name_css .= 'margin-bottom:'. intval( $plan_name_margin ) .'px;';

				if ( $plan_name_color == $accent ) {
					$plan_name_cls .= ' accent-color';
				} elseif ( $plan_name_color ) {
					$plan_name_css .= 'color:'. $plan_name_color .';';
				}

				if ( $plan_name_font_family ) {
					deeper_enqueue_google_font( $plan_name_font_family );
					$plan_name_css .= 'font-family:' . $plan_name_font_family . ';';
				}

				if ( $plan_name_font_weight ) $plan_name_css .= 'font-weight:'. $plan_name_font_weight .';';
				if ( $plan_name_font_size ) $plan_name_css .= 'font-size:'. intval( $plan_name_font_family ) .'px;';
				if ( $plan_name_line_height ) $plan_name_css .= 'line-height:'. $plan_name_line_height .';';
				if ( $plan_name_letter_spacing ) $plan_name_css .= 'letter-spacing:'. intval( $plan_name_letter_spacing ) .'px;';

				$html .= sprintf( 
					'<h2 class="plan-name %1$s" style="%2$s">%3$s</h2>',
					$plan_name_cls,
					$plan_name_css,
					$plan_name 
				);
			}
			
			// Price Styles
			if ( $price ) {
				if ( $price_margin ) $price_css .= 'margin-bottom:'. intval( $price_margin ) .'px;';

				if ( $price_text_color == $accent ) {
					$price_cls .= ' accent-color';
				} elseif ( $price_text_color ) {
					$price_css .= 'color:'. $price_text_color .';';
				}

				if ( $price_font_family ) {
					deeper_enqueue_google_font( $price_font_family );
					$price_css .= 'font-family:' . $price_font_family . ';';
				}

				if ( $price_font_weight ) $price_css .= 'font-weight:'. $price_font_weight .';';
				if ( $price_font_size ) $price_css .= 'font-size:'. intval( $price_font_size ) .'px;';
				if ( $price_line_height ) $price_css .= 'line-height:'. $price_line_height .';';
				if ( $price_letter_spacing ) $price_css .= 'letter-spacing:'. intval( $price_letter_spacing ) .'px;';

				// Prefix
				if ( $price_pre ) {
					$prefix_html = $prefix_css = $prefix_cls = '';

					if ( $price_pre_color == $accent ) {
						$prefix_cls .= 'color-accent';
					} elseif ( $price_pre_color ) {
						$prefix_css .= 'color:' . $price_pre_color . ';';
					}

					if ( $price_pre_font_family ) {
						deeper_enqueue_google_font( $price_pre_font_family );
						$prefix_css .= 'font-family:' . $price_pre_font_family . ';';
					}

					if ( $price_pre_font_weight ) $prefix_css .= 'font-weight:'. $price_pre_font_weight .';';
					if ( $price_pre_font_size ) $prefix_css .= 'font-size:'. intval( $price_pre_font_size ) .'px;';
					if ( $price_pre_line_height ) $prefix_css .= 'line-height:'. $price_pre_line_height .';';
					if ( $price_pre_letter_spacing ) $prefix_css .= 'letter-spacing:'. intval( $price_pre_letter_spacing ) .'px;';

					$prefix_html = sprintf( '<span class="prefix %2$s" style="%3$s">%1$s</span>', 
						$price_pre, 
						$prefix_cls, 
						$prefix_css );
				}

				// Subfit
				if ( $price_suf ) {
					$suffix_html = $suffix_css = $suffix_cls = '';

					if ( $price_suf_color == $accent ) {
						$suffix_cls .= 'color-accent';
					} elseif ( $price_suf_color ) {
						$suffix_css .= 'color:' . $price_suf_color . ';';
					}

					if ( $price_suf_font_family ) {
						deeper_enqueue_google_font( $price_suf_font_family );
						$suffix_css .= 'font-family:' . $price_suf_font_family . ';';
					}

					if ( $price_suf_font_weight ) $suffix_css .= 'font-weight:'. $price_suf_font_weight .';';
					if ( $price_suf_font_size ) $suffix_css .= 'font-size:'. intval( $price_suf_font_size ) .'px;';
					if ( $price_suf_line_height ) $suffix_css .= 'line-height:'. $price_suf_line_height .';';
					if ( $price_suf_letter_spacing ) $suffix_css .= 'letter-spacing:'. intval( $price_suf_letter_spacing ) .'px;';

					$suffix_html = sprintf( '<span class="suffix %2$s" style="%3$s">%1$s</span>', 
						$price_suf, 
						$suffix_cls, 
						$suffix_css );
				}

				$html .= sprintf(
					'<div class="price %1$s" style="%2$s"><span class="price-inner">%4$s %3$s%5$s</span></div>',
					$price_cls,
					$price_css,
					esc_attr( $price ),
					$prefix_html,
					$suffix_html
				);
			}
			
			// Plan description
			if ( $plan_desc ) {
				if ( $plan_desc_margin ) $plan_desc_css .= 'margin-bottom:'. intval( $plan_desc_margin ) .'px;';

				if ( $plan_desc_color == $accent ) {
					$plan_desc_cls .= ' accent-color';
				} elseif ( $plan_desc_color ) {
					$plan_desc_css .= 'color:'. $plan_desc_color .';';
				}

				if ( $plan_desc_font_family ) {
					deeper_enqueue_google_font( $plan_desc_font_family );
					$plan_desc_css .= 'font-family:' . $plan_desc_font_family . ';';
				}

				if ( $plan_desc_font_weight ) $plan_desc_css .= 'font-weight:'. $plan_desc_font_weight .';';
				if ( $plan_desc_font_size ) $plan_desc_css .= 'font-size:'. intval( $plan_desc_font_family ) .'px;';
				if ( $plan_desc_line_height ) $plan_desc_css .= 'line-height:'. $plan_desc_line_height .';';
				if ( $plan_desc_letter_spacing ) $plan_desc_css .= 'letter-spacing:'. intval( $plan_desc_letter_spacing ) .'px;';

				$html .= sprintf( 
					'<div class="plan-desc %1$s" style="%2$s">%3$s</div>',
					$plan_desc_cls,
					$plan_desc_css,
					$plan_desc
				);
			}

			// Features
			if ( $content ) {
				if ( $features_margin ) $features_css .= 'margin-bottom:'. intval( $features_margin ) .'px;';
				$html .= sprintf('<div class="features" style="%2$s">%1$s</div>', $content, $features_css );
			}
			
			// Shortcode Button & Link
			if ( $url_showcase == 'link' )
				$url_string = deeper_get_shortcode( 'deeper_link', $atts, 'link' );

			if ( $url_showcase == 'button' )
				$url_string = deeper_get_shortcode( 'deeper_button', $atts, 'button' );

			//Animation
			if ( $animation ) {
			    $anim_cls = ' wow '. $animation_effect;
			    $anim_data = ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';

			    return sprintf(
					'<div class="%6$s" %7$s>
						<div class="deeper-price-box %1$s" style="%2$s" %3$s>
							%4$s
							%5$s
						</div>
					</div>',
					$cls,
					$css,
					$data,
					$html,
					do_shortcode( $url_string ),
					$anim_cls,
					$anim_data
				);
			}

			return sprintf(
				'<div class="deeper-price-box %1$s" style="%2$s" %3$s>
					%4$s
					%5$s
				</div>',
				$cls,
				$css,
				$data,
				$html,
				do_shortcode( $url_string )
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Price Box', 'deeper' ),
		        'description' => __( 'Custom Price Box.', 'deeper' ),
		        'base' => 'pricebox',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/pricetable.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'align',
						'value'      => array(
							'Left' => 'align-left',
							'Center' => 'align-center',
							'Right' => 'align-right',
						),
						'std'		=> 'align-left',
					),
		        	array(
						'type' => 'deeper_heading',
						'text' => __( 'Plan', 'deeper' ),
						'param_name' => 'heading_plan',
					),
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => __( 'Plan Name', 'deeper' ),
						'param_name' => 'plan_name',
						'value' => ''
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Plan Name Color', 'deeper' ),
						'param_name' => 'plan_name_color',
						'value' => ''
			        ),
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => __( 'Plan Description', 'deeper' ),
						'param_name' => 'plan_desc',
						'value' => ''
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Plan Description Color', 'deeper' ),
						'param_name' => 'plan_desc_color',
						'value' => ''
			        ),
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Price', 'deeper' ),
						'param_name' => 'heading_price',
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Plan Price', 'deeper' ),
						'param_name' => 'price',
						'value' => ''
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Price Text Color', 'deeper' ),
						'param_name' => 'price_text_color',
						'value' => ''
			        ),
					array(
						'type' => 'textfield',
						'heading' => __( 'Price : Prefix', 'deeper' ),
						'param_name' => 'price_pre',
						'value' => ''
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Price Prefix Color', 'deeper' ),
						'param_name' => 'price_pre_color',
						'value' => ''
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Price : Suffix', 'deeper' ),
						'param_name' => 'price_suf',
						'value' => ''
			        ), 
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Price Suffix Color', 'deeper' ),
						'param_name' => 'price_suf_color',
						'value' => ''
			        ),
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Features', 'deeper' ),
						'param_name' => 'heading_features',
					),
					array(
						'type' => 'textarea_html',
						'holder' => 'div',
						'class' => '',
						'heading' => __( 'Features Content', 'deeper' ),
						'param_name' => 'content',
						'value' => '',
  						'description' => __( "Enter your content.", "deeper" )
			        ),
			        // Button or Link
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'url_showcase',
						'value'      => array(
							'Disable' => '',
							'Link' => 'link',
							'Button' => 'button',
						),
						'std'		=> '',
						'group' => __( 'URL', 'deeper' ),
					),
					// Link
					array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'link_align',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
						'value' => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'medium'
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Link Style', 'deeper' ),
						'param_name' => 'link_style',
						'value' => array(
							'Style 1' 		=> 'style-1',
							'Style 2' 		=> 'style-2',
							'Style 3' 		=> 'style-3',
						),
						'std'		=> 'style-1',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
					),
			        array(
						'type' => 'textfield',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'link_text',
						'value' => 'Read More',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'link_url',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Link Color', 'deeper'),
						'param_name' => 'link_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Line Color', 'deeper'),
						'param_name' => 'link_line_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Icon Color', 'deeper'),
						'param_name' => 'link_icon_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        // Button 
			        array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'button_align',
						'value' => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'medium',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Style', 'deeper' ),
						'param_name' => 'button_style',
						'value' => array(
							'Accent' 	=> 'button-accent',
							'Outline Accent' 	=> 'outline-accent',
							'Radical Red' 		=> 'button-radical-red',			
							'Outline Radical Red' 		=> 'outline-radical-red',			
							'Blue' 		=> 'button-blue',			
							'Outline Blue' 		=> 'outline-blue',
							'Green' 		=> 'button-green',			
							'Outline Green' 		=> 'outline-green',	
							'White' 		=> 'button-white',			
							'Custom' 			=> 'custom',
						),
						'std'		=> 'button-accent',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Size', 'deeper' ),
						'param_name' => 'button_size',
						'value' => array(
							'Small' 		=> 'small',
							'Medium' 		=> 'medium',
							'Big' 			=> 'big',
						),
						'std'		=> 'medium',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),	
			        array(
						'type' => 'textfield',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'button_text',
						'value' => 'Read More',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'button_url',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
			        // Custom
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Custom Button', 'deeper' ),
						'param_name' => 'deeper_heading',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Padding', 'deeper' ),
						'param_name' => 'button_padding',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left.', 'deeper' ),
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Rounded', 'deeper' ),
						'param_name' => 'button_rounded',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Text Color', 'deeper' ),
						'param_name' => 'button_text_color',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Background', 'deeper' ),
						'param_name' => 'button_background',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Border Width', 'deeper' ),
						'param_name' => 'button_border_width',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Button Border Style', 'deeper' ),
						'param_name' => 'button_border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
					),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Border', 'deeper' ),
						'param_name' => 'button_border',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Shadow', 'deeper' ),
						'param_name' => 'button_shadow',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        // Link Hover
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Link Hover', 'deeper' ),
						'param_name' => 'deeper_link_hover',
						'group' => __( 'Hover', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
					),
					array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Link Color', 'deeper'),
						'param_name' => 'link_hover_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Line Color', 'deeper'),
						'param_name' => 'link_hover_line_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Icon Color', 'deeper'),
						'param_name' => 'link_hover_icon_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'link_parent_hover',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-content-box', 'deeper' ),
			        ),
					// Button Hover
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Button Hover', 'deeper' ),
						'param_name' => 'deeper_heading_hover',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
					),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Text: Hover', 'deeper' ),
						'param_name' => 'button_text_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Background: Hover', 'deeper' ),
						'param_name' => 'button_background_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Border: Hover', 'deeper' ),
						'param_name' => 'button_border_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Shadow: Hover', 'deeper' ),
						'param_name' => 'button_shadow_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'button_parent_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-icon-box', 'deeper' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'group' => __( 'URL', 'deeper' ),
						'param_name' => 'button_extra',
						'value' => '',
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),  
			        // Design
					array(
						'type' => 'colorpicker',
						'heading' => __( 'Background Color', 'deeper' ),
						'param_name' => 'bg_color',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Border', 'deeper' ),
						'param_name' => 'border',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
						'description'	=> __( 'Ex: 1px solid #e7e7e7', 'deeper' ),
			        ), 
			        array(
						'type' => 'textfield',
						'heading' => __( 'Rounded', 'deeper' ),
						'param_name' => 'rounded',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
						'description'	=> __( 'Ex: 5px', 'deeper' ),
			        ), 
			        array(
						'type' => 'textfield',
						'heading' => __( 'Box Shadow', 'deeper' ),
						'param_name' => 'shadow',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
						'description'	=> __( 'Ex: outset 10px 10px 0 30px rgba(0,0,0,0.2)', 'deeper' ),
			        ), 				
			        // Typography
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Plan name', 'deeper' ),
						'param_name' => 'heading_plan_name',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Plan Name: Font Family', 'deeper' ),
						'param_name' => 'plan_name_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Plan name: Font Weight', 'deeper' ),
						'param_name' => 'plan_name_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Plan name: Font Size', 'deeper' ),
						'param_name' => 'plan_name_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Plan name: Line Height', 'deeper' ),
						'param_name' => 'plan_name_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Plan name: Letter Spacing', 'deeper' ),
						'param_name' => 'plan_name_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Plan description', 'deeper' ),
						'param_name' => 'heading_plan_desc',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Plan description: Font Family', 'deeper' ),
						'param_name' => 'plan_desc_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Plan description: Font Weight', 'deeper' ),
						'param_name' => 'plan_desc_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Plan description: Font Size', 'deeper' ),
						'param_name' => 'plan_desc_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Plan description: Line Height', 'deeper' ),
						'param_name' => 'plan_desc_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Plan description: Letter Spacing', 'deeper' ),
						'param_name' => 'plan_desc_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Pricing', 'deeper' ),
						'param_name' => 'heading_price',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Pricing: Font Family', 'deeper' ),
						'param_name' => 'price_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Pricing: Font Weight', 'deeper' ),
						'param_name' => 'price_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pricing: Font Size', 'deeper' ),
						'param_name' => 'price_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pricing: Line Height', 'deeper' ),
						'param_name' => 'price_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Pricing: Letter Spacing', 'deeper' ),
						'param_name' => 'price_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	// Pricing Prefix
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Pricing Prefix', 'deeper' ),
						'param_name' => 'heading_price_pre',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_pre', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Pricing Prefix: Font Family', 'deeper' ),
						'param_name' => 'price_pre_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_pre', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Pricing Prefix: Font Weight', 'deeper' ),
						'param_name' => 'price_pre_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_pre', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pricing Prefix: Font Size', 'deeper' ),
						'param_name' => 'price_pre_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_pre', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pricing Prefix: Line Height', 'deeper' ),
						'param_name' => 'price_pre_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_pre', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Pricing Prefix: Letter Spacing', 'deeper' ),
						'param_name' => 'price_pre_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_pre', 'not_empty' => true ),
				  	),
				  	// Pricing Suffix
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Pricing Suffix', 'deeper' ),
						'param_name' => 'heading_price_suf',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_suf', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Pricing Suffix: Font Family', 'deeper' ),
						'param_name' => 'price_suf_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_suf', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Pricing Suffix: Font Weight', 'deeper' ),
						'param_name' => 'price_suf_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_suf', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pricing Suffix: Font Size', 'deeper' ),
						'param_name' => 'price_suf_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_suf', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pricing Suffix: Line Height', 'deeper' ),
						'param_name' => 'price_suf_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_suf', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Pricing Suffix: Letter Spacing', 'deeper' ),
						'param_name' => 'price_suf_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'price_suf', 'not_empty' => true ),
				  	),
			        // Spacing
			        array(
						'type' => 'textfield',
						'heading' => __( 'Box Padding', 'deeper' ),
						'param_name' => 'padding',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
					array(
						'type' => 'textfield',
						'heading' => __( 'Plan Name Bottom Margin', 'deeper' ),
						'param_name' => 'plan_name_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Plan Desciption Bottom Margin', 'deeper' ),
						'param_name' => 'plan_desc_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Price Bottom Margin', 'deeper' ),
						'param_name' => 'price_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Features Bottom Margin', 'deeper' ),
						'param_name' => 'features_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type'       => 'dropdown',
						'heading'    => __( 'Feature List Item Spacing', 'deeper' ),
						'param_name' => 'list_spacing',
						'value'      => array(
							'0px' => 'margin-0',
							'1px' => 'margin-1',
							'2px' => 'margin-2',
							'3px' => 'margin-3',
							'4px' => 'margin-4',
							'5px' => 'margin-5',
							'6px' => 'margin-6',
							'7px' => 'margin-7',
							'8px' => 'margin-8',
							'9px' => 'margin-9',
							'10px' => 'margin-10',
							'11px' => 'margin-11',
							'12px' => 'margin-12',
							'13px' => 'margin-13',
							'14px' => 'margin-14',
							'15px' => 'margin-15',
							'16px' => 'margin-16',
							'17px' => 'margin-17',
							'18px' => 'margin-18',
							'19px' => 'margin-19',
							'20px' => 'margin-20',
						),
						'std'		=> 'margin-0',
						'group' => __( 'Spacing', 'deeper' ),
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            // Extra Class
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
		            ),
		        )
		    );
		}
	}
}

new Deeper_Price_Box_Shortcode;