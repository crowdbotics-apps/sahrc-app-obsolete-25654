<?php
/**
 * List shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_List_Shortcode' ) ) {

	class Deeper_List_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_list', array( 'Deeper_List_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_list', array( 'Deeper_List_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			$args = extract( shortcode_atts( array(
				// Icon
				'icon_image' => '',
				'icon_image_width' => '',

				'icon_text' => '',

				'icon' => '',
				'icon_type' => '',
				'icon_font_size' => '',
				'icon_width' => '',
				'icon_height' => '',
				'icon_line_height' => '',
				'icon_rounded' => '',

				'icon_color' => '',
				'icon_background' => '',
				'icon_border_width' => '',
				'icon_border_style' => 'solid',
				'icon_border' => '',
				'icon_margin'	=> '0px',

				// Control
				'icon_pos'	=> '',
				'content_padding_left'	=> '',
				'content_margin_bottom'	=> '',
				'title_margin_bottom'	=> '',
				'class'	=> '',

				// Content
				'title_color' => '',
				'desc_color' => '',
			    'list_item' => '',

			    // Typography
			    'title_font_size' 	=> '',
			    'title_line_height' 	=> '',
			    'title_font_family' 	=> '',
				'title_font_weight' 	=> '',
				'title_letter_spacing' => '',
				'title_margin_bottom'  => '',
				'desc_font_size' 	=> '',
				'desc_line_height' 	=> '',
				'desc_font_family' 	=> '',
				'desc_font_weight' 	=> '',
				'desc_letter_spacing' => '',

			    //Animation
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );
			$accent = deeper_get_accent_color();
			$list_html = $item_css = $cls = '';
			$title_html = $desc_html = $title_css = $desc_css = $title_cls = $desc_cls = '';
			$icon_html = $icon = $icon_css = $icon_cls = $icon_data = $icon_string = '';
			$data = '';
			$css = '';
			
			$icon_string = deeper_get_shortcode( 'deeper_icon', $atts, 'icon' );	

			$cls = $icon_pos . ' ' . $class;

			// List Item
			$list_item = vc_param_group_parse_atts( $atts['list_item'] );
			if ( $content_padding_left ) $item_css .= 'padding-left:' . intval( $content_padding_left ) . 'px;';		
			if ( $content_margin_bottom ) $item_css .= 'margin-bottom:' . intval( $content_margin_bottom ) . 'px;';				

			foreach ( $list_item as $key=>$item ) {
				$title = $desc = '';
				if ( isset( $item['list_title'] ) ) $title = $item['list_title'];
				if ( isset( $item['list_desc'] ) ) $desc = $item['list_desc'];

				// Title
				if ( $title ) {
					if ( $title_color == $accent ) {
						$title_cls = 'accent-color';
					} elseif ( $title_color ) {
						$title_css .= 'color:' . $title_color . ';';
					} 

					if ( $title_margin_bottom ) $title_css .= 'margin-bottom:' . $title_margin_bottom . ';';
					if ( $title_font_size ) $title_css .= 'font-size:'. intval( $title_font_size ) .'px;';
					if ( $title_font_weight ) $title_css .= 'font-weight:'. intval( $title_font_weight ) .';';
					if ( $title_line_height ) $title_css .= 'line-height:'. intval( $title_line_height ) .'px;';
					if ( $title_letter_spacing ) $title_css .= 'letter-spacing:'. $title_letter_spacing . 'px;';
					if ( $title_font_family ) {
						deeper_enqueue_google_font( $title_font_family );
						$css .= 'font-family:'. $title_font_family .';';
					}

					$title_html = sprintf( 
						'<h4 class="title %3$s" style="%2$s %4$s">%1$s</h4>',
						$title,
						$title_css,
						$title_cls,
						$css
					);
				}

				// Description
				if ( $desc ) {
					if ( $desc_color == $accent ) {
						$desc_cls = 'accent-color';
					} elseif ( $desc_color ) {
						$desc_css .= 'color:' . $desc_color . ';';
					}

					if ( $desc_color ) $desc_css .= 'color:' . $desc_color . ';';
					if ( $desc_font_size ) $desc_css .= 'font-size:'. intval( $desc_font_size ) .'px;';
					if ( $desc_font_weight ) $desc_css .= 'font-weight:'. intval( $desc_font_weight ) .';';
					if ( $desc_line_height ) $desc_css .= 'line-height:'. intval( $desc_line_height ) .'px;';
					if ( $desc_letter_spacing ) $desc_css .= 'letter-spacing:'. $desc_letter_spacing . 'px;';

					if ( $desc_font_family ) {
						deeper_enqueue_google_font( $desc_font_family );
						$css .= 'font-family:'. $desc_font_family .';';
					}

					$desc_html = sprintf(
						'<div class="desc" style="%2$s">%1$s</div>', 
						$desc,
						$desc_css,
						$desc_cls
					);
				}

				$list_html .= sprintf(
					'<li class="list-item" style="%4$s">
						%1$s
						<div class="content-wrap">
							%2$s
							%3$s
						</div>
					</li>',
					do_shortcode( $icon_string ),
					$title_html,
					$desc_html,
					$item_css
				);	
			}

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			return sprintf(
				'<div class="list-wrap">
					<ul class="deeper-list %1$s" %3$s>
						%2$s
					</ul>
				</div>',
				$cls,
				$list_html,
				$data
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'List', 'deeper' ),
		        'description' => __( 'Empty space with custom height.', 'deeper' ),
		        'base' => 'deeper_list',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/list.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	// Icon
		        	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon to Display', 'deeper' ),
						'param_name' => 'icon_display',
						'value'      => array(
							'Icon Font' => 'icon-font',
							'Icon Image' => 'icon-image',
							'Icon Text' => 'icon-text'
						),
						'std'		=> 'icon-font',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon Position', 'deeper' ),
						'param_name' => 'icon_pos',
						'value'      => array(
							'Top' 		=> 'icon-top',
							'Middle' 	=> 'icon-middle',
						),
						'std'		=> 'icon-top',
					),
			        // Image
					array(
						'type' => 'attach_image',
						'heading' => __( 'Image', 'deeper' ),
						'param_name' => 'icon_image',
						'value' => '',
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Image Width', 'deeper' ),
						'param_name' => 'icon_image_width',
						'value' => '',
						'description'	=> __( 'Example: 100px', 'deeper' ),
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
			        ),
			        // Icon Text
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Text', 'deeper' ),
						'param_name' => 'icon_text',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-text' ),
			        ),
			        // Extra Class
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
		            ),
			       	array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Icon library', 'deeper' ),
						'param_name' => 'icon_type',
						'description' => esc_html__( 'Select icon library.', 'deeper' ),
						'value' => array(
							'' => '',
							esc_html__( 'Basic', 'deeper' ) => 'basic',
							esc_html__( 'Corporate', 'deeper' ) => 'corporate',
							esc_html__( 'Stroke 7 Icons', 'deeper' ) => '7stroke',
							esc_html__( 'FontAwesome', 'deeper' ) => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_basic',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'basic',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'basic',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_corporate',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'corporate',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'corporate',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_7stroke',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => '7stroke',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => '7stroke',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon',
						'settings' => array(
							'emptyIcon' => true,
							'iconsPerPage' => 200,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Icon Font Size', 'deeper' ),
						'param_name' => 'icon_font_size',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
						'description' => esc_html__( 'Default: 16px.', 'deeper' ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Width', 'deeper' ),
						'param_name' => 'icon_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Height', 'deeper' ),
						'param_name' => 'icon_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Line Height', 'deeper' ),
						'param_name' => 'icon_line_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Rounded', 'deeper' ),
						'param_name' => 'icon_rounded',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Color', 'deeper' ),
						'param_name' => 'icon_color',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Background', 'deeper' ),
						'param_name' => 'icon_background',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Border Width', 'deeper' ),
						'param_name' => 'icon_border_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon Border Style', 'deeper' ),
						'param_name' => 'icon_border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Border', 'deeper' ),
						'param_name' => 'icon_border',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Shadow', 'deeper' ),
						'param_name' => 'icon_shadow',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            // List Item Content
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Title Color', 'deeper' ),
						'param_name' => 'title_color',
						'value' => '',
						'group' => esc_html__( 'Content', 'deeper' ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Desciption Color', 'deeper' ),
						'param_name' => 'desc_color',
						'value' => '',
						'group' => esc_html__( 'Content', 'deeper' ),
		            ),
		            array(
						'type' => 'deeper_heading',
						'text' => __( 'Content', 'deeper' ),
						'param_name' => 'deeper_heading_content',
						'value' => '',
						'group' => esc_html__( 'Content', 'deeper' ),
		            ),
			        array(
						'type' => 'param_group',
						'heading' => esc_html__( 'List Item', 'jitsin' ),
						'param_name' => 'list_item',
						'value' => '',
						'group' => esc_html__( 'Content', 'deeper' ),
				        'params' => array(
			                array(
			                    'type' => 'textfield',
			                    'holder' => 'div',
			                    'heading' => esc_html__( 'Title', 'jitsin' ),
			                    'param_name' => 'list_title',
			                    'value' => '',
			                ),
			                array(
			                    'type' => 'textarea',
			                    'heading' => esc_html__( 'Description', 'jitsin' ),
			                    'param_name' => 'list_desc',
			                    'value' => '',
			                ),		            				            
			            ) 
				    ),
				    // Spacing
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon Offset', 'deeper' ),
						'param_name' => 'icon_margin',
						'value'      => array(
							'-10px' 		=> '-10px 0 0',
							'-9px' 			=> '-9px 0 0',
							'-8px' 			=> '-8px 0 0',
							'-7px' 			=> '-7px 0 0',
							'-6px' 			=> '-6px 0 0',
							'-5px' 			=> '-5px 0 0',
							'-4px' 			=> '-4px 0 0',
							'-3px' 			=> '-3px 0 0',
							'-2px' 			=> '-2px 0 0',
							'-1px' 			=> '-1px 0 0',
							'0px' 			=> '0px',
							'1px' 			=> '1px 0 0',
							'2px' 			=> '2px 0 0',
							'3px' 			=> '3px 0 0',
							'4px' 			=> '4px 0 0',
							'5px' 			=> '5px 0 0',
							'6px' 			=> '6px 0 0',
							'7px' 			=> '7px 0 0',
							'8px' 			=> '8px 0 0',
							'9px' 			=> '9px 0 0',
							'10px' 			=> '10px 0 0',
						),
						'std'		=> '0px',
						'group' => __( 'Spacing', 'deeper' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Content: Left Padding', 'deeper' ),
						'param_name' => 'content_padding_left',
						'value' => '',
						'description'	=> __( 'Default: 20px', 'deeper' ),
						'group' => __( 'Spacing', 'deeper' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Content: Margin Bottom', 'deeper' ),
						'param_name' => 'content_margin_bottom',
						'value' => '',
						'description'	=> __( 'Default: 10px', 'deeper' ),
						'group' => __( 'Spacing', 'deeper' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Title: Margin Bottom', 'deeper' ),
						'param_name' => 'title_margin_bottom',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
		            ), 
				    // Typography
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Title: Font Family', 'deeper' ),
						'param_name' => 'title_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Title: Font Weight', 'deeper' ),
						'param_name' => 'title_font_weight',
						'value'      => array(
							'Default'		=> '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> '',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Title: Font Size', 'deeper' ),
						'param_name' => 'title_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Title: Line Height', 'deeper' ),
						'param_name' => 'title_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'deeper_number',
						'heading' => __( 'Title: Letter Spacing', 'deeper' ),
						'param_name' => 'title_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Description: Font Family', 'deeper' ),
						'param_name' => 'desc_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Title: Font Weight', 'deeper' ),
						'param_name' => 'desc_font_weight',
						'value'      => array(
							'Default'		=> '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> '',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Font Size', 'deeper' ),
						'param_name' => 'desc_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Line Height', 'deeper' ),
						'param_name' => 'desc_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'deeper_number',
						'heading' => __( 'Description: Letter Spacing', 'deeper' ),
						'param_name' => 'desc_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				    // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}

	new Deeper_List_Shortcode;
}
