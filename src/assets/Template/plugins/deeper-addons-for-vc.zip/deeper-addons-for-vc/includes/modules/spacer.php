<?php
/**
 * Spacer shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Spacer_Shortcode' ) ) {

	class Deeper_Spacer_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_spacer', array( 'Deeper_Spacer_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_spacer', array( 'Deeper_Spacer_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
			    'desktop' => '100',
			    'mobile' => '60',
			    'smobile' => '60'
			), $atts ) );

			if ( $desktop ) $config['desktop'] = intval( $desktop );
			if ( $mobile ) $config['mobile'] = intval( $mobile );
			if ( $smobile ) $config['smobile'] = intval( $smobile );

			$data = 'data-config=\'' . json_encode( $config ) . '\'';

			return sprintf(
				'<div class="deeper-spacer clearfix" %1$s></div>',
				$data
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Spacer', 'deeper' ),
		        'description' => __( 'Empty space with custom height.', 'deeper' ),
		        'base' => 'deeper_spacer',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/spacer.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => __( 'Desktop: Height', 'deeper' ),
						'param_name' => 'desktop',
						'value' => '100'
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Mobile: Height', 'deeper' ),
						'param_name' => 'mobile',
						'value' => '60'
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Small Mobile: Height', 'deeper' ),
						'param_name' => 'smobile',
						'value' => '60'
			        ),
		        )
		    );
		}
	}

	new Deeper_Spacer_Shortcode;
}
