<?php
/**
 * Contact_Form shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Contact_Form_Shortcode' ) ) {

	class Deeper_Contact_Form_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_contactform', array( 'Deeper_Contact_Form_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_contactform', array( 'Deeper_Contact_Form_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$cls = '';

			extract( shortcode_atts( array(
				'align' => 'align-center',
				'form_id' => '',
				'background' => '',
				'width'	=> '',
				'class' => '',
			), $atts ) );
			$css = '';
			$cls .= ' ' . $background . ' ' . $align;
			if ( $class ) $cls .= ' ' . $class;
			if ( $width ) {
				$css .= 'max-width:' . $width . ';' . ' margin:0 auto;';
			} 

			return sprintf( 
				'<div class="deeper-cf7 %2$s" style="%3$s">%1$s</div>',
				do_shortcode( '[contact-form-7 id="'. $form_id .'"]' ),
				$cls,
				$css
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Contact_Form', 'deeper' ),
		        'description' => __( 'Displays Form Contact.', 'deeper' ),
		        'base' => 'deeper_contactform',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/subscibe.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Alignment', 'deeper' ),
						'param_name' => 'align',
						'value'      => array(
							'Left' => 'align-left',
							'Center' => 'align-center',
							'Right' => 'align-right',
						),
						'std'		=> 'align-center',
					),
			        array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Form', 'deeper' ),
						'param_name' => 'form_id',
						'std' => '',
						'value'      =>  deeper_list_contact_form_7(),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Input Background', 'deeper' ),
						'param_name' => 'background',
						'value'      => array(
							'Default' => '',
							'White' => 'input-white',
						),
						'std'		=> '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Max Width', 'deeper' ),
						'param_name' => 'width',
						'value'      => '',
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Extra Classes', 'deeper' ),
						'param_name' => 'class',
						'value'      => '',
					),
		        )
		    );
		}
	}

	new Deeper_Contact_Form_Shortcode;
}
