<?php
/**
 * News Grid shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_News_Grid_Shortcode' ) ) {
	
	class Deeper_News_Grid_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_newsgrid', array( 'Deeper_News_Grid_Shortcode', 'output' ) );		

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_newsgrid', array( 'Deeper_News_Grid_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$cls = '';
			$date_html = $time_html = $location_html = $title_html = '';

			extract( shortcode_atts( array(
				'items'			=> '6',
				'pagination'	=> '',
				'cat_slug'		=> '',
				'exclude_cat_slug' => '',
				'image_crop'    => 'full',
			    'layout'		=> 'grid',
			    'column'        => '3',
			    'column2'       => '3',
			    'column3'       => '2',
			    'column4'       => '1',
			    'gaph'       => '',
			    'gaph2'       => 'inherit',
			    'gaph3'       => 'inherit',
			    'gaph4'       => 'inherit',
			    'gapv'       => '',
			    'gapv2'       => 'inherit',
			    'gapv3'       => 'inherit',
			    'gapv4'       => 'inherit',
			    'class'		 => '',
			    'linktext'	 => '',
			    // Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$data = $cls = '';

			$config = array();
			$filter = 'filter-' . rand();
			$config['filters'] = '.' . $filter;
			$config['defaultFilter'] = '*';
			$config['animationType'] = 'quicksand';
			$config['showNavigation'] = true;
			$config['showPagination'] = true;
			$config['rewindNav'] = false;
			$config['auto'] = false;
			$config['caption'] = '';
			$config['displayType'] = 'sequentially';
			$config['displayTypeSpeed'] = '100';
			$config['mediaQueries']['0']['width'] = 1500;
			$config['mediaQueries']['1']['width'] = 923;
			$config['mediaQueries']['2']['width'] = 878;
			$config['mediaQueries']['3']['width'] = 675;
			$config['mediaQueries']['4']['width'] = 502;
			$config['mediaQueries']['2']['option']['caption'] = '';
			$config['mediaQueries']['3']['option']['caption'] = '';
			$config['mediaQueries']['4']['option']['caption'] = '';

			if ( $layout == 'grid' ) {
				$config['layoutMode'] = 'grid';
				$config['gridAdjustment'] = 'responsive';
			} else {
				$config['layoutMode'] = 'mosaic';
				$config['gridAdjustment'] = 'default';
			}
			$config['mediaQueries']['0']['cols'] = intval( $column );
			$config['mediaQueries']['1']['cols'] = intval( $column );
			$config['mediaQueries']['2']['cols'] = intval( $column2 );
			$config['mediaQueries']['3']['cols'] = intval( $column3 );
			$config['mediaQueries']['4']['cols'] = intval( $column4 );
			$config['gapHorizontal'] = intval( $gaph );
			$config['gapVertical'] = intval( $gapv );

			if ( $gaph2 == 'inherit' ) $gaph2 == intval( $gaph );
			if ( $gaph3 == 'inherit' ) $gaph3 == intval( $gaph2 );
			if ( $gaph4 == 'inherit' ) $gaph4 == intval( $gaph3 );
			if ( $gapv2 == 'inherit' ) $gaph2 == intval( $gapv );
			if ( $gapv3 == 'inherit' ) $gaph3 == intval( $gapv2 );
			if ( $gapv4 == 'inherit' ) $gaph4 == intval( $gapv3 );

			$config['mediaQueries']['2']['options']['gapHorizontal'] = intval( $gaph2 );
			$config['mediaQueries']['3']['options']['gapHorizontal'] = intval( $gaph3 );
			$config['mediaQueries']['4']['options']['gapHorizontal'] = intval( $gaph4 );
			$config['mediaQueries']['2']['options']['gapVertical'] = intval( $gapv2 );
			$config['mediaQueries']['3']['options']['gapVertical'] = intval( $gapv3 );
			$config['mediaQueries']['4']['options']['gapVertical'] = intval( $gapv4 );

			if ( $config )
				$data = 'data-config=\'' . json_encode( $config ) . '\'';

			if ( get_query_var('paged') ) {
			   $paged = get_query_var('paged');
			} elseif ( get_query_var('page') ) {
			   $paged = get_query_var('page');
			} else {
			   $paged = 1;
			}

			$args = array(
			    'post_type' => 'post',
			    'posts_per_page' => intval( $items ),
			    'paged'     => $paged
			);

			if ( ! empty( $cat_slug ) ) {
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'category',
						'field'    => 'slug',
						'terms'    => $cat_slug
					),
				);
			}

			if ( ! empty( $exclude_cat_slug ) ) {
				$args['tax_query'] = array(
				    array(
				        'taxonomy' => 'category',
				        'field' => 'slug',
				        'terms' => $exclude_cat_slug,
				        'operator' => 'NOT IN'
				    ),
				);
			}		

			$current_post = 0;	

			$query = new WP_Query( $args );
			if ( ! $query->have_posts() ) { esc_html_e( 'Post item not found!', 'deeper' ); return; }

			wp_enqueue_script( 'cubeportfolio' );
			wp_enqueue_script( 'magnificpopup' );

			if ( $class ) $cls .= ' ' . $class;
			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			ob_start(); 
			if ( $query->have_posts() ) : ?>
				<div class="deeper-cubeportfolio deeper-news-grid <?php echo esc_attr( $cls ); ?>" <?php echo $data; ?> data-inviewport="yes">
                    <div class="cube-galleries cbp">
                    	<?php while ( $query->have_posts() ) : $query->the_post(); ?>
                    		<div class="cbp-item">
                    			<article id="post-<?php the_ID(); ?>" 
                    				class="news-box">
                    				<?php 
                    				// Post Thumbnail
                					echo '<div class="thumb">' . 
                						get_the_post_thumbnail( get_the_ID(), $image_crop ) . 
                						'</div>'; ?>
                    			
                    				<div class="texts">
                						<h2 class="title">
                							<a href="<?php the_permalink(); ?>">
                								<?php 
                								if ( worksquare_metabox( 'post-desc' ) ) {
                									echo esc_attr( worksquare_metabox( 'post-desc' ) );
                								} else {
                									the_title();
                								}
                								?>
                							</a>
                						</h2>

                						<div class="meta-wrap">
                							<?php 
                							$categories = get_the_category();
                							$cat_string = array();

                							foreach ($categories as $key => $cat) {
                								$cat_string[] = sprintf( '<span class="cat-item"><a href="%2$s">%1$s</a></span>',
                								 	$cat->cat_name,
                								 	get_category_link( $cat->cat_ID )
                								);
                							}

                							echo implode( '<span class="sep"> / </span>', $cat_string );

                							?>
                							<!-- <span class="post-date"><?php the_date(); ?></span> -->
                						</div>

                						<?php
                						if ( $linktext ) {
                							echo '<a class="post-link" href="' . esc_url( get_the_permalink( get_the_ID() ) ) . '">' .
                								esc_attr( $linktext ) . '</a>';
                						}
                						?>
                    				</div>
                    			</article>
		                    </div><!-- /.cbp-item -->
                    	<?php endwhile; ?>
			        </div><!-- /#galleries -->
				</div><!-- /.deeper-cubeportfolio -->
				
				<?php if ( 'true' == $pagination ) {
					echo '<div class="project-nav">';
					worksquare_pagination($query);
					echo '</div>';
				} ?>
			<?php endif; wp_reset_postdata(); 
			$return = ob_get_clean();
			return $return;
		}

		// Map shortcode to VC
		public static function map() {		

		    return array( 
		    	'name' => __( 'News Grid', 'deeper' ),
				'description' => __( 'Displays News in responsive grid.', 'deeper' ),
				'base' => 'deeper_newsgrid',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/news.png', __FILE__ ),
				'category' => __( 'Deeper Addons', 'deeper' ),
				'params' => array(
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Enable Pagination?', 'deeper' ),
						'param_name' => 'pagination',
						'value'      => array(
							'No' => '',
							'Yes' => 'true',
						),
						'std'		=> '',
					),
			        array(
						'type'       => 'dropdown',
						'heading'    => __( 'Image Cropping', 'deeper' ),
						'param_name' => 'image_crop',
						'value'      => array(
							'Full' => 'full',
							'670 x 484' => 'deeper-std1',
							'670 x 340' => 'deeper-std2',
							'570 x 340' => 'deeper-std3',
							'535 x 650' => 'deeper-std4',
						),
						'std'		=> 'full',
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Posts Per Page', 'deeper' ),
						'param_name' => 'items',
						'value' => '6',
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Category Slug (Optional)', 'deeper' ),
						'param_name' => 'cat_slug',
						'value' => '',
						'description'	=> __( 'Displaying posts that have this category. Using category-slug.', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Exclude Category Slug (Optional)', 'deeper' ),
						'param_name' => 'exclude_cat_slug',
						'value' => '',
						'description'	=> __( 'Exclude posts that have this category. Using category-slug.', 'deeper' ),
			        ),		
			        // CubePortfolio Controls
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Layout', 'deeper' ),
						'param_name' => 'layout',
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
						'value'      => array(
							'Responsive Grid' => 'grid',
							'Mosaic' => 'mosaic',
						),
						'std'		=> 'grid',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Screen > 1024px', 'deeper' ),
						'param_name' => 'column',
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
						'value'      => array(
							'1 Column' => '1',
							'2 Columns' => '2',
							'3 Columns' => '3',
							'4 Columns' => '4',
						),
						'std'		=> '3',
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Vertical Spacing', 'deeper' ),
						'param_name' => 'gapv',
						'value' => '',
						'description'	=> __( 'Ex: 30.', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Horizontal Spacing', 'deeper' ),
						'param_name' => 'gaph',
						'value' => '',
						'description'	=> __( 'Ex: 30.', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Screen from 991px to 1024px', 'deeper' ),
						'param_name' => 'column2',
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
						'value'      => array(
							'1 Column' => '1',
							'2 Columns' => '2',
							'3 Columns' => '3',
						),
						'std'		=> '3',
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Vertical Spacing', 'deeper' ),
						'param_name' => 'gapv2',
						'value' => 'inherit',
						'description'	=> __( 'Ex: 30. Default: inherit from bigger', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Horizontal Spacing', 'deeper' ),
						'param_name' => 'gaph2',
						'value' => 'inherit',
						'description'	=> __( 'Ex: 30. Default: inherit from bigger', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Screen from 768px to 991px', 'deeper' ),
						'param_name' => 'column3',
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
						'value'      => array(
							'1 Column' => '1',
							'2 Columns' => '2',
							'3 Columns' => '3',
						),
						'std'		=> '2',
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Vertical Spacing', 'deeper' ),
						'param_name' => 'gapv3',
						'value' => 'inherit',
						'description'	=> __( 'Ex: 30. Default: inherit from bigger', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Horizontal Spacing', 'deeper' ),
						'param_name' => 'gaph3',
						'value' => 'inherit',
						'description'	=> __( 'Ex: 30. Default: inherit from bigger', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Screen < 768px', 'deeper' ),
						'param_name' => 'column4',
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
						'value'      => array(
							'1 Column' => '1',
							'2 Columns' => '2',
							'3 Columns' => '3',
						),
						'std'		=> '1',
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Vertical Spacing', 'deeper' ),
						'param_name' => 'gapv4',
						'value' => 'inherit',
						'description'	=> __( 'Ex: 30. Default: inherit from bigger', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Horizontal Spacing', 'deeper' ),
						'param_name' => 'gaph4',
						'value' => 'inherit',
						'description'	=> __( 'Ex: 30. Default: inherit from bigger', 'deeper' ),
						'group'      => __( 'CubePortfolio Controls', 'deeper' ),
			        ),
					array(
						'type' => 'textfield',
						'heading' => __( 'Link Text', 'deeper' ),
						'param_name' => 'linktext',
						'value' => '',
						'description'	=> __( 'Require to show Link.', 'deeper' ),
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				  	array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
			        ),
        		)
			);
		}
	}
}

new Deeper_News_Grid_Shortcode;
