<?php
/**
 * Tabs shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_tabs extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Tabs_Shortcode' ) ) {

	class Deeper_Tabs_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_tabs', array( 'Deeper_Tabs_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_tabs', array( 'Deeper_Tabs_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract(shortcode_atts(array(
	            'class' => '',
	            // Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
	        ), $atts));
	        $data = '';
	        $cls = ' ' . $class;
	     	
	     	//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

	     	return sprintf(
	     		'<div class="deeper-adv-tabs %1$s" %3$s>
		            <div class="tab-title"></div>

		            <div class="tab-content-wrap">
		            	%2$s
		            </div>                			
		    	</div>',
		    	$cls,
		    	do_shortcode( $content ),
		    	$data 
		    );
				
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
	        	"name" => esc_html__("Advanced Tabs", 'deeper'),
				'base' => 'tabs',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/tabs.png', __FILE__ ),
				'as_parent' => array('only' => 'deeper_tab'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
				'params' => array(
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				  	array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
			        ),
				),
		    );
		}
	}
}

new Deeper_Tabs_Shortcode;