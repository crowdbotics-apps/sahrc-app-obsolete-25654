<?php
/**
 * Button shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Button_Shortcode' ) ) {

	class Deeper_Button_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_button', array( 'Deeper_Button_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_button', array( 'Deeper_Button_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(
				// General
				'button_align'			=> 'align-left',
				'button_style'			=> 'button-accent',
				'button_size'			=> 'medium',
				'button_text' 			=> 'Read More',
				'button_url' 			=> '',
				'button_margin' 		=> '',
				'button_extra'			=> '',

				// Custom 
				'button_padding' 		=> '',
				'button_rounded' 		=> '',
				'button_text_color'	 	=> '',
				'button_background' 	=> '',
			    'button_border_width' 	=> '',
			    'button_border_style' 	=> 'solid',
				'button_border' 		=> '',
				'button_shadow' 		=> '',
				'button_text_hover' 	=> '',
				'button_background_hover' => '',
				'button_border_hover' 	=> '',
				'button_shadow_hover' 	=> '',
				'button_parent_hover' 	=> '',

				// Typography
				'button_font_family' 	=> '',
				'button_font_weight' 	=> '',
				'button_font_size' 		=> '',
				'button_line_height' 	=> '',
				'button_letter_spacing' 	=> '',

				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );
			
			// Init
			$config = array();
			$cls = $css = $data = '';
			$url_atts = $url_cls = $url_css = '';

			if ( $button_url && $button_text ) {
				// Style + Size + Id + align
				$cls = $button_style . ' ' . $button_size;
				if ( $button_align ) $url_cls .= ' ' . $button_align;
				if ( $button_extra ) $url_cls .= ' ' . $button_extra;

				// RUL
				if ( $button_url ) {
					$url = vc_build_link( $button_url );
					if ( $url['url'] ) $url_atts .= 'href=' . esc_url( $url['url'] );
					if ( $url['target'] ) $url_atts .= ' target=' . esc_attr( $url['target'] );
					if ( $url['title'] ) $url_atts .= ' title="' . sanitize_html_class( $url['title'] ) . '"';
				}
				
				// Typography
				if ( $button_font_weight ) $url_css .= 'font-weight:' . $button_font_weight . ';';
				if ( $button_font_size ) $url_css .= 'font-size:' . intval( $button_font_size ) . 'px;';
				if ( $button_line_height ) $url_css .= 'line-height:' . intval( $button_line_height ) . 'px;';
				if ( $button_letter_spacing ) $url_css .= 'letter-spacing:' . $button_letter_spacing . 'px;';
				if ( $button_font_family ) {
					deeper_enqueue_google_font( $button_font_family );
					$url_css .= 'font-family:' . $button_font_family . ';';
				}

				// Custom Style
				if ( $button_text_color ) $config['color'] = $button_text_color;
				if ( $button_background ) $config['bg'] = $button_background;
				if ( $button_padding ) $config['padding'] = $button_padding;
				if ( $button_margin ) $config['margin'] = $button_margin;
			    if ( $button_rounded ) $config['rounded'] = $button_rounded;
			    if ( $button_shadow ) $config['shadow'] = $button_shadow;
			    if ( $button_border_width ) 
			        if ( $button_border ) 
			        	$config['border'] = intval( $button_border_width ) . 'px ' . $button_border_style . ' ' . $button_border;

			    // Custom Hover
			    if ( $button_border_hover ) 
			    	$config['borderHover'] = intval( $button_border_width ) . 'px ' . $button_border_style . ' ' . $button_border_hover;
				if ( $button_text_hover ) $config['colorHover'] = $button_text_hover;
				if ( $button_background_hover ) $config['bgHover'] = $button_background_hover;
				if ( $button_shadow_hover ) $config['shadowHover'] = $button_shadow_hover;
				
				if ( $button_parent_hover ) $config['parentHover'] = $button_parent_hover;

				if ( $config ) {
					$data = 'data-config=\'' . json_encode( $config ) . '\'';
					$cls .= ' btn-' . rand();
				}
				
				//Animation
				if ( $animation ) {
				    $cls .= ' wow '. $animation_effect;
				    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
				} 
			
				return sprintf( 
					'<div class="url-wrap %6$s">
						<a class="deeper-button %1$s" style="%2$s" %4$s %5$s>%3$s</a>
					</div>',
					$cls,
					$css,
					esc_html( $button_text ),
					esc_attr( $url_atts ),
					$data,
					$url_cls
				);	
			}
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => __( 'Button', 'deeper' ),
		        'description' => __( 'Displays custom button.', 'deeper' ),
				'base' => 'deeper_button',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/buttons.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
				'params' => array(	
					array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'button_align',
						'value' => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'align-left'
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Style', 'deeper' ),
						'param_name' => 'button_style',
						'value' => array(
							'Accent' 	=> 'button-accent',
							'Outline Accent' 	=> 'outline-accent',
							'Radical Red' 		=> 'button-radical-red',			
							'Outline Radical Red' 		=> 'outline-radical-red',			
							'Blue' 		=> 'button-blue',			
							'Outline Blue' 		=> 'outline-blue',
							'Green' 		=> 'button-green',			
							'Outline Green' 		=> 'outline-green',	
							'White' 		=> 'button-white',			
							'Custom' 			=> 'custom',
						),
						'std'		=> 'button-accent'
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Size', 'deeper' ),
						'param_name' => 'button_size',
						'value' => array(
							'Small' 		=> 'small',
							'Medium' 		=> 'medium',
							'Big' 			=> 'big',
							'Extra Big' 	=> 'extra-big',
						),
						'std'		=> 'medium'
					),	
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'button_text',
						'value' => 'Read More',
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'button_url',
						'value' => '',
			        ),
			        // Custom
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Custom Button', 'deeper' ),
						'param_name' => 'deeper_heading',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Padding', 'deeper' ),
						'param_name' => 'button_padding',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left.', 'deeper' ),
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Rounded', 'deeper' ),
						'param_name' => 'button_rounded',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Text Color', 'deeper' ),
						'param_name' => 'button_text_color',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Background', 'deeper' ),
						'param_name' => 'button_background',
						'value' => '#eeeeee',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Border Width', 'deeper' ),
						'param_name' => 'button_border_width',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Button Border Style', 'deeper' ),
						'param_name' => 'button_border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
					),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Border', 'deeper' ),
						'param_name' => 'button_border',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Shadow', 'deeper' ),
						'param_name' => 'button_shadow',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Button Hover', 'deeper' ),
						'param_name' => 'deeper_heading_hover',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
					),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Text: Hover', 'deeper' ),
						'param_name' => 'button_text_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Background: Hover', 'deeper' ),
						'param_name' => 'button_background_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Border: Hover', 'deeper' ),
						'param_name' => 'button_border_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Shadow: Hover', 'deeper' ),
						'param_name' => 'button_shadow_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'button_parent_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-icon-box', 'deeper' ),
			        ),
			        // Spacing 
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Spacing', 'deeper' ),
						'param_name' => 'deeper',
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Margin', 'deeper' ),
						'param_name' => 'button_margin',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 0px 0px', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'button_extra',
						'value' => '',
			        ),
			        // Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Button', 'deeper' ),
						'param_name' => 'button_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Button: Font Family', 'deeper' ),
						'param_name' => 'button_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Button: Font Weight', 'deeper' ),
						'param_name' => 'button_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Font Size', 'deeper' ),
						'param_name' => 'button_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Line Height', 'deeper' ),
						'param_name' => 'button_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Button: Letter Spacing', 'deeper' ),
						'param_name' => 'button_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				)
			);
		}
	}

	new Deeper_Button_Shortcode;
}