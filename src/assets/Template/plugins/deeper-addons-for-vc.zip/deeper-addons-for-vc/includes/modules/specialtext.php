<?php
/**
 * Single Special Text shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Special_Text_Shortcode' ) ) {

	class Deeper_Special_Text_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'special_text_text', array( 'Deeper_Special_Text_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'special_text_text', array( 'Deeper_Special_Text_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$html = $cls = $css = $data = '';
			$text_css = $text_cls = '';
			$line_html = $line_cls = $line_css = '';

			extract( shortcode_atts( array(
				'text_style' => 'style-1',
				'text_align' => 'align-center',
			    'text_color' => '',
				'text_width' => '',
				'line_width' => '',
				'line_height' => '',
				'line_color' => '',
				'text_extra' => '',

				'text_tag' => 'h2',
				'text_font_size' => '',
				'text_line_height' => '',
				'text_font_family' => '',
				'text_font_weight' => '',
				'text_letter_spacing' => '',

			    'text_padding' => '',
			    'text_margin' => '',
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			if ( $content ) {
				$content = wpb_js_remove_wpautop( $content, true );
				// Change <p> tag to <span>
				$content = str_replace( '<p>', '<span>', $content );
				$content = str_replace( '</p>', '</span>', $content );
				
				$accent = deeper_get_accent_color();

				$cls .= $text_style . ' ' . $text_align . ' ' . $text_extra;

				// Typography
				if ( $text_font_size ) $text_css .= 'font-size:'. intval( $text_font_size ) .'px;';
				if ( $text_font_weight ) $text_css .= 'font-weight:'. intval( $text_font_weight ) .';';
				if ( $text_line_height ) $text_css .= 'line-height:'. intval( $text_line_height ) .'px;';
				if ( $text_letter_spacing ) $text_css .= 'letter-spacing:'. $text_letter_spacing . 'px;';

				if ( $text_margin ) $css .= 'margin:' . $text_margin . ';';
				if ( $text_padding ) $text_css .= 'padding:' . $text_padding . ';';

				if ( $text_color == $accent ) {
					$text_cls .= ' color-accent';
				} elseif ( $text_color ) {
					$text_css .= 'color:' . $text_color . ';';
				}

				if ( $text_width ) $text_css .= 'max-width:' . $text_width . ';';

				// Line
				if ( $line_color == $accent ) {
					$line_cls .= ' bg-accent';
				} elseif ( $line_color ) {
					$line_css .= 'background-color:' . $line_color . ';';
				}

				if ( $line_width ) $line_css .= 'width:' . intval( $line_width ) . 'px;';
				if ( $line_height ) $line_css .= 'height:' . intval( $line_height ) . 'px;';

				if ( $text_style == 'style-2' ) {
					// Make line midde 
					if ( $line_height ) $line_css .= 'margin-top:-' . intval( $line_height ) / 2 . 'px;';
					$line_html = sprintf(
						'<span class="line-1 %2$s" style="%1$s"></span>
						<span class="line-2 %2$s" style="%1$s"></span>', 
						$line_css,
						$line_cls
					);
				} else {
					$line_html .= sprintf(
						'<span class="line %2$s" style="%1$s"></span>',
						$line_css,
						$line_cls
					);
				}

				//Animation
				if ( $animation ) {
				    $cls .= ' wow '. $animation_effect;
				    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
				}

				return sprintf(
					'<div class="deeper-special-text %2$s" style="%3$s" %9$s data-inviewport="yes">
						<div class="inner">
							<%8$s class="text %6$s" style="%5$s">%4$s</%8$s>
							%7$s
						</div>
					</div>',
					$html,
					$cls,
					$css,
					$content,
					$text_css,
					$text_cls,
					$line_html,
					$text_tag,
					$data
				);
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
				'name'        => __( 'Special Text', 'deeper' ),
		        'description' => __( 'Special text with some styles', 'deeper' ),
				'base'        => 'singletext',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/headings.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
				'params'      => array(
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'text_style',
						'value'      => array(
							'Style 1' => 'style-1',
							'Style 2' => 'style-2',
							'Style 3' => 'style-3',
							'Style 4' => 'style-4',
							'Style 5' => 'style-5',
						),
						'std'		=> 'style-1',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'text_align',
						'value'      => array(
							'Left' 		=> 'align-left',
							'Center' 	=> 'align-center',
							'Right'		=> 'align-right',
						),
						'std'		=> 'align-center',
						'dependency' => array( 'element' => 'style', 'value' => 'style-1' ),
					),
					array(
						'type' => 'colorpicker',
						'heading' => __( 'Text Color', 'deeper' ),
						'param_name' => 'text_color',
						'value' => '',
		            ),
					array(
						'type' => 'textarea_html',
						'holder' => 'div',
						'heading' => __( 'Text', 'deeper' ),
						'param_name' => 'content',
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Text Max Width', 'deeper' ),
						'param_name' => 'text_width',
						'value' => '',
						'description'	=> __( 'Example: 800px', 'deeper' ),
		            ),
		            // Line
		            array(
						'type' => 'deeper_heading',
						'text' => __( 'Line', 'deeper' ),
						'param_name' => 'deeper_heading_line',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Line Width', 'deeper' ),
						'param_name' => 'line_width',
						'value' => '',
						'description'	=> __( 'Example: 100px', 'deeper' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Line Height', 'deeper' ),
						'param_name' => 'line_height',
						'value' => '',
						'description'	=> __( 'Default: 2px', 'deeper' ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Line Color', 'deeper' ),
						'param_name' => 'line_color',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Text Extra Class', 'deeper' ),
						'param_name' => 'text_extra',
						'value' => '',
		            ),
			        // Typography
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Font Family', 'deeper' ),
						'param_name' => 'text_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Text Tag', 'deeper' ),
						'param_name' => 'text_tag',
						'value'      => array(
							'H1' => 'h1',
							'H2' => 'h2',
							'H3' => 'h3',
							'H4' => 'h4',
							'H5' => 'h5',
							'H6' => 'h6',
							'Div' => 'div',
							'Span' => 'span',
						),
						'std'		=> 'h2',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Text: Font Weight', 'deeper' ),
						'param_name' => 'text_font_weight',
						'value'      => array(
							'Default'		=> '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> '',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Text: Font Size', 'deeper' ),
						'param_name' => 'text_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Text: Line Height', 'deeper' ),
						'param_name' => 'text_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'deeper_number',
						'heading' => __( 'Text: Letter Spacing', 'deeper' ),
						'param_name' => 'text_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
			        // Spacing
			        array(
						'type' => 'textfield',
						'heading' => __( 'Text Padding', 'deeper' ),
						'param_name' => 'text_padding',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'description'	=> __( 'Top Right Bottom Left.', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Margin', 'deeper' ),
						'param_name' => 'text_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'description'	=> __( 'Top Right Bottom Left.', 'deeper' ),
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				)
		  );
		}
	}
}

new Deeper_Special_Text_Shortcode;
