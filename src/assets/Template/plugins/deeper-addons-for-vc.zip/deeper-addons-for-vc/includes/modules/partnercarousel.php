<?php
/**
 * PartnerCarousel shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_PartnerCarousel_Shortcode' ) ) {

	class Deeper_PartnerCarousel_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_partnercarousel', array( 'Deeper_PartnerCarousel_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_partnercarousel', array( 'Deeper_PartnerCarousel_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
				'items'			=> '6',
				'cat_slug'		=> '',
				'exclude_cat_slug' => '',
				'gap'			=> '0',
				'autoplay' => 'false',
				'center' => 'left',
				'autoplay_speed' => 3000,
			    'fullaside' => 'false',
			    'loop' => '',
			    'groupcell' => 'false',
				
				'column' => '3',
				'column2' => '2',
				'column3' => '2',
				'column4' => '1',
				
				'class'	=> '',
				// Arrows
				'show_arrows' => '',
				'arrowsvg' => 'svg1',
				'arrows_position' => 'middle',
				'arrows_size' => 'arrows-medium',
				'arrows_offset' => 'arrow-offset-0',
				// Bullets
				'show_bullets' => '',
				'bullets_offset' => 'bullet-offset-0',
				'bullets_pos' => 'bullet-center',
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$args = array(
			    'post_type' => 'partner',
			    'posts_per_page' => intval( $items )
			);

			if ( ! empty( $cat_slug ) ) {
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'partner_category',
						'field'    => 'slug',
						'terms'    => $cat_slug
					),
				);
			}

			if ( ! empty( $exclude_cat_slug ) ) {
				$args['tax_query'] = array(
				    array(
				        'taxonomy' => 'partner_category',
				        'field' => 'slug',
				        'terms' => $exclude_cat_slug,
				        'operator' => 'NOT IN'
				    ),
				);
			}

			$query = new WP_Query( $args );
			if ( ! $query->have_posts() ) { esc_html_e( 'Partner item not found!', 'deeper' ); return; }

			$cls = ' column-' . $column . ' column2-' . $column2 . ' column3-' . $column3 . ' column4-' . $column4 .  ' gap-' . $gap;
			if ( $class ) $cls .= ' ' . $class;

			$config['cellAlign'] = $center;
			$config['autoPlay'] = $autoplay == 'true' ? abs( (int) $autoplay_speed ) : false;
			$config['fullAside'] = $fullaside == 'true' ? true : false;
			$config['wrapAround'] = $loop == 'true' ? true : false;
			$config['groupCells'] = $groupcell == 'true' ? true : false;
			
			// Arrows
			if ( $show_arrows ) {
				$cls .= ' has-arrows arrow-' . $arrows_position . ' ' . $arrows_offset . ' ' . $arrows_size;
				$config['prevNextButtons'] = true;
				$config['arrowShapeStyle'] = $arrowsvg;
			}

			// Bullets
			if ( $show_bullets ) {
				$cls .= ' has-bullets ' . $bullets_offset . ' ' . $bullets_pos;
				$config['pageDots'] = true;
			}

			if ( $config )
				$data = 'data-config=\'' . json_encode( $config ) . '\'';

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			wp_enqueue_script( 'flickity' );
			ob_start(); ?>

			<div class="deeper-carousel-box <?php echo $cls; ?>" <?php echo $data; ?>>
				<?php if ( $query->have_posts() ) : ?>
					<?php while ( $query->have_posts() ) : $query->the_post(); ?>
						<div class="deeper-partner">
							<?php

							printf( '<div class="partner-logo"><a href="%2$s">%1$s</a></div>',
								get_the_post_thumbnail( get_the_ID() ),
								esc_url( worksquare_metabox( 'partner_hyperlink' ) ) 
							);
							?>
						</div><!-- /.deeper-partner -->
					<?php endwhile; ?>
				<?php endif; wp_reset_postdata(); ?>
			</div><!-- /.deeper-carousel-box -->

			<?php
			return ob_get_clean();
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => esc_html__('Partner Carousel', 'deeper'),
				'base' => 'partnercarousel',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/partner.png', __FILE__ ),
				'category' => esc_html__('Deeper Addons', 'deeper'),
			    'params' => array(
			    	array(
						'type' => 'textfield',
						'heading' => esc_html__( 'Posts Per Page', 'deeper' ),
						'param_name' => 'items',
						'value' => '6',
		            ), 
		            array(
						'type' => 'textfield',
						'heading' => __( 'Category Slug (Optional)', 'deeper' ),
						'param_name' => 'cat_slug',
						'value' => '',
						'description'	=> __( 'Displaying posts that have this category. Using category-slug.', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Exclude Category Slug (Optional)', 'deeper' ),
						'param_name' => 'exclude_cat_slug',
						'value' => '',
						'description'	=> __( 'Exclude posts that have this category. Using category-slug.', 'deeper' ),
			        ),           
			        array(
						'type'       => 'dropdown',
						'heading'    => __( 'Spacing between Items', 'deeper' ),
						'param_name' => 'gap',
						'value'      => array(
							'0px' => '0',
							'1px' => '1',
							'5px' => '5',
							'10px' => '10',
							'15px' => '15',
							'20px' => '20',
							'30px' => '30',
							'40px' => '40',
							'50px' => '50',
							'100px' => '100',
						),
						'std'		=> '0',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Auto Play?', 'deeper' ),
						'param_name' => 'autoplay',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Auto Play Speed', 'deeper' ),
						'param_name' => 'autoplay_speed',
						'value' => '3000',
						'dependency' => array( 'element' => 'autoplay', 'value' => 'true' ),
		            ),      
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Full Aside?', 'deeper' ),
						'param_name' => 'fullaside',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Center Mode?', 'deeper' ),
						'param_name' => 'center',
						'value'      => array(
							'No' => 'left',
							'Yes' => 'center',
						),
						'std'		=> 'left',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Infinity Loop?', 'deeper' ),
						'param_name' => 'loop',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
						'description'	=> __( 'Duplicate last and first items to get loop illusion.', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Group Cell?', 'deeper' ),
						'param_name' => 'groupcell',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
						'description'	=> __( 'Groups cells together in slides. Flicking, page dots, and previous/next buttons are mapped to group slides, not individual cells.', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
		            ),
		            // Controls
		            array(
						'type' => 'deeper_heading',
						'text' => __( 'Arrows', 'deeper' ),
						'param_name' => 'deeper_heading_arrow',
						'group' => __( 'Controls', 'deeper' ),
		            ),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Arrows?', 'deeper' ),
						'param_name' => 'show_arrows',
						'group' => __( 'Controls', 'deeper' ),
						'value'      => array(
							'No' => '',
							'Yes' => 'yes',
						),
						'std'		=> '',
					),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrow Style?', 'deeper' ),
						'param_name' => 'arrowsvg',
						'value'      => array(
							'Style 1' => 'svg1',
							'Style 2' => 'svg2',
							'Style 3' => 'svg3',
						),
						'std'		=> 'svg1',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Position', 'deeper' ),
						'param_name' => 'arrows_position',
						'value'      => array(
							'Middle' => 'middle',
							'Top' => 'top',
						),
						'std'		=> 'middle',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Size', 'deeper' ),
						'param_name' => 'arrows_size',
						'value'      => array(
							'Small' => 'arrows-small',
							'Medium' => 'arrows-medium',
							'Big' => 'arrows-big',
						),
						'std'		=> 'arrows-medium',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Offset', 'deeper' ),
						'param_name' => 'arrows_offset',
						'value'      => array(
							'0px' 	=> 'arrow-offset-0',
							'10px' 	=> 'arrow-offset-10',
							'20px' 	=> 'arrow-offset-20',
							'30px' 	=> 'arrow-offset-30',
							'40px' 	=> 'arrow-offset-40',
							'50px' 	=> 'arrow-offset-50',
							'60px' 	=> 'arrow-offset-60',
							'70px' 	=> 'arrow-offset-70',
							'80px' 	=> 'arrow-offset-80',
							'90px' 	=> 'arrow-offset-90',
							'100px' 	=> 'arrow-offset-100',
						),
						'std'		=> 'arrow-offset-0',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'arrows_position', 'value' => 'top' )
					),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Bullets', 'deeper' ),
						'param_name' => 'deeper_heading_bullets',
						'group' => __( 'Controls', 'deeper' ),
		            ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Bullets?', 'deeper' ),
						'param_name' => 'show_bullets',
						'group' => __( 'Controls', 'deeper' ),
						'value'      => array(
							'No' => '',
							'Yes' => 'yes',
						),
						'std'		=> '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Bullets Position', 'deeper' ),
						'param_name' => 'bullets_pos',
						'value'      => array(
							'Left' 		=> 'bullet-left',
							'Center' 	=> 'bullet-center',
							'Right' 	=> 'bullet-right',
						),
						'std'		=> 'bullet-center',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_bullets', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Bullets Offset', 'deeper' ),
						'param_name' => 'bullets_offset',
						'value'      => array(
							'0px' 	=> 'bullet-offset-0',
							'10px' 	=> 'bullet-offset-10',
							'20px' 	=> 'bullet-offset-20',
							'30px' 	=> 'bullet-offset-30',
							'40px' 	=> 'bullet-offset-40',
							'50px' 	=> 'bullet-offset-50',
							'60px' 	=> 'bullet-offset-60',
							'70px' 	=> 'bullet-offset-70',
							'80px' 	=> 'bullet-offset-80',
							'90px' 	=> 'bullet-offset-90',
							'100px' 	=> 'bullet-offset-100',
						),
						'std'		=> 'bullet-offset-0',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_bullets', 'value' => 'yes' )
					),
					// Column
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Desktop ( > 1024px )', 'deeper' ),
						'param_name' => 'column',
						'value'      => array(
							'6 Columns' => '6',
							'5 Columns' => '5',
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '3',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Tablet ( From 991px to 1024px )', 'deeper' ),
						'param_name' => 'column2',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '2',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Mobile ( From 767px to 991px )', 'deeper' ),
						'param_name' => 'column3',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '2',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Small Mobile ( < 767px )', 'deeper' ),
						'param_name' => 'column4',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '1',
						'group' => __( 'Columns', 'deeper' ),
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
			    )
			);
		}
	}

	new Deeper_PartnerCarousel_Shortcode;
}



