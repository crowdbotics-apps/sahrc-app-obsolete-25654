<?php
/**
 * Event_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Event_Box_Shortcode' ) ) {

	class Deeper_Event_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_eventbox', array( 'Deeper_Event_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_eventbox', array( 'Deeper_Event_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract( shortcode_atts( array(
				'alignment' => 'align-center',
				'event_image' => '',
				'event_image_width' => '',
				// Content
				'title'	=> '',
				'title_color'	=> '',
				'sub_title'	=> '',
				'sub_title_color'	=> '',
				'time'	=> '',
				'time_color'	=> '',
				'date_color'	=> '',

				// Typography
				'title_font_family' 	=> '',
				'title_font_weight' 	=> '',
				'title_font_size' 		=> '',
				'title_line_height' 	=> '',
				'title_letter_spacing' 	=> '',

				'sub_title_font_family' 	=> '',
				'sub_title_font_weight' 	=> '',
				'sub_title_font_size' 		=> '',
				'sub_title_line_height' 	=> '',
				'sub_title_letter_spacing' 	=> '',

				'time_font_family' 	=> '',
				'time_font_weight' 	=> '',
				'time_font_size' 		=> '',
				'time_line_height' 	=> '',
				'time_letter_spacing' 	=> '',

				'date_font_family' 	=> '',
				'date_font_weight' 	=> '',
				'date_font_size' 		=> '',
				'date_line_height' 	=> '',
				'date_letter_spacing' 	=> '',

				'url_showcase'			=> '',
				// Button General
				'button_align'			=> 'align-left',
				'button_style'			=> 'button-accent',
				'button_size'			=> 'medium',
				'button_text' 			=> 'Read More',
				'button_url' 			=> '',
				'button_margin' 		=> '',
				'button_extra'			=> '',
				// Button Custom 
				'button_padding' 		=> '14px 20px 14px 20px',
				'button_rounded' 		=> '',
				'button_text_color'	 	=> '',
				'button_background' 	=> '',
			    'button_border_width' 	=> '',
			    'button_border_style' 	=> 'solid',
				'button_border' 		=> '',
				'button_shadow' 		=> '',
				'button_text_hover' 	=> '',
				'button_background_hover' => '',
				'button_border_hover' 	=> '',
				'button_shadow_hover' 	=> '',
				'button_parent_hover' 	=> '',
				// Button Typography
				'button_font_family' 	=> '',
				'button_font_weight' 	=> '',
				'button_font_size' 		=> '',
				'button_line_height' 	=> '',
				'button_letter_spacing' 	=> '',
				// Link General
				'link_align'			=> 'align-left',
				'link_style'			=> 'style-1',
				'link_text' 			=> 'Read More',
				'link_url' 				=> '',
				'link_margin' 			=> '',
				'link_extra'			=> '',
				// Link Typography
				'link_font_family' 		=> '',
				'link_font_weight' 		=> '',
				'link_font_size' 		=> '',
				'link_line_height' 		=> '',
				'link_letter_spacing' 	=> '',
				'link_color'			=> '',
				'link_line_color'		=> '',
				'link_icon_color'		=> '',
				'link_hover_color'			=> '',
				'link_hover_line_color'		=> '',
				'link_hover_icon_color'		=> '',
				'link_parent_hover'			=> '',

				// Spacing
				'title_margin' => '',
				'desc_padding' => '',
				'sub_title_margin' => '',
				'time_margin_top' => '',
				'time_margin_bottom' => '',

				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',

				'class'  => '',
			), $atts ) );

			// Init
			$title_css = $sub_title_css = $time_css = $image_css = $date_css = '';
			$title_html = $sub_title_html = $time_html = $date_html = '';
			$url_wrap_css = $url_css = $link_html = $link_cls = $sub_title_cls = '';
			$data = '';
			$url_atts = '';
			$url_string = '';

			$accent = deeper_get_accent_color();

			$content = wpb_js_remove_wpautop( $content, true );
			$content = str_replace( '<p>', '<div>', $content );
			$content = str_replace( '</p>', '</div>', $content );
			
			$cls = $alignment . ' ' . $class;

			if ( $url_showcase == 'link' )
				$url_string = deeper_get_shortcode( 'deeper_link', $atts, 'link' );

			if ( $url_showcase == 'button' )
				$url_string = deeper_get_shortcode( 'deeper_button', $atts, 'button' );	

			if( $event_image_width ) $image_css .= 'width:' . $event_image_width . ';';

			if ( $link_url ) {
				$url = vc_build_link( $link_url );
				if ( $url['url'] ) $url_atts .= 'href=' . esc_url( $url['url'] );
				if ( $url['target'] ) $url_atts .= ' target=' . esc_attr( $url['target'] );
				if ( $url['title'] ) $url_atts .= ' title="' . sanitize_html_class( $url['title'] ) . '"';
			}

			// Title
			if ( $title ) {
				$title_cls = '';
				if ( $title_color == $accent ) {
					$title_cls .= ' accent-color';
				} elseif ( $title_color ) {
					$title_css .=  'color:' . $title_color . ';';
				}
				if ( $title_font_weight ) $title_css .= 'font-weight:' . $title_font_weight . ';';
				if ( $title_font_size ) $title_css .= 'font-size:' . intval( $title_font_size ) . 'px;';
				if ( $title_line_height ) $title_css .= 'line-height:' . intval( $title_line_height ) . 'px;';
				if ( $title_letter_spacing ) $title_css .= 'letter-spacing:' . $title_letter_spacing . 'px;';
				if ( $title_font_family ) {
					deeper_enqueue_google_font( $title_font_family );
					$title_css .= 'font-family:' . $title_font_family . ';';
				}
				if ( $title_margin ) $title_css .= 'margin-bottom:' . intval( $title_margin ) . 'px;';

				$title_html = sprintf( 
				'<h2 class="title %3$s" style="%1$s">
					<a %4$s">%2$s</a>
				</h2>',
				esc_attr( $title_css ),
				esc_attr( $title ),
				esc_attr( $title_cls ),
				esc_attr( $url_atts )
				);
			}

			// Sub Title
			if ( $sub_title ) {
				if ( $sub_title_font_weight ) $sub_title_css .= 'font-weight:' . $sub_title_font_weight . ';';
				if ( $sub_title_font_size ) $sub_title_css .= 'font-size:' . intval( $sub_title_font_size ) . 'px;';
				if ( $sub_title_line_height ) $sub_title_css .= 'line-height:' . intval( $sub_title_line_height ) . 'px;';
				if ( $sub_title_letter_spacing ) $sub_title_css .= 'letter-spacing:' . $sub_title_letter_spacing . 'px;';
				if ( $sub_title_font_family ) {
					deeper_enqueue_google_font( $sub_title_font_family );
					$sub_title_css .= 'font-family:' . $sub_title_font_family . ';';
				}
				if ( $sub_title_margin ) $desc_css .= 'margin-bottom:' . intval( $sub_title_margin ) . 'px;';

				$sub_title_html = sprintf( 
				'<div class="sub-title %3$s" style="%1$s">
					%2$s
				</div>',
				esc_attr( $sub_title_css ),
				esc_attr( $sub_title ),
				esc_attr( $sub_title_cls )
				);
			}

			// Time
			if ( $time ) {
				$time_cls = '';
				if ( $time_color == $accent ) {
					$time_cls .= ' accent-color';
				} elseif ( $time_color ) {
					$time_css .=  'color:' . $time_color . ';';
				}
				if ( $time_font_weight ) $time_css .= 'font-weight:' . $time_font_weight . ';';
				if ( $time_font_size ) $time_css .= 'font-size:' . intval( $time_font_size ) . 'px;';
				if ( $time_line_height ) $time_css .= 'line-height:' . intval( $time_line_height ) . 'px;';
				if ( $time_letter_spacing ) $time_css .= 'letter-spacing:' . $time_letter_spacing . 'px;';
				if ( $time_font_family ) {
					deeper_enqueue_google_font( $time_font_family );
					$time_css .= 'font-family:' . $time_font_family . ';';
				}
				if ( $time_margin_top ) $time_css .= 'margin-top:' . intval( $time_margin_top ) . 'px;';
				if ( $time_margin_bottom ) $time_css .= 'margin-bottom:' . intval( $time_margin_bottom ) . 'px;';

				$time_html = sprintf( 
				'<div class="time %3$s" style="%1$s">
					%2$s
				</div>',
				esc_attr( $time_css ),
				esc_attr( $time ),
				esc_attr( $time_cls )
				);
			}

			// Date
			if ( $content ) {
				$date_cls = '';
				if ( $date_color == $accent ) {
					$date_cls .= ' accent-color';
				} elseif ( $date_color ) {
					$date_css .=  'color:' . $date_color . ';';
				}
				if ( $date_font_weight ) $date_css .= 'font-weight:' . $date_font_weight . ';';
				if ( $date_font_size ) $date_css .= 'font-size:' . intval( $date_font_size ) . 'px;';
				if ( $date_line_height ) $date_css .= 'line-height:' . intval( $date_line_height ) . 'px;';
				if ( $date_letter_spacing ) $date_css .= 'letter-spacing:' . $date_letter_spacing . 'px;';
				if ( $date_font_family ) {
					deeper_enqueue_google_font( $date_font_family );
					$date_css .= 'font-family:' . $date_font_family . ';';
				}

				$date_html = sprintf( 
				'<div class="date %3$s" style="%1$s">
					%2$s
				</div>',
				esc_attr( $date_css ),
				$content,
				esc_attr( $date_cls )
				);
			}

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}
			ob_start(); ?>

			<?php
			return sprintf(
				'<div class="deeper-event-box %8$s" data-inviewport="yes" %9$s>
						<div class="thumb">
						<a %10$s">
							<img style ="%5$s" src="%1$s" alt="Image">
						</a>
						</div>
						<div class="content-wrap">
							%7$s
							%3$s
							%2$s
							%4$s
							%6$s
						</div>
					</div>
				',
				esc_url( wp_get_attachment_image_src( $event_image, 'full' )[0] ),
				$title_html,
				$sub_title_html,
				$time_html,
				$image_css,
				do_shortcode( $url_string ),
				$date_html,
				$cls,
				$data,
				esc_attr( $url_atts )
			);
			return ob_get_clean();
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Event Box', 'deeper' ),
		        'description' => __( 'Empty space with custom height.', 'deeper' ),
		        'base' => 'deeper_eventbox',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/news.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Alignment', 'deeper' ),
						'param_name'  => 'alignment',
						'value'       => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'align-center',
					),
					array(
						'type' => 'attach_image',
						'heading' => __( 'Image', 'deeper' ),
						'param_name' => 'event_image',
						'value' => '',
						'group' => __( 'Image', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Image Width', 'deeper' ),
						'param_name' => 'event_image_width',
						'value' => '',
						'group' => __( 'Image', 'deeper' ),
					),
					// Content
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Title', 'deeper'),
						'param_name' => 'title',
						'holder'	=> 'div',
						'value' => '',
						'group' => __( 'Content', 'deeper' ),
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Title Color', 'deeper'),
						'param_name' => 'title_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Sub Title', 'deeper'),
						'param_name' => 'sub_title',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Sub Title Color', 'deeper'),
						'param_name' => 'sub_title_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Time', 'deeper'),
						'param_name' => 'time',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Time Color', 'deeper'),
						'param_name' => 'time_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'textarea_html',
						'heading' => esc_html__('Date', 'deeper'),
						'param_name' => 'content',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Date Color', 'deeper'),
						'param_name' => 'date_color',
						'group' => __( 'Content', 'deeper' ),
						'value' => '',
					),
					// Button or Link
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'url_showcase',
						'value'      => array(
							'Disable' => '',
							'Link' => 'link',
							'Button' => 'button',
						),
						'std'		=> '',
						'group' => __( 'URL', 'deeper' ),
					),
					// Link
					array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'link_align',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
						'value' => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'medium'
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Link Style', 'deeper' ),
						'param_name' => 'link_style',
						'value' => array(
							'Style 1' 		=> 'style-1',
							'Style 2' 		=> 'style-2',
							'Style 3' 		=> 'style-3',
						),
						'std'		=> 'style-1',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
					),
			        array(
						'type' => 'textfield',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'link_text',
						'value' => 'Read More',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'link_url',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        // Button 
			        array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'button_align',
						'value' => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'medium',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Style', 'deeper' ),
						'param_name' => 'button_style',
						'value' => array(
							'Accent' 	=> 'button-accent',
							'Outline Accent' 	=> 'outline-accent',
							'Radical Red' 		=> 'button-radical-red',			
							'Outline Radical Red' 		=> 'outline-radical-red',			
							'Blue' 		=> 'button-blue',			
							'Outline Blue' 		=> 'outline-blue',
							'Green' 		=> 'button-green',			
							'Outline Green' 		=> 'outline-green',	
							'White' 		=> 'button-white',			
							'Custom' 			=> 'custom',
						),
						'std'		=> 'button-accent',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Size', 'deeper' ),
						'param_name' => 'button_size',
						'value' => array(
							'Small' 		=> 'small',
							'Medium' 		=> 'medium',
							'Big' 			=> 'big',
						),
						'std'		=> 'medium',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),	
			        array(
						'type' => 'textfield',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'button_text',
						'value' => 'Read More',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'button_url',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Link Color', 'deeper'),
						'param_name' => 'link_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Line Color', 'deeper'),
						'param_name' => 'link_line_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Icon Color', 'deeper'),
						'param_name' => 'link_icon_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        // Hover
				  	array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Link Color', 'deeper'),
						'param_name' => 'link_hover_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Line Color', 'deeper'),
						'param_name' => 'link_hover_line_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Icon Color', 'deeper'),
						'param_name' => 'link_hover_icon_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'link_parent_hover',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-content-box', 'deeper' ),
			        ),
					// Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Title', 'deeper' ),
						'param_name' => 'title_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Title: Font Family', 'deeper' ),
						'param_name' => 'title_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Title: Font Weight', 'deeper' ),
						'param_name' => 'title_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Title: Font Size', 'deeper' ),
						'param_name' => 'title_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Title: Line Height', 'deeper' ),
						'param_name' => 'title_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Title: Letter Spacing', 'deeper' ),
						'param_name' => 'title_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Sub Title', 'deeper' ),
						'param_name' => 'sub_title_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Sub Title: Font Family', 'deeper' ),
						'param_name' => 'sub_title_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Sub Title: Font Weight', 'deeper' ),
						'param_name' => 'sub_title_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Sub Title: Font Size', 'deeper' ),
						'param_name' => 'sub_title_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Sub Title: Line Height', 'deeper' ),
						'param_name' => 'sub_title_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Sub Title: Letter Spacing', 'deeper' ),
						'param_name' => 'sub_title_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Time', 'deeper' ),
						'param_name' => 'time_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Time: Font Family', 'deeper' ),
						'param_name' => 'time_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Time: Font Weight', 'deeper' ),
						'param_name' => 'time_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Time: Font Size', 'deeper' ),
						'param_name' => 'time_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Time: Line Height', 'deeper' ),
						'param_name' => 'time_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Time: Letter Spacing', 'deeper' ),
						'param_name' => 'time_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Date', 'deeper' ),
						'param_name' => 'date_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Date: Font Family', 'deeper' ),
						'param_name' => 'date_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Date: Font Weight', 'deeper' ),
						'param_name' => 'date_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Date: Font Size', 'deeper' ),
						'param_name' => 'date_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Date: Line Height', 'deeper' ),
						'param_name' => 'date_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Date: Letter Spacing', 'deeper' ),
						'param_name' => 'date_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	// Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Button', 'deeper' ),
						'param_name' => 'button_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Button: Font Family', 'deeper' ),
						'param_name' => 'button_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Button: Font Weight', 'deeper' ),
						'param_name' => 'button_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Font Size', 'deeper' ),
						'param_name' => 'button_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Line Height', 'deeper' ),
						'param_name' => 'button_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Button: Letter Spacing', 'deeper' ),
						'param_name' => 'button_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
				  	),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'link_extra',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
			        ),
			        // Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Link', 'deeper' ),
						'param_name' => 'link_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Link: Font Family', 'deeper' ),
						'param_name' => 'link_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Link: Font Weight', 'deeper' ),
						'param_name' => 'link_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Font Size', 'deeper' ),
						'param_name' => 'link_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Line Height', 'deeper' ),
						'param_name' => 'link_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Link: Letter Spacing', 'deeper' ),
						'param_name' => 'link_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
				  	),

					// Spacing
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Title: Margin Bottom', 'deeper'),
						'param_name' => 'title_margin',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Sub Title: Padding', 'deeper'),
						'param_name' => 'desc_padding',
						'value' => '',
						'description'	=> esc_html__('Top Right Bottom Left. Ex: 0px 0px 1px 0px', 'deeper'),
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Sub Title: Margin', 'deeper'),
						'param_name' => 'sub_title_margin',
						'value' => '',
						'description'	=> esc_html__('Top Right Bottom Left. Ex: 0px 0px 1px 0px', 'deeper'),
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Time: Margin Top', 'deeper'),
						'param_name' => 'time_margin_top',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Time: Margin Bottom', 'deeper'),
						'param_name' => 'time_margin_bottom',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),

					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}

	new Deeper_Event_Box_Shortcode;
}
