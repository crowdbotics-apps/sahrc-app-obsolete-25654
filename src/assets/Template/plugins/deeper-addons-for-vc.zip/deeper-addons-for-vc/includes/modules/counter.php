<?php
/**
 * Counter shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_counter_Shortcode' ) ) {

	class Deeper_counter_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_counter', array( 'Deeper_counter_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_counter', array( 'Deeper_counter_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(

			// General
			'counter_style' => 'style-1',
			'counter' => '',
			'number_format' => '',
			'counter_color' => '',
			'counter_bg'	=> '',
			'prefix'	=> '',
			'suffix'	=> '',
			'prefix_color'	=> '',
			'suffix_color'	=> '',
			'heading' => '',
			'heading_color' => '',
			'desc' => '',
			'desc_color' => '',

			// Icon
			'icon_image' => '',
			'icon_image_width' => '',

			'icon_text' => '',

			'icon' => '',
			'icon_align' => '',
			'icon_type' => '',
			'icon_font_size' => '',
			'icon_width' => '',
			'icon_height' => '',
			'icon_line_height' => '',
			'icon_rounded' => '',

			'icon_color' => '',
			'icon_background' => '',
			'icon_border_width' => '',
			'icon_border_style' => 'solid',
			'icon_border' => '',
			'icon_margin'	=> '0px',
			'icon_pos'	=> '',

			// Typography
			'counter_font_family' => '',
			'counter_font_weight' => '',
			'counter_font_size' => '',
			'counter_line_height' => '',
			'counter_letter_spacing' => '',

			'prefix_font_family' => '',
			'prefix_font_weight' => '',
			'prefix_font_size' => '',
			'prefix_line_height' => '',
			'prefix_letter_spacing' => '',

			'suffix_font_family' => '',
			'suffix_font_weight' => '',
			'suffix_font_size' => '',
			'suffix_line_height' => '',
			'suffix_letter_spacing' => '',

			'heading_font_family' => '',
			'heading_font_weight' => '',
			'heading_font_size' => '',
			'heading_line_height' => '',
			'heading_letter_spacing' => '',

			'desc_font_family' => '',
			'desc_font_weight' => '',
			'desc_font_size' => '',
			'desc_line_height' => '',
			'desc_letter_spacing' => '',
			
			// Spacing
			'counter_bottom_margin' => '',
			'heading_bottom_margin' => '',
			'prefix_padding' => '',
			'suffix_padding' => '',
			
			// Animation
			'animation' => '',
			'animation_effect' => 'fadeInUp',
			'animation_duration' => '0.75s',
			'animation_delay' => '0.3s',

			'class' => '',
		), $atts ) );
		$accent = deeper_get_accent_color();

		wp_enqueue_script( 'appear' );
		wp_enqueue_script( 'countto' );
		$cls = $html = $data = '';
		$icon_html = $icon = $icon_css = $icon_cls = $icon_data = $icon_string = '';
		$heading_css = $counter_css = $desc_css ='';
		$heading_cls = $counter_cls = $desc_cls ='';
		$prefix_html = $suffix_html = '';
		$prefix_cls = $suffix_cls = $prefix_css = $suffix_css = '';

		$cls .= $counter_style;
		if( $class ) $cls .= ' ' . $class;

		$icon_string = deeper_get_shortcode( 'deeper_icon', $atts, 'icon' );	
		$cls = $icon_pos . ' ' . $class;
		
		// Counter
		if ( $counter ) {
			if ( $counter_font_weight ) $counter_css .= 'font-weight:'. $counter_font_weight .';';
			if ( $counter_color == $accent ) {
				$counter_cls .= ' accent-color';
			} elseif ( $counter_color ) {
				$counter_css .= 'color:'. $counter_color .';';
			} 
			if ( $counter_font_size ) $counter_css .= 'font-size:'. intval( $counter_font_size ) .'px;';
			if ( $counter_line_height ) $counter_css .= 'line-height:'. intval( $counter_line_height ) .'px;';
			if ( $counter_letter_spacing ) $counter_css .= 'letter-spacing:'. $counter_letter_spacing .'px;';

			if ( $counter_bottom_margin ) $counter_css .= 'margin-bottom:'. intval( $counter_bottom_margin ) .'px;';
			if ( $counter_font_family ) {
				deeper_enqueue_google_font( $counter_font_family );
				$counter_css .= 'font-family:'. $counter_font_family .';';
			}

			// Prefix
			if ( $prefix ) {
				if ( $prefix_font_weight ) $prefix_css .= 'font-weight:'. $prefix_font_weight .';';
				if ( $prefix_color == $accent ) {
					$prefix_cls .= ' accent-color';
				} elseif ( $prefix_color ) {
					$prefix_css .= 'color:'. $prefix_color .';';
				} 
				if ( $prefix_font_size ) $prefix_css .= 'font-size:'. intval( $prefix_font_size ) .'px;';
				if ( $prefix_line_height ) $prefix_css .= 'line-height:'. intval( $prefix_line_height ) .'px;';
				if ( $prefix_letter_spacing ) $prefix_css .= 'letter-spacing:'. $prefix_letter_spacing .'px;';

				if ( $prefix_font_family ) {
					deeper_enqueue_google_font( $prefix_font_family );
					$prefix_css .= 'font-family:'. $prefix_font_family .';';
				}
				if( $prefix_padding ) $prefix_css .= 'padding:' . $prefix_padding . ';';

				$prefix_html = sprintf( 
					'<span class="prefix %2$s" style="%3$s">%1$s</span>',
					$prefix,
					$prefix_cls,
					$prefix_css
				);
			}

			// Suffix
			if ( $suffix ) {
				if ( $suffix_font_weight ) $suffix_css .= 'font-weight:'. $suffix_font_weight .';';
				if ( $suffix_color == $accent ) {
					$suffix_cls .= ' accent-color';
				} elseif ( $suffix_color ) {
					$suffix_css .= 'color:'. $suffix_color .';';
				} 
				if ( $suffix_font_size ) $suffix_css .= 'font-size:'. intval( $suffix_font_size ) .'px;';
				if ( $suffix_line_height ) $suffix_css .= 'line-height:'. intval( $suffix_line_height ) .'px;';
				if ( $suffix_letter_spacing ) $suffix_css .= 'letter-spacing:'. $suffix_letter_spacing .'px;';

				if ( $suffix_font_family ) {
					deeper_enqueue_google_font( $suffix_font_family );
					$suffix_css .= 'font-family:'. $suffix_font_family .';';
				}
				if( $suffix_padding ) $prefix_css .= 'padding:' . $suffix_padding . ';';				

				$suffix_html = sprintf( 
					'<span class="prefix %2$s" style="%3$s">%1$s</span>',
					$suffix,
					$suffix_cls,
					$suffix_css
				);
			}

			if ( $counter_bg ) 
				$counter_css .= '-webkit-text-fill-color:transparent;-webkit-background-clip:text;background-position:center center;background-size:cover;background-image: url(' . 
					esc_url( wp_get_attachment_image_src( $counter_bg, 'full' )[0] ) . ');';

			$html .= sprintf(
				'<div class="counter-wrap %3$s" style="%2$s">
					%4$s<span class="number" data-speed="3000" data-to="%1$s" data-format="%6$s">%1$s</span>%5$s
				</div>',
				$counter,
				$counter_css,
				$counter_cls,
				$prefix_html,
				$suffix_html,
				$number_format
			);
		}

		// Heading
		if ( $heading ) {
			if ( $heading_font_weight ) $heading_css .= 'font-weight:'. $heading_font_weight .';';
			if ( $heading_color == $accent ) {
					$heading_cls .= ' accent-color';
				} elseif ( $heading_color ) {
					$heading_css .= 'color:'. $heading_color .';';
				} 
			if ( $heading_font_size ) $heading_css .= 'font-size:'. intval( $heading_font_size ) .'px;';
			if ( $heading_line_height ) $heading_css .= 'line-height:'. intval( $heading_line_height ) .'px;';
			if ( $heading_letter_spacing ) $heading_css .= 'letter-spacing:'. $heading_letter_spacing .'px;';

			if ( $heading_bottom_margin ) $heading_css .= 'margin-bottom:'. intval( $heading_bottom_margin ) .'px;';
			if ( $heading_font_family ) {
				deeper_enqueue_google_font( $heading_font_family );
				$heading_css .= 'font-family:'. $heading_font_family .';';
			}

			$html .= sprintf(
				'<h3 class="heading" style="%2$s">
					<span>%1$s</span>
				</h3>',
				$heading,
				$heading_css
			);
		}

		// Desc
		if ( $desc ) {
			if ( $desc_font_weight ) $desc_css .= 'font-weight:'. $desc_font_weight .';';
			if ( $desc_color ) $desc_css .= 'color:'. $desc_color .';';
			if ( $desc_font_size ) $desc_css .= 'font-size:'. intval( $desc_font_size ) .'px;';
			if ( $desc_line_height ) $desc_css .= 'line-height:'. intval( $desc_line_height ) .'px;';
			if ( $desc_letter_spacing ) $desc_css .= 'letter-spacing:'. $desc_letter_spacing .'px;';

			if ( $desc_font_family ) {
				deeper_enqueue_google_font( $desc_font_family );
				$desc_css .= 'font-family:'. $desc_font_family .';';
			}

			$html .= sprintf(
				'<div class="desc" style="%2$s">
					<span>%1$s</span>
				</div>',
				$desc,
				$desc_css
			);
		}

		//Animation
		if ( $animation ) {
		    $cls .= ' wow '. $animation_effect;
		    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
		}

		return sprintf(
			'<div class="deeper-counter clearfix %1$s %5$s" data-inviewport="yes" %3$s>
				<div class="wrap-inner">
					%4$s
					%2$s
				</div>
			</div>',
			$cls,
			$html,
			$data,
			do_shortcode( $icon_string ),
			$counter_style
		);
	}

	// Map shortcode to VC
		public static function map() {
			return array(
		        'name' => __( 'Counter', 'deeper' ),
		        'description' => __( 'Displays custom Counter', 'deeper' ),
		        'base' => 'counter',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/counter.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params'      => array(
		        	// Icon
		        	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon to Display', 'deeper' ),
						'param_name' => 'icon_display',
						'value'      => array(
							'Icon Font' => 'icon-font',
							'Icon Image' => 'icon-image',
							'Icon Text' => 'icon-text'
						),
						'std'		=> 'icon-font',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'icon_align',
						'value'      => array(
							'Left' => 'align-left',
							'Center' => 'align-center',
							'Right' => 'align-right',
						),
						'std'		=> 'align-left',
						'dependency' => array( 'element' => 'icon_style', 'value' => 'icon-top' ),
					),
			        // Image
					array(
						'type' => 'attach_image',
						'heading' => __( 'Image', 'deeper' ),
						'param_name' => 'icon_image',
						'value' => '',
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Image Width', 'deeper' ),
						'param_name' => 'icon_image_width',
						'value' => '',
						'description'	=> __( 'Example: 100px', 'deeper' ),
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
			        ),
			        // Icon Text
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Text', 'deeper' ),
						'param_name' => 'icon_text',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-text' ),
			        ),
			        array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Icon library', 'deeper' ),
						'param_name' => 'icon_type',
						'description' => esc_html__( 'Select icon library.', 'deeper' ),
						'value' => array(
							'' => '',
							esc_html__( 'Basic', 'deeper' ) => 'basic',
							esc_html__( 'Corporate', 'deeper' ) => 'corporate',
							esc_html__( 'Stroke 7 Icons', 'deeper' ) => '7stroke',
							esc_html__( 'FontAwesome', 'deeper' ) => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_basic',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'basic',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'basic',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_corporate',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'corporate',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'corporate',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_7stroke',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => '7stroke',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => '7stroke',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon',
						'settings' => array(
							'emptyIcon' => true,
							'iconsPerPage' => 200,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Icon Font Size', 'deeper' ),
						'param_name' => 'icon_font_size',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
						'description' => esc_html__( 'Default: 16px.', 'deeper' ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Width', 'deeper' ),
						'param_name' => 'icon_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Height', 'deeper' ),
						'param_name' => 'icon_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Line Height', 'deeper' ),
						'param_name' => 'icon_line_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Rounded', 'deeper' ),
						'param_name' => 'icon_rounded',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Color', 'deeper' ),
						'param_name' => 'icon_color',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Background', 'deeper' ),
						'param_name' => 'icon_background',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Border Width', 'deeper' ),
						'param_name' => 'icon_border_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon Border Style', 'deeper' ),
						'param_name' => 'icon_border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Border', 'deeper' ),
						'param_name' => 'icon_border',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Shadow', 'deeper' ),
						'param_name' => 'icon_shadow',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),	       
					
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Counter', 'deeper' ),
						'param_name' => 'deeper_heading_counter',
		            ),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Counter Style', 'deeper' ),
						'param_name' => 'counter_style',
						'value'      => array(
							'Style 1' => 'style-1',
							'Style 2' => 'style-2',
						),
						'std'		=> 'style-1',
					),
					array(
						'type' => 'deeper_number',
						'holder' => 'div',
						'heading' => __( 'Counter', 'deeper' ),
						'param_name' => 'counter',
						'value' => '',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Counter Color', 'deeper' ),
						'param_name' => 'counter_color',
						'value' => '',
		            ),
		            array(
						'type' => 'attach_image',
						'heading' => esc_html__('Counter Background Image', 'deeper'),
						'param_name' => 'counter_bg',
						'value' => '',
					),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Number format', 'deeper' ),
						'param_name' => 'number_format',
						'value'      => array(
							'Default' => '',
							'Thousand Separateur' => 'ts',
							'1 decimal' => 'd1',
							'2 decimals' => 'd2',
						),
						'std'		=> '',
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Counter: Prefix', 'deeper' ),
						'param_name' => 'prefix',
						'value' => '',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Prefix Color', 'deeper' ),
						'param_name' => 'prefix_color',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Counter: Suffix', 'deeper' ),
						'param_name' => 'suffix',
						'value' => '',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Suffix Color', 'deeper' ),
						'param_name' => 'suffix_color',
						'value' => '',
		            ),
		            array(
						'type' => 'deeper_heading',
						'text' => __( 'Content', 'deeper' ),
						'param_name' => 'deeper_heading_content',
		            ),
					array(
						'type' 		=> 'textarea',
						'holder'	=> 'div',
						'heading' 	=> __( 'Heading', 'deeper' ),
						'param_name' 	=> 'heading',
						'value' 		=> '',
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Heading Color', 'deeper' ),
						'param_name' => 'heading_color',
						'value' => '',
		            ),

		            array(
						'type' 		=> 'textarea',
						'heading' 	=> __( 'Description', 'deeper' ),
						'param_name' 	=> 'desc',
						'value' 		=> '',
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Description Color', 'deeper' ),
						'param_name' => 'desc_color',
						'value' => '',
		            ),
		            // Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Counter', 'deeper' ),
						'param_name' => 'counter_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Counter: Font Family', 'deeper' ),
						'param_name' => 'counter_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Counter: Font Weight', 'deeper' ),
						'param_name' => 'counter_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Counter: Font Size', 'deeper' ),
						'param_name' => 'counter_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Counter: Line Height', 'deeper' ),
						'param_name' => 'counter_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Counter: Letter Spacing', 'deeper' ),
						'param_name' => 'counter_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Counter Prefix', 'deeper' ),
						'param_name' => 'prefix_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'prefix', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Counter Prefix: Font Family', 'deeper' ),
						'param_name' => 'prefix_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'prefix', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Counter Prefix: Font Weight', 'deeper' ),
						'param_name' => 'prefix_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'prefix', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Counter Prefix: Font Size', 'deeper' ),
						'param_name' => 'prefix_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'prefix', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Counter Prefix: Line Height', 'deeper' ),
						'param_name' => 'prefix_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'prefix', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Counter Prefix: Letter Spacing', 'deeper' ),
						'param_name' => 'prefix_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'prefix', 'not_empty' => true ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Counter Suffix', 'deeper' ),
						'param_name' => 'suffix_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'suffix', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Counter Suffix: Font Family', 'deeper' ),
						'param_name' => 'suffix_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'suffix', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Counter Suffix: Font Weight', 'deeper' ),
						'param_name' => 'suffix_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'suffix', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Counter Suffix: Font Size', 'deeper' ),
						'param_name' => 'suffix_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'suffix', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Counter Suffix: Line Height', 'deeper' ),
						'param_name' => 'suffix_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'suffix', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Counter Suffix: Letter Spacing', 'deeper' ),
						'param_name' => 'suffix_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'suffix', 'not_empty' => true ),
				  	),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Heading', 'deeper' ),
						'param_name' => 'heading_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'heading', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Heading: Font Family', 'deeper' ),
						'param_name' => 'heading_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'heading', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Heading: Font Weight', 'deeper' ),
						'param_name' => 'heading_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'heading', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Heading: Font Size', 'deeper' ),
						'param_name' => 'heading_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'heading', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Heading: Line Height', 'deeper' ),
						'param_name' => 'heading_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'heading', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Heading: Letter Spacing', 'deeper' ),
						'param_name' => 'heading_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'heading', 'not_empty' => true ),
				  	),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Description', 'deeper' ),
						'param_name' => 'desc_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'desc', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Description: Font Family', 'deeper' ),
						'param_name' => 'desc_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'desc', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Description: Font Weight', 'deeper' ),
						'param_name' => 'desc_font_weight',
						'value'      => array(
							'Default'		=> 'Default',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'desc', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Font Size', 'deeper' ),
						'param_name' => 'desc_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'desc', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Line Height', 'deeper' ),
						'param_name' => 'desc_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'desc', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Description: Letter Spacing', 'deeper' ),
						'param_name' => 'desc_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'desc', 'not_empty' => true ),
				  	),
			        // Spacing
			        array(
						'type' => 'textfield',
						'heading' => __( 'Counter: Bottom Margin', 'deeper' ),
						'param_name' => 'counter_bottom_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Prefix: Padding', 'deeper' ),
						'param_name' => 'prefix_padding',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'dependency' => array( 'element' => 'prefix', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Suffix: Padding', 'deeper' ),
						'param_name' => 'suffix_padding',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'dependency' => array( 'element' => 'suffix', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Heading: Bottom Margin', 'deeper' ),
						'param_name' => 'heading_bottom_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'dependency' => array( 'element' => 'heading', 'not_empty' => true ),
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
		            ),
		        )
		    );
		}
	}

	new Deeper_Counter_Shortcode;
}

