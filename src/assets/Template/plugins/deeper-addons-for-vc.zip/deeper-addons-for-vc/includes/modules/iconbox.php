<?php
/**
 * IconBox shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_IconBox_Shortcode' ) ) {

	class Deeper_IconBox_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_iconbox', array( 'Deeper_IconBox_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_iconbox', array( 'Deeper_IconBox_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$cls = $css = $data = $text_html = '';
			$heading_css = $desc_css = '';
			$url_wrap_css = $url_css = $link_html = $link_cls = '';
			$button_cls = $button_data = '';
			$icon_html = $icon = $icon_css = $icon_cls = $icon_data = $icon_string = '';
			$url_string = '';

			extract( shortcode_atts( array(
				'class'	=> '',
				'icon_style' => 'icon-top',
				'icon_align' => 'align-left',
				'icon_display' => 'icon-font',

				'icon_image' => '',
				'icon_image_width' => '',

				'icon_text' => '',

				'icon' => '',
				'icon_type' => '',
				'icon_font_size' => '',
				'icon_width' => '',
				'icon_height' => '',
				'icon_line_height' => '',
				'icon_rounded' => '',

				'icon_color' => '',
				'icon_color1' => '',
				'icon_color2' => '',
				'icon_angle' => '',
				'icon_background' => '',
				'icon_border_width' => '',
				'icon_border_style' => 'solid',
				'icon_border' => '',
				'icon_color_hover' => '',
				'icon_background_hover' => '',
				'icon_border_hover' => '',
				'icon_shadow' => '',
				'icon_shadow_hover' => '',
				'icon_parent_hover' => 'deeper-icon-box',
				'icon_extra'	=> '',

				'tag' => 'h3',
				'heading' => '',
				'heading_color' => '',
				'desc_color' => '',

				'url_showcase'			=> '',
				// Button General
				'button_align'			=> 'align-left',
				'button_style'			=> 'button-accent',
				'button_size'			=> 'medium',
				'button_text' 			=> 'Read More',
				'button_url' 			=> '',
				'button_margin' 		=> '',
				'button_extra'			=> '',
				// Button Custom 
				'button_padding' 		=> '14px 20px 14px 20px',
				'button_rounded' 		=> '',
				'button_text_color'	 	=> '',
				'button_background' 	=> '',
			    'button_border_width' 	=> '',
			    'button_border_style' 	=> 'solid',
				'button_border' 		=> '',
				'button_shadow' 		=> '',
				'button_text_hover' 	=> '',
				'button_background_hover' => '',
				'button_border_hover' 	=> '',
				'button_shadow_hover' 	=> '',
				'button_parent_hover' 	=> '',
				// Button Typography
				'button_font_family' 	=> '',
				'button_font_weight' 	=> '',
				'button_font_size' 		=> '',
				'button_line_height' 	=> '',
				'button_letter_spacing' 	=> '',
				// Link General
				'link_align'			=> 'align-left',
				'link_style'			=> 'style-1',
				'link_text' 			=> 'Read More',
				'link_url' 				=> '',
				'link_margin' 			=> '',
				'link_extra'			=> '',
				// Link Typography
				'link_font_family' 		=> '',
				'link_font_weight' 		=> '',
				'link_font_size' 		=> '',
				'link_line_height' 		=> '',
				'link_letter_spacing' 	=> '',
				'link_color'			=> '',
				'link_line_color'		=> '',
				'link_icon_color'		=> '',
				'link_hover_color'			=> '',
				'link_hover_line_color'		=> '',
				'link_hover_icon_color'		=> '',
				'link_parent_hover'			=> '',

				'heading_font_family' => '',
				'heading_font_weight' => '',
				'heading_font_size' => '',
				'heading_line_height' => '',
				'heading_letter_spacing' => '',

				'desc_font_family' => '',
				'desc_font_weight' => '',
				'desc_font_size' => '',
				'desc_line_height' => '',
				'desc_letter_spacing' => '',

				'icon_margin' => '',

				'content_left_padding' => '85px', // for icon-left
				'content_right_padding' => '85px', // for icon-right

				'heading_top_margin' => '',
				'heading_bottom_margin' => '',
				'desc_top_margin' => '',
				'desc_bottom_margin' => '',

				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );
			$content = wpb_js_remove_wpautop( $content, true );
			$accent = deeper_get_accent_color();

			$cls = $icon_style . ' ' . $icon_align;
			if ( $class ) $cls .= ' ' . $class;

			if ( $icon_style == 'icon-left' && $content_left_padding ) 
				$heading_css = $desc_css = $url_wrap_css = 'padding-left:' . intval( $content_left_padding ) . 'px;';

			if ( $icon_style == 'icon-right' && $content_right_padding )
				$heading_css = $desc_css = $url_wrap_css = 'padding-right:' . intval( $content_right_padding ) . 'px;';
					
			if ( $heading ) {
				$heading_cls = '';
				if ( $heading_color == $accent ) { 
					$heading_cls .= ' accent-color';
				} elseif ( $heading_color ) { 
					$heading_css .= 'color:' . $heading_color . ';';
				}

				if ( $heading_font_weight ) $heading_css .= 'font-weight:' . $heading_font_weight . ';';
				if ( $heading_font_size ) $heading_css .= 'font-size:' . intval( $heading_font_size ) . 'px;';
				if ( $heading_line_height ) $heading_css .= 'line-height:' . intval( $heading_line_height ) . 'px;';
				if ( $heading_letter_spacing ) $heading_css .= 'letter-spacing:' . $heading_letter_spacing . 'px;';

				if ( $heading_top_margin ) {
					if ( $icon_style == 'icon-left' || $icon_style == 'icon-right' ) {
						$heading_css .= 'padding-top:' . intval( $heading_top_margin ) . 'px;';
					} else { $heading_css .= 'margin-top:' . intval( $heading_top_margin ) . 'px;'; }
				}

				if ( $heading_bottom_margin ) $heading_css .= 'margin-bottom:' . intval( $heading_bottom_margin ) . 'px;';
				if ( $heading_font_family ) {
					deeper_enqueue_google_font( $heading_font_family );
					$heading_css .= 'font-family:' . $heading_font_family . ';';
				}

				$text_html .= sprintf(
					'<%3$s class="heading %4$s" style="%2$s">
						<span>%1$s</span>
					</%3$s>',
					$heading,
					$heading_css,
					$tag,
					$heading_cls
				);
			}

			if ( $content ) {
				$desc_cls = '';
				if ( $desc_color == $accent ) { 
					$desc_cls .= ' accent-color';
				} elseif ( $desc_color ) { 
					$desc_css .= 'color:' . $desc_color . ';';
				}

				if ( $desc_font_weight ) $desc_css .= 'font-weight:' . $desc_font_weight . ';';
				if ( $desc_font_size ) $desc_css .= 'font-size:' . intval( $desc_font_size ) . 'px;';
				if ( $desc_line_height ) $desc_css .= 'line-height:' . intval( $desc_line_height ) . 'px;';
				if ( $desc_letter_spacing ) $desc_css .= 'letter-spacing:' . $desc_letter_spacing . 'px;';

				if ( $desc_top_margin ) $desc_css .= 'margin-top:' . intval( $desc_top_margin ) . 'px;';
				if ( $desc_bottom_margin ) $desc_css .= 'margin-bottom:' . intval( $desc_bottom_margin ) . 'px;';
				if ( $desc_font_family ) {
					deeper_enqueue_google_font( $desc_font_family );
					$desc_css .= 'font-family:' . $desc_font_family . ';';
				}

				$text_html .= sprintf(
					'<div class="desc %3$s" style="%2$s">%1$s</div>',
					$content,
					$desc_css,
					$desc_cls
				);
			}

			if ( $url_showcase == 'link' )
				$url_string = deeper_get_shortcode( 'deeper_link', $atts, 'link' );

			if ( $url_showcase == 'button' )
				$url_string = deeper_get_shortcode( 'deeper_button', $atts, 'button' );	

			$icon_string = deeper_get_shortcode( 'deeper_icon', $atts, 'icon' );

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			} 

			return sprintf(
				'<div class="deeper-icon-box clearfix %1$s" style="%2$s" %6$s>
					%3$s %4$s %5$s
				</div>',
				$cls,
				$css,
				do_shortcode( $icon_string ),
				$text_html,
				do_shortcode( $url_string ),
				$data
			);
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => __( 'Icon Box', 'deeper' ),
		        'description' => __( 'Displays info box with custom icon and button.', 'deeper' ),
				'base' => 'deeper_iconbox',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/iconbox.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
				'params' => array(
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'icon_style',
						'value'      => array(
							'Icon Top' => 'icon-top',
							'Icon Left' => 'icon-left',
							'Icon Right' => 'icon-right',
						),
						'std'		=> 'icon-top',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'icon_align',
						'value'      => array(
							'Left' => 'align-left',
							'Center' => 'align-center',
							'Right' => 'align-right',
						),
						'std'		=> 'align-left',
						'dependency' => array( 'element' => 'icon_style', 'value' => 'icon-top' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon to Display', 'deeper' ),
						'param_name' => 'icon_display',
						'value'      => array(
							'Icon Font' => 'icon-font',
							'Icon Image' => 'icon-image',
							'Icon Text' => 'icon-text'
						),
						'std'		=> 'icon-font',
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
					),
			        // Image
					array(
						'type' => 'attach_image',
						'heading' => __( 'Image', 'deeper' ),
						'param_name' => 'icon_image',
						'value' => '',
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Image Width', 'deeper' ),
						'param_name' => 'icon_image_width',
						'value' => '',
						'description'	=> __( 'Example: 100px', 'deeper' ),
						'group' => __( 'Image', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-image' ),
			        ),
			        // Icon Text
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Text', 'deeper' ),
						'param_name' => 'icon_text',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-text' ),
			        ),
					// Icon
					array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Icon library', 'deeper' ),
						'param_name' => 'icon_type',
						'description' => esc_html__( 'Select icon library.', 'deeper' ),
						'value' => array(
							'' => '',
							esc_html__( 'Basic', 'deeper' ) => 'basic',
							esc_html__( 'Corporate', 'deeper' ) => 'corporate',
							esc_html__( 'Stroke 7 Icons', 'deeper' ) => '7stroke',
							esc_html__( 'FontAwesome', 'deeper' ) => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => 'icon-font' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_basic',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'basic',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'basic',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_corporate',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => 'corporate',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => 'corporate',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
					    'type' => 'iconpicker',
					    'heading' => esc_html__( 'Icon', 'deeper' ),
					    'param_name' => 'icon_7stroke',
					    'settings' => array(
					        'emptyIcon' => true,
					        'type' => '7stroke',
					        'iconsPerPage' => 200,
					    ),
					    'dependency' => array(
					        'element' => 'icon_type',
					        'value' => '7stroke',
					    ),
					    'group' => esc_html__( 'Icon', 'deeper' ),
					),
					array(
						'type' => 'iconpicker',
						'heading' => esc_html__( 'Icon', 'deeper' ),
						'param_name' => 'icon',
						'settings' => array(
							'emptyIcon' => true,
							'iconsPerPage' => 200,
						),
						'dependency' => array(
							'element' => 'icon_type',
							'value' => 'fontawesome',
						),
						'group' => esc_html__( 'Icon', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Font Size', 'deeper' ),
						'param_name' => 'icon_font_size',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Width', 'deeper' ),
						'param_name' => 'icon_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Height', 'deeper' ),
						'param_name' => 'icon_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Line Height', 'deeper' ),
						'param_name' => 'icon_line_height',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Rounded', 'deeper' ),
						'param_name' => 'icon_rounded',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Color', 'deeper' ),
						'param_name' => 'icon_color',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'deeper_heading',
						'text' => __( 'Gradient Color', 'deeper' ),
						'param_name' => 'icon_gradient_heading',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Gradient Color: Start', 'deeper' ),
						'param_name' => 'icon_color1',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
					array(
						'type' => 'colorpicker',
						'heading' => __( 'Gradient Color: Stop', 'deeper' ),
						'param_name' => 'icon_color2',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Gradient Color: Angle', 'deeper' ),
						'param_name' => 'icon_angle',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Background', 'deeper' ),
						'param_name' => 'icon_background',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Border Width', 'deeper' ),
						'param_name' => 'icon_border_width',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Icon Border Style', 'deeper' ),
						'param_name' => 'icon_border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Border', 'deeper' ),
						'param_name' => 'icon_border',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Shadow', 'deeper' ),
						'param_name' => 'icon_shadow',
						'value' => '',
						'group' => __( 'Icon', 'deeper' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        // Background
			        array(
						'type' => 'attach_image',
						'heading' => __( 'Background', 'deeper' ),
						'param_name' => 'bg_image',
						'value' => '',
						'group' => __( 'Background', 'deeper' ),
						'dependency' => array( 'element' => 'icon_style', 'value' => 'icon-left-2' ),
					),
					// Content
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Heading Tag', 'deeper' ),
						'param_name' => 'tag',
						'value'      => array(
							'H1' => 'h1',
							'H2' => 'h2',
							'H3' => 'h3',
							'H4' => 'h4',
							'H5' => 'h5',
							'H6' => 'h6',
						),
						'std'		=> 'h3',
						'group' => __( 'Content', 'deeper' ),
					),
		            array(
						'type' => 'textarea',
						'holder' => 'div',
						'heading' => __( 'Heading', 'deeper' ),
						'param_name' => 'heading',
						'value' => '',
						'group' => __( 'Content', 'deeper' ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Heading Color', 'deeper' ),
						'param_name' => 'heading_color',
						'value' => '',
						'group' => __( 'Content', 'deeper' ),
		            ),
					array(
						'type' 		=> 'textarea_html',
						'heading' 	=> __( 'Description', 'deeper' ),
						'param_name' 	=> 'content',
						'value' 		=> '',
						'group' => __( 'Content', 'deeper' ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Description Color', 'deeper' ),
						'param_name' => 'desc_color',
						'value' => '',
						'group' => __( 'Content', 'deeper' ),
		            ),
					// Button or Link
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'url_showcase',
						'value'      => array(
							'Disable' => '',
							'Link' => 'link',
							'Button' => 'button',
						),
						'std'		=> '',
						'group' => __( 'URL', 'deeper' ),
					),
					// Link
					array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'link_align',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
						'value' => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'medium'
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Link Style', 'deeper' ),
						'param_name' => 'link_style',
						'value' => array(
							'Style 1' 		=> 'style-1',
							'Style 2' 		=> 'style-2',
							'Style 3' 		=> 'style-3',
						),
						'std'		=> 'style-1',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
					),
			        array(
						'type' => 'textfield',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'link_text',
						'value' => 'Read More',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'link_url',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        // Button 
			        array(
						'type' => 'dropdown',
						'heading' => __( 'Alignment', 'deeper' ),
						'param_name' => 'button_align',
						'value' => array(
							'Left' 			=> 'align-left',
							'Center' 		=> 'align-center',
							'Right' 		=> 'align-right',
						),
						'std'		=> 'medium',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Style', 'deeper' ),
						'param_name' => 'button_style',
						'value' => array(
							'Accent' 	=> 'button-accent',
							'Outline Accent' 	=> 'outline-accent',
							'Radical Red' 		=> 'button-radical-red',			
							'Outline Radical Red' 		=> 'outline-radical-red',			
							'Blue' 		=> 'button-blue',			
							'Outline Blue' 		=> 'outline-blue',
							'Green' 		=> 'button-green',			
							'Outline Green' 		=> 'outline-green',	
							'White' 		=> 'button-white',			
							'Custom' 			=> 'custom',
						),
						'std'		=> 'button-accent',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),
					array(
						'type' => 'dropdown',
						'heading' => __( 'Button Size', 'deeper' ),
						'param_name' => 'button_size',
						'value' => array(
							'Small' 		=> 'small',
							'Medium' 		=> 'medium',
							'Big' 			=> 'big',
						),
						'std'		=> 'medium',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
					),	
			        array(
						'type' => 'textfield',
						'heading' => __('Text (Required)', 'deeper'),
						'param_name' => 'button_text',
						'value' => 'Read More',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'button_url',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Link Color', 'deeper'),
						'param_name' => 'link_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Line Color', 'deeper'),
						'param_name' => 'link_line_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Icon Color', 'deeper'),
						'param_name' => 'link_icon_color',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        // Custom
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Custom Button', 'deeper' ),
						'param_name' => 'deeper_heading',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Padding', 'deeper' ),
						'param_name' => 'button_padding',
						'value' => '14px 20px 14px 20px',
						'description'	=> __( 'Top Right Bottom Left.', 'deeper' ),
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Rounded', 'deeper' ),
						'param_name' => 'button_rounded',
						'value' => '',
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Text Color', 'deeper' ),
						'param_name' => 'button_text_color',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Background', 'deeper' ),
						'param_name' => 'button_background',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Border Width', 'deeper' ),
						'param_name' => 'button_border_width',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Button Border Style', 'deeper' ),
						'param_name' => 'button_border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
					),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Border', 'deeper' ),
						'param_name' => 'button_border',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'URL', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Shadow', 'deeper' ),
						'param_name' => 'button_shadow',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'group' => __( 'URL', 'deeper' ),
			        ),	
			        // Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Button', 'deeper' ),
						'param_name' => 'button_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Button: Font Family', 'deeper' ),
						'param_name' => 'button_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Button: Font Weight', 'deeper' ),
						'param_name' => 'button_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Font Size', 'deeper' ),
						'param_name' => 'button_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Line Height', 'deeper' ),
						'param_name' => 'button_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Button: Letter Spacing', 'deeper' ),
						'param_name' => 'button_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button'),
				  	),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'link_extra',
						'value' => '',
						'group' => __( 'URL', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
			        ),
			        // Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Link', 'deeper' ),
						'param_name' => 'link_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Link: Font Family', 'deeper' ),
						'param_name' => 'link_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Link: Font Weight', 'deeper' ),
						'param_name' => 'link_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Font Size', 'deeper' ),
						'param_name' => 'link_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Line Height', 'deeper' ),
						'param_name' => 'link_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Link: Letter Spacing', 'deeper' ),
						'param_name' => 'link_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link'),
				  	),
					
			        // Typography
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Heading', 'deeper' ),
						'param_name' => 'heading_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Heading: Font Family', 'deeper' ),
						'param_name' => 'heading_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Heading: Font Weight', 'deeper' ),
						'param_name' => 'heading_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Heading: Font Size', 'deeper' ),
						'param_name' => 'heading_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Heading: Line Height', 'deeper' ),
						'param_name' => 'heading_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Heading: Letter Spacing', 'deeper' ),
						'param_name' => 'heading_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Description', 'deeper' ),
						'param_name' => 'desc_typograpy',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Description: Font Family', 'deeper' ),
						'param_name' => 'desc_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Description: Font Weight', 'deeper' ),
						'param_name' => 'desc_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Font Size', 'deeper' ),
						'param_name' => 'desc_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Line Height', 'deeper' ),
						'param_name' => 'desc_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Description: Letter Spacing', 'deeper' ),
						'param_name' => 'desc_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
				  	),
				  	// Link Hover
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Link Hover', 'deeper' ),
						'param_name' => 'deeper_link_hover',
						'group' => __( 'Hover', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
					),
					array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Link Color', 'deeper'),
						'param_name' => 'link_hover_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Line Color', 'deeper'),
						'param_name' => 'link_hover_line_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => array( 'style-1', 'style-2' ) ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __('Hover: Icon Color', 'deeper'),
						'param_name' => 'link_hover_icon_color',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'dependency'	=> array( 'element' => 'link_style', 'value' => 'style-3'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'link_parent_hover',
						'group' => __( 'Hover', 'deeper' ),
						'value' => '',
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-content-box', 'deeper' ),
			        ),
				  	// Button Hover
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Button Hover', 'deeper' ),
						'param_name' => 'deeper_heading_hover',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
					),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Text: Hover', 'deeper' ),
						'param_name' => 'button_text_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Background: Hover', 'deeper' ),
						'param_name' => 'button_background_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Button Border: Hover', 'deeper' ),
						'param_name' => 'button_border_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button Shadow: Hover', 'deeper' ),
						'param_name' => 'button_shadow_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'button_parent_hover',
						'value' => '',
						'dependency' => array( 'element' => 'button_style', 'value' => 'custom' ),
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-icon-box', 'deeper' ),
						'group' => __( 'Hover', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'group' => __( 'Hover', 'deeper' ),
						'param_name' => 'button_extra',
						'value' => '',
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
				  	// Icon Hover
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Icon Hover', 'deeper' ),
						'param_name' => 'icon_typograpy',
						'group' => __( 'Hover', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Color: Hover', 'deeper' ),
						'param_name' => 'icon_color_hover',
						'value' => '',
						'group' => __( 'Hover', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Background: Hover', 'deeper' ),
						'param_name' => 'icon_background_hover',
						'value' => '',
						'group' => __( 'Hover', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => __( 'Icon Border: Hover', 'deeper' ),
						'param_name' => 'icon_border_hover',
						'value' => '',
						'group' => __( 'Hover', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Icon Shadow Hover', 'deeper' ),
						'param_name' => 'icon_shadow_hover',
						'value' => '',
						'group' => __( 'Hover', 'deeper' ),
						'description'	=> __( 'Example: 0 8px 25px rgba(0,0,0,0.15)', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Parent Hover (Optional)', 'deeper' ),
						'param_name' => 'icon_parent_hover',
						'value' => 'deeper-icon-box',
						'group' => __( 'Hover', 'deeper' ),
						'description'	=> __( 'Enter the name of the parent class that the effect occurs when mouse over it. Example: deeper-icon-box', 'deeper' ),
						'dependency' => array( 'element' => 'icon_display', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
			        // Spacing
			        array(
						'type' => 'deeper_heading',
						'param_name' => 'deeper_heading_icon_margin',
						'text' => __( 'Icon', 'deeper' ),
						'group' => __( 'Spacing', 'deeper' ),
						'dependency' => array( 'element' => 'icon_type', 'value' => array( 'icon-font', 'icon-text' ) ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon: Margin', 'deeper' ),
						'param_name' => 'icon_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 10px 0px', 'deeper' ),
			        ),
			        array(
						'type' => 'deeper_heading',
						'param_name' => 'deeper_heading_content_padding',
						'text' => __( 'Content: Padding', 'deeper' ),
						'group' => __( 'Spacing', 'deeper' ),
						'dependency' => array( 'element' => 'icon_style', 'value' => array( 'icon-left', 'icon-right' ) ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Content: Left Padding', 'deeper' ),
						'param_name' => 'content_left_padding',
						'value' => '85px',
						'group' => __( 'Spacing', 'deeper' ), 
						'dependency' => array( 'element' => 'icon_style', 'value' => 'icon-left' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Content: Right Padding', 'deeper' ),
						'param_name' => 'content_right_padding',
						'value' => '85px',
						'group' => __( 'Spacing', 'deeper' ), 
						'dependency' => array( 'element' => 'icon_style', 'value' => 'icon-right' ),
			        ),
			        array(
						'type' => 'deeper_heading',
						'param_name' => 'deeper_heading_content_margin',
						'text' => __( 'Content: Margin', 'deeper' ),
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Heading: Top Margin', 'deeper' ),
						'param_name' => 'heading_top_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Heading: Bottom Margin', 'deeper' ),
						'param_name' => 'heading_bottom_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Top Margin', 'deeper' ),
						'param_name' => 'desc_top_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Description: Bottom Margin', 'deeper' ),
						'param_name' => 'desc_bottom_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Button: Margin', 'deeper' ),
						'param_name' => 'button_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 0px 0px', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'button')
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Link: Margin', 'deeper' ),
						'param_name' => 'link_margin',
						'value' => '',
						'group' => __( 'Spacing', 'deeper' ),
						'description'	=> __( 'Top Right Bottom Left. Example: 10px 0px 0px 0px', 'deeper' ),
						'dependency'	=> array( 'element' => 'url_showcase', 'value' => 'link')
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				)
			);
		}
	}
}

new Deeper_IconBox_Shortcode;