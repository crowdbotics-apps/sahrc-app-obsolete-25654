<?php
/**
 * Canvas shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Canvas_Shortcode' ) ) {

	class Deeper_Canvas_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_canvas', array( 'Deeper_Canvas_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_canvas', array( 'Deeper_Canvas_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
				'style' => '',
				// Water Ripples
				'water_bg_rounded' => '',
				'water_bg_image' => '',
				// Canvas Objects
				'canvas' => '',
			), $atts ) );

			$cls = $css = '';
			$output = '';

			// Canvas Background
			switch ( $style ) {
				case 'water':
					wp_enqueue_script('ripples');
					if ( $water_bg_image ) {
						if ( $water_bg_image ) {
							$css .= 'background-image:url('. wp_get_attachment_image_src( $water_bg_image, 'full' )[0] .');';
							$css .= 'background-position:center center;';
							$css .= 'background-repeat:no-repeat;';
							$css .= 'background-size:101%;z-index:0;';
							if ( $water_bg_rounded ) $css .= 'overflow:hidden;border-radius:'. $water_bg_rounded .';';
						}
					}
					$output .= sprintf(
						'<div class="deeper-water-ripples" style="%1$s"></div>',
						$css
					);
					break;
				
				case 'particles':
					wp_enqueue_script('particles');
					$output .=  sprintf(
						'<div id="particles-js" class="deeper-canvas" %1$s></div>',
						$data
					);
					break;

				default:
					# code...
					break;
			}

			// Canvas Objects
			$canvas = vc_param_group_parse_atts( $atts['canvas'] );
			foreach ( $canvas as $key=>$item ) {
				if ( isset( $item['element'] ) ) {
					$cls = $css = '';
					if ( isset( $item['class'] ) ) $cls .= ' ' . $item['class'];

					switch ( $item['element'] ) {
						case 'image':
							if ( isset( $item['image'] ) ) {
								if ( isset($item['image_effect']) ) $cls .=  ' ' . $item['image_effect'];

								$canvas_css = 'position:absolute;';
								$parallax_atts = $top = $mobile_hide = $zoom_duration = $zoom_delay = $smoothness = '';

								// Position
								if ( isset( $item['image_post_top'] ) ) $canvas_css .= 'top:'. $item['image_post_top'] .';';
								if ( isset( $item['image_post_left'] ) ) $canvas_css .= 'left:'. $item['image_post_left'] .';';
								if ( isset( $item['image_post_bottom'] ) ) $canvas_css .= 'bottom:'. $item['image_post_bottom'] .';';
								if ( isset( $item['image_post_right'] ) ) $canvas_css .= 'text-align:right;right:'. $item['image_post_right'] .';';

								isset( $item['parallax_atts'] ) ? $parallax_atts = $item['parallax_atts'] : '';
								isset( $item['smoothness'] ) ? $smoothness = intval( $item['smoothness'] ) : $smoothness = 0;
								isset( $item['top'] ) ? $top = $item['top'] : $top = 0;
								if ( isset( $item['mobile_hide'] ) ) $mobile_hide = $item['mobile_hide'];

								$element = '';
								if ( $item['image'] ) {
									$image_css = '';
									if ( isset( $item['image_width'] ) ) $canvas_css .= 'width:' . $item['image_width'];
									$element = sprintf( '<div class="image-wrap" style="%2$s"><img src="%1$s" alt="Image"></div>', 
										esc_url( wp_get_attachment_image_src( $item['image'], 'full' )[0] ),
										$image_css
										);
								}

								if ( $item['image_effect'] == 'style-1' ) {
									$output .= sprintf( 
										'<div class="deeper-canvas %1$s %7$s" style="%2$s" data-inviewport="yes">
											<div class="parallax-wrap">
												<div class="canvas-item" data-parallax=\'{ %4$s, "smoothness" : %5$s}\' data-top="%6$s">
													%3$s
												</div>
											</div>
										</div>',
										esc_attr( $cls ),
										esc_attr( $canvas_css ),
										$element,
										esc_html( $parallax_atts ),
										esc_html( $smoothness ),
										esc_html( $top ),
										esc_html( $mobile_hide ) );

								} else {
									$zoom_config = '';
									if ( isset( $item['zoom_duration'] ) ) $zoom_config .= 'animation-duration:'. intval( $item['zoom_duration'] ) .'s;';
									if ( isset( $item['zoom_delay'] ) ) $zoom_config .= 'animation-delay:'. intval( $item['zoom_delay'] ) .'s;';
									$output .= sprintf( 
										'<div class="deeper-canvas %1$s %5$s" style="%2$s" data-inviewport="yes"><img src="%3$s" alt="canvas" style="%4$s"></div>',
										esc_attr( $cls ),
										esc_attr( $canvas_css ),
										esc_url( wp_get_attachment_image_src( $item['image'], 'full' )[0] ),
										esc_html( $zoom_config ),
										esc_html( $mobile_hide ) );
								}
							}
							
							break;
						
						case 'morphin':
							$inner_image = '';
							$svg_string = $shape_color = '';
							$cls .= ' ' . $item['shape'];
							$id = 'morph-' . rand();
							
							if ( isset( $item['inner_image'] ) ) 
								$inner_image = sprintf('<a xlink:href="#"><image clip-path="url(#%2$s)" xlink:href="%1$s"></a>', 
									esc_url( wp_get_attachment_image_src( $item['inner_image'], 'full' )[0] ),
									$id );

							isset( $item['shape_color'] ) ? $shape_color = $item['shape_color'] : $shape_color = '#f7f7f7'; 
							
							
							switch ( $item['shape'] ) {
								case 'shape-1':
									$svg_string = 
										'<svg viewBox="0 0 1920 775" preserveAspectRatio="none">
							                <path class="shape" fill="' .  $shape_color . '"
							                    d="M1160.9,762.9C895.1,778.9,564.4,512.2,361,527.2c-32.5,2.4-64.2,4.7-100.9,22.6
												c-92.3,45-100.1,131.7-165.1,135.4c-24,1.4-47.6-9.6-95-31.5c-25.9-12-46.4-24.4-60.6-33.7c7.5,57.2,15,114.4,22.5,171.6
												c686.3,0,1372.6,0,2058.9,0c-4.1-320.7-8.2-641.4-12.3-962C1988.7-128,1959.3-68.7,1920,0C1762.6,274.7,1494.4,742.7,1160.9,762.9z">
							                    
							                    <animate attributeName="d" begin="0s" dur="5s" repeatCount="indefinite" 

							                    values="M1160.9,762.9C895.1,778.9,564.4,512.2,361,527.2c-32.5,2.4-64.2,4.7-100.9,22.6
												c-92.3,45-100.1,131.7-165.1,135.4c-24,1.4-47.6-9.6-95-31.5c-25.9-12-46.4-24.4-60.6-33.7c7.5,57.2,15,114.4,22.5,171.6
												c686.3,0,1372.6,0,2058.9,0c-4.1-320.7-8.2-641.4-12.3-962C1988.7-128,1959.3-68.7,1920,0C1762.6,274.7,1494.4,742.7,1160.9,762.9z;

											    M1140.4,679.1c-236.5,8.7-529.3-138.3-731.2-122.6c-98.8,7.7-147.1,24.5-147.1,24.5
												c-91.1,31.6-115.2,74.6-167.5,63.3c-48.7-10.5-68.1-56.4-112.3-49c-19.9,3.3-34.4,15.7-42.9,24.5c7.5,57.2,15,114.4,22.5,171.6
												c686.3,0,1372.6,0,2058.9,0c-4.1-320.7-8.2-641.4-12.3-962C1992.8-117.7,1966-39.8,1920,48C1901.4,83.5,1589.2,662.7,1140.4,679.1z;

							                    M1160.9,762.9C895.1,778.9,564.4,512.2,361,527.2c-32.5,2.4-64.2,4.7-100.9,22.6
												c-92.3,45-100.1,131.7-165.1,135.4c-24,1.4-47.6-9.6-95-31.5c-25.9-12-46.4-24.4-60.6-33.7c7.5,57.2,15,114.4,22.5,171.6
												c686.3,0,1372.6,0,2058.9,0c-4.1-320.7-8.2-641.4-12.3-962C1988.7-128,1959.3-68.7,1920,0C1762.6,274.7,1494.4,742.7,1160.9,762.9z"/>
							                </path>
						            	</svg>';

									break;
								case 'shape-2':
									$svg_string = sprintf(
										'<svg viewBox="0 0 945 815">
											<g>
											<clipPath id="%1$s">
							                	<path class="shape1" fill="none" 
							                    d="M595.4,799.8c139.6-34.2,350.5-177.7,349-366c-1.3-163.2-64.7-297-344-386C96-113-111.6,172.9,58.3,300.3c176.2,132.2,239.3,150.1,179.1,306.4C161.2,805,389.1,850.4,595.4,799.8z">
							                    <animate attributeName="d" begin="0s" dur="7s" repeatCount="indefinite"

							                    values="M595.4,799.8c139.6-34.2,350.5-177.7,349-366c-1.3-163.2-64.7-297-344-386C96-113-111.6,172.9,58.3,300.3c176.2,132.2,239.3,150.1,179.1,306.4C161.2,805,389.1,850.4,595.4,799.8z;

							                    M649,793c139.6-34.2,266.5-195.3,265-383.6C912.7,246.2,899.3,158,620,69C115.6-91.8-77.9,159.6,92,287
												c176.2,132.2,196.1,160.7,136,317C151.8,802.2,442.7,843.6,649,793z;

												M702,766c139.6-34.2,140.5-69.7,139-258c-1.3-163.2,189.3-314-90-403C246.6-55.8-79.9,237.6,90,365
												c176.2,132.2,159.1,85.7,99,242C112.8,805.2,495.7,816.6,702,766z;

							                    M595.4,799.8c139.6-34.2,350.5-177.7,349-366c-1.3-163.2-64.7-297-344-386C96-113-111.6,172.9,58.3,300.3
												c176.2,132.2,239.3,150.1,179.1,306.4C161.2,805,389.1,850.4,595.4,799.8z"/>
							                	</path>

							                	<path class="shape2" fill="none" 
							                    d="M144.4,659.8c115-66.1,84.6-179.8,7.6-226.9c-93.7-57.3-129.2,32.7-75.6,72.9C135.5,550,60.9,707.8,144.4,659.8z">
							                    <animate attributeName="d" begin="0s" dur="5s" repeatCount="indefinite"

							                    values="M144.4,659.8c115-66.1,84.6-179.8,7.6-226.9c-93.7-57.3-129.2,32.7-75.6,72.9C135.5,550,60.9,707.8,144.4,659.8z;

							                    M210.8,595.8c115-66.1,42.3-130.5-34.8-177.7C82.3,360.8,22.4,551.8,76,592
												C135.1,636.3,127.2,643.8,210.8,595.8z;

							                    M173,623c115-66.1,80-157.7,3-204.9C82.3,360.8,15.4,501.3,69,541.5C128.1,585.8,89.5,671,173,623z;

							                    M144.4,659.8c115-66.1,84.6-179.8,7.6-226.9c-93.7-57.3-129.2,32.7-75.6,72.9C135.5,550,60.9,707.8,144.4,659.8z"/>
							                	</path>
							                </clipPath>
							                </g>	

							                <path class="shape1" fill="none" clip-path="url(#%1$s)"
							                    d="M595.4,799.8c139.6-34.2,350.5-177.7,349-366c-1.3-163.2-64.7-297-344-386C96-113-111.6,172.9,58.3,300.3c176.2,132.2,239.3,150.1,179.1,306.4C161.2,805,389.1,850.4,595.4,799.8z">			
							                </path>

							                <path class="shape2" fill="none" clip-path="url(#%1$s)"
							                    d="M144.4,659.8c115-66.1,84.6-179.8,7.6-226.9c-93.7-57.3-129.2,32.7-75.6,72.9C135.5,550,60.9,707.8,144.4,659.8z">			
							                </path>
							                %2$s
							                </svg>',
							            $id,
							            $inner_image
							        );

									break;
								case 'shape-3':
									$svg_string = sprintf(
										'<svg viewBox="0 0 1020 947">
											<g>
											<clipPath id="%1$s">
							                	<path class="shape1" fill="none" 
							                    d="M294.8,0.1C371-1.6,416.6,32.3,454.1,69.9c45.1,45.1,86.2,106.2,140.5,140.6
												c42.5,26.9,98.2,36.6,151.8,52.8c14.6,4.4,28.2,4.8,42.4,9.4c64.4,21,117.5,36.1,165.9,72.7c10.5,8,18.7,20.2,26.4,31.1
												c16.5,23.5,27.2,49.3,34.9,82.1c2.1,9,3.4,18.1,3.8,27.4c0,5.7,0.2,13.3,0.2,19c-0.5,15.9-2.7,29.5-4,41c-1.9,17.7-21.8,94.5-27,110
												c-17.5,52.4-81.7,180.9-192.2,248.2c-30.1,18.4-63.3,31.2-98.1,37.8c-44,8.1-109.4,7.7-153.7-1.9c-20.2-4.4-56.2-14.3-83.1-28.1
												c-69.1-35.2-123.3-84.1-154.1-154.2c-10.8-24.5-17.6-51.3-25.4-79.3c-4.9-17.7-5.2-37.2-9.4-54.7c-0.6-6.6-1.3-13.2-1.9-19.8
												c-6.4-26.7-7.6-56.4-20.7-76.4c-14.8-22.6-43.5-27.9-74.5-34.9c-19-4.3-39.3,0.6-57.5-3.8c-33.8-8.2-65.2-22.5-83-46.2
												C22.1,424.8,12.2,405,5.3,380.3c-10.9-39-3.2-100.8,7.5-134C45.6,145.6,100,84.5,182.6,34c21.6-13.2,47.6-21.7,74.5-29.3
												C264.3,2.8,290.3,2.9,294.8,0.1z">
							                    <animate attributeName="d" begin="0s" dur="7s" repeatCount="indefinite"

							                    values="M294.8,0.1C371-1.6,416.6,32.3,454.1,69.9c45.1,45.1,86.2,106.2,140.5,140.6
												c42.5,26.9,98.2,36.6,151.8,52.8c14.6,4.4,28.2,4.8,42.4,9.4c64.4,21,117.5,36.1,165.9,72.7c10.5,8,18.7,20.2,26.4,31.1
												c16.5,23.5,27.2,49.3,34.9,82.1c2.1,9,3.4,18.1,3.8,27.4c0,5.7,0.2,13.3,0.2,19c-0.5,15.9-2.7,29.5-4,41c-1.9,17.7-21.8,94.5-27,110
												c-17.5,52.4-81.7,180.9-192.2,248.2c-30.1,18.4-63.3,31.2-98.1,37.8c-44,8.1-109.4,7.7-153.7-1.9c-20.2-4.4-56.2-14.3-83.1-28.1
												c-69.1-35.2-123.3-84.1-154.1-154.2c-10.8-24.5-17.6-51.3-25.4-79.3c-4.9-17.7-5.2-37.2-9.4-54.7c-0.6-6.6-1.3-13.2-1.9-19.8
												c-6.4-26.7-7.6-56.4-20.7-76.4c-14.8-22.6-43.5-27.9-74.5-34.9c-19-4.3-39.3,0.6-57.5-3.8c-33.8-8.2-65.2-22.5-83-46.2
												C22.1,424.8,12.2,405,5.3,380.3c-10.9-39-3.2-100.8,7.5-134C45.6,145.6,100,84.5,182.6,34c21.6-13.2,47.6-21.7,74.5-29.3
												C264.3,2.8,290.3,2.9,294.8,0.1z;

							                    M298.7,11.5C375,9.9,416.6,32.3,454.1,69.9c45.1,45.1,105.1,85,159.5,119.3
												c42.5,26.9,79.2,57.9,132.8,74.1c14.6,4.4,28.2,4.8,42.4,9.4c64.4,21,117.5,36.1,165.9,72.7c10.5,8,18.7,20.2,26.4,31.1
												c16.5,23.5,27.2,49.3,34.9,82.1c2.1,9,3.4,18.1,3.8,27.4c0,5.7,0.2,13.3,0.2,19c-0.5,15.9-2.7,29.5-4,41
												c-1.9,17.7-40.4,90.4-45.5,105.9c-17.5,52.4-63.2,185-173.6,252.3c-30.1,18.4-67.4,18.4-102.1,24.9c-44,8.1-105.3,20.5-149.6,10.9
												c-20.2-4.4-56.2-14.3-83.1-28.1c-69.1-35.2-110.3-87.4-141-157.5c-10.8-24.5-30.6-48-38.5-75.9c-4.9-17.7-5.2-37.2-9.4-54.7
												c-0.6-6.6-1.3-13.2-1.9-19.8c-6.4-26.7-18.3-41.7-31.4-61.7c-14.8-22.6-32.9-42.7-63.8-49.7c-19-4.3-39.3,0.6-57.5-3.8
												c-33.8-8.2-65.2-22.5-83-46.2C22.1,424.8,12.2,405,5.3,380.3c-10.9-39,49.8-104.4,60.6-137.5c32.8-100.8,37.7-151,120.3-201.4
												c21.6-13.2,45.1-20.8,72-28.3C265.4,11,294.2,14.3,298.7,11.5z;

												M294.8,0.1C371-1.6,438.1,15.3,475.7,52.9c45.1,45.1,39.9,140.3,94.2,174.6
												c42.5,26.9,122.8,19.6,176.5,35.8c14.6,4.4,28.2,4.8,42.4,9.4c64.4,21,78.1,28.5,126.5,65c10.5,8,35.2,36.5,42.9,47.5
												c16.5,23.5,28.3,36.2,36,68.9c2.1,9,8.8,24.5,9.2,33.7c0,5.7-6.1,35.7-6.1,41.4c-0.5,15.9-13.3,32.1-14.6,43.7
												c-1.9,17.7-33.9,57.3-39.1,72.8c-17.5,52.4-35.1,118.8-145.5,186.1c-30.1,18.4-67.9,45.6-102.6,52.1c-44,8.1-88.2,17.3-132.5,7.7
												c-20.2-4.4-81.1-17.7-108-31.4c-69.1-35.2-116.3-32.3-147.1-102.4c-10.8-24.5-17.6-51.3-25.4-79.3c-4.9-17.7-5.2-37.2-9.4-54.7
												c-0.6-6.6-1.3-13.2-1.9-19.8c-6.4-26.7-22.1-37.1-35.2-57.1c-14.8-22.6-29-47.3-60-54.3c-19-4.3-42.1,7.4-60.3,3
												c-33.8-8.2-62.4-29.3-80.2-53C22.1,424.8,12.2,405,5.3,380.3c-10.9-39,28.4-239.2,39.1-272.3C77.2,7.3,100,84.5,182.6,34
												c21.6-13.2,47.6-21.7,74.5-29.3C264.3,2.8,290.3,2.9,294.8,0.1z;

							                    M294.8,0.1C371-1.6,416.6,32.3,454.1,69.9c45.1,45.1,86.2,106.2,140.5,140.6
												c42.5,26.9,98.2,36.6,151.8,52.8c14.6,4.4,28.2,4.8,42.4,9.4c64.4,21,117.5,36.1,165.9,72.7c10.5,8,18.7,20.2,26.4,31.1
												c16.5,23.5,27.2,49.3,34.9,82.1c2.1,9,3.4,18.1,3.8,27.4c0,5.7,0.2,13.3,0.2,19c-0.5,15.9-2.7,29.5-4,41c-1.9,17.7-21.8,94.5-27,110
												c-17.5,52.4-81.7,180.9-192.2,248.2c-30.1,18.4-63.3,31.2-98.1,37.8c-44,8.1-109.4,7.7-153.7-1.9c-20.2-4.4-56.2-14.3-83.1-28.1
												c-69.1-35.2-123.3-84.1-154.1-154.2c-10.8-24.5-17.6-51.3-25.4-79.3c-4.9-17.7-5.2-37.2-9.4-54.7c-0.6-6.6-1.3-13.2-1.9-19.8
												c-6.4-26.7-7.6-56.4-20.7-76.4c-14.8-22.6-43.5-27.9-74.5-34.9c-19-4.3-39.3,0.6-57.5-3.8c-33.8-8.2-65.2-22.5-83-46.2
												C22.1,424.8,12.2,405,5.3,380.3c-10.9-39-3.2-100.8,7.5-134C45.6,145.6,100,84.5,182.6,34c21.6-13.2,47.6-21.7,74.5-29.3
												C264.3,2.8,290.3,2.9,294.8,0.1z"/>
							                	</path>
							                </clipPath>
							                </g>	

							                <path class="shape1" fill="none" clip-path="url(#%1$s)"
							                    d="M294.8,0.1C371-1.6,416.6,32.3,454.1,69.9c45.1,45.1,86.2,106.2,140.5,140.6
												c42.5,26.9,98.2,36.6,151.8,52.8c14.6,4.4,28.2,4.8,42.4,9.4c64.4,21,117.5,36.1,165.9,72.7c10.5,8,18.7,20.2,26.4,31.1
												c16.5,23.5,27.2,49.3,34.9,82.1c2.1,9,3.4,18.1,3.8,27.4c0,5.7,0.2,13.3,0.2,19c-0.5,15.9-2.7,29.5-4,41c-1.9,17.7-21.8,94.5-27,110
												c-17.5,52.4-81.7,180.9-192.2,248.2c-30.1,18.4-63.3,31.2-98.1,37.8c-44,8.1-109.4,7.7-153.7-1.9c-20.2-4.4-56.2-14.3-83.1-28.1
												c-69.1-35.2-123.3-84.1-154.1-154.2c-10.8-24.5-17.6-51.3-25.4-79.3c-4.9-17.7-5.2-37.2-9.4-54.7c-0.6-6.6-1.3-13.2-1.9-19.8
												c-6.4-26.7-7.6-56.4-20.7-76.4c-14.8-22.6-43.5-27.9-74.5-34.9c-19-4.3-39.3,0.6-57.5-3.8c-33.8-8.2-65.2-22.5-83-46.2
												C22.1,424.8,12.2,405,5.3,380.3c-10.9-39-3.2-100.8,7.5-134C45.6,145.6,100,84.5,182.6,34c21.6-13.2,47.6-21.7,74.5-29.3
												C264.3,2.8,290.3,2.9,294.8,0.1z">			
							                </path>
							                %2$s
							                </svg>',
							            $id,
							            $inner_image
							        );

									break;
							}
							
							$output .= sprintf( '<div class="deeper-morph %2$s">%1$s</div>',
							 	$svg_string,
							 	$cls
							);
						
							break;
						
						case 'svg':
							$icon_string = dtp_get_svg( $item['svg'] );
							$css = '';
							if ( isset( $item['svg_color'] ) ) $css .= 'stroke:'. $item['svg_color'] .';';
							if ( isset( $item['svg_width'] ) ) $css .= 'width:'. $item['svg_width'] .';';
							if ( isset( $item['svg_rotate'] ) ) $css .= 'transform:rotate('. $item['svg_rotate'] .');';

							$output = sprintf( 
								'<div class="deeper-svg draw" data-inviewport="yes">
									<div class="svg-wrap" style="%2$s">%1$s</div>
								</div>',
								$icon_string,
								$css
							);
							
							break;
					}
				}
			}

			return $output;
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Canvas', 'deeper' ),
		        'description' => __( 'Animation Background.', 'deeper' ),
		        'base' => 'deeper_canvas',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/herocarousels.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type' => 'dropdown',
						'heading' => __( 'Style', 'deeper' ),
						'param_name' => 'style',
						'value' => array(
							'Disable' => '',
							'Water Ripples' => 'water',
							'Particles' 	=> 'particles',
						),
						'std'		=> '',
						'group' => esc_html__( 'Canvas Background', 'deeper' ),
					),
					// Water Ripples
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Background Rounded', 'deeper'),
						'param_name' => 'water_bg_rounded',
						'value' => '',
						'dependency' => array( 'element' => 'style', 'value' => 'water' ),
						'description' => esc_html__( 'Ex: 10px' ,'depper'),
						'group' => esc_html__( 'Canvas Background', 'deeper' ),
					),
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Background Image', 'deeper'),
						'param_name' => 'water_bg_image',
						'value' => '',
						'dependency' => array( 'element' => 'style', 'value' => 'water' ),
						'group' => esc_html__( 'Canvas Background', 'deeper' ),
					),
					// Object
					array(
		            'type' => 'param_group',
		            'value' => '',
		            'param_name' => 'canvas',
		            'group' => esc_html__( 'Canvas Object', 'deeper' ),
		            'params' => array(
		            	array(
		                    'type' => 'dropdown',
		                    'heading' => esc_html__( 'Element', 'deeper' ),
		                    'param_name' => 'element',
		                    'value'      => array(
		                    	''		=> '',
		                    	'Image' => 'image', 
		                        'Morphin Shape' => 'morphin'      
		                    ),
		                    'std'       => '',
		                ),
		                array(
				            'type' => 'dropdown',
				            'heading' => esc_html__( 'Background Shape Morphin', 'deeper' ),
				            'param_name' => 'shape',
				            'value' => array(
				                'Wave' => 'shape-1',
				                'Blob 1' => 'shape-2',
				                'Blob 2' => 'shape-3',
				            ),
				            'std' => 'shape-1',
				            'dependency' => array( 'element' => 'element', 'value' => 'morphin' ),
				        ),
						array(
				            "type" => "colorpicker",
				            "heading" => esc_html__( 'Shape Color', 'deeper' ),
				            "param_name" => "shape_color",
				            'value' => '',
				            'dependency' => array( 'element' => 'element', 'value' => 'morphin' ),
				        ),
				        array(
		                    'type' => 'attach_image',
		                    'heading' => esc_html__( 'Inner Image', 'deeper' ),
		                    'param_name' => 'inner_image',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'morphin' ),
		                ),
		                // Image
		                array(
		                    'type' => 'attach_image',
		                    'heading' => esc_html__( 'Image', 'deeper' ),
		                    'param_name' => 'image',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'dropdown',
		                    'heading' => esc_html__( 'Hide on mobile?', 'deeper' ),
		                    'param_name' => 'mobile_hide',
		                    'value'      => array(
		                    	'No' => '',
		                        'Yes' => 'hide-on-mobile',       
		                    ),
		                    'std'       => '',
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__( 'Image Width', 'deeper' ),
		                    'param_name' => 'image_width',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Left', 'deeper'),
		                    'param_name' => 'image_post_left',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Top', 'deeper'),
		                    'param_name' => 'image_post_top',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Right', 'deeper'),
		                    'param_name' => 'image_post_right',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Bottom', 'deeper'),
		                    'param_name' => 'image_post_bottom',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type'       => 'dropdown',
		                    'heading'    => esc_html__( 'Element: Effect', 'deeper' ),
		                    'param_name' => 'image_effect',
		                    'value'      => array(
		                        'Parallax' 	=> 'style-1',
		                        'Zoom' 		=> 'style-2',
		                        'Moving'   	=> 'style-3',
		                        'Shake'    	=> 'style-4',
		                        'Bounce'    => 'style-5',
		                    ),
		                    'std'       => 'style-1',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
				            'type' => 'textfield',
				            'heading' => esc_html__('Parallax Attributes', 'deeper'),
				            'param_name' => 'parallax_atts',
				            'description'   => esc_html__('Ex: "x": 10, "y": 20. Values Possible: x, y, z, rotateX, rotateY, rotateZ, scaleX, scaleY, scaleZ, scale.', 'deeper'),
				            'dependency' => array( 'element' => 'image_effect', 'value' => 'style-1' ),
				        ),
				        array(
				            'type' => 'textfield',
				            'heading' => esc_html__('Smoothness', 'deeper'),
				            'param_name' => 'smoothness',
				            'value' => '30',
				            'description'   => esc_html__('Slowdown the animation.', 'deeper'),
				            'dependency' => array( 'element' => 'image_effect', 'value' => 'style-1' ),
				        ),
						array(
							'type' => 'textfield',
							'heading' => esc_html__('Duration', 'deeper'),
							'param_name' => 'zoom_duration',
							'value' => '',
							'dependency' => array( 'element' => 'image_effect', 'value' => array( 'style-2' ) ),
						),
						array(
							'type' => 'textfield',
							'heading' => esc_html__('Delay', 'deeper'),
							'param_name' => 'zoom_delay',
							'value' => '',
							'dependency' => array( 'element' => 'image_effect', 'value' => array( 'style-2' ) ),
						),
						array(
							'type' => 'textfield',
							'heading' => esc_html__('Extra Class', 'deeper'),
							'param_name' => 'class',
							'value' => '',
						),
		            )                
		        )
		        )
		    );
		}
	}

	new Deeper_Canvas_Shortcode;
}
