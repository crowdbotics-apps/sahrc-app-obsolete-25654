<?php
/**
 * Parallax_Item shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Parallax_Item_Shortcode' ) ) {

	class Deeper_Parallax_Item_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_parallaxitem', array( 'Deeper_Parallax_Item_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_parallaxitem', array( 'Deeper_Parallax_Item_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			$cls = $css = $icon_css = $inner_css = $image_html = $icon_html = $data = '';

			extract( shortcode_atts( array(
				'image' => '',
				'image_width' => '',
				'image_rounded' => '',
				'stretch' => '',
				'parallax_x' => '',
				'parallax_y' => '',
				'smoothness' => '30',
				'left' => '',
				'right' => '',
				'top' => '',
				'class' => '',
			    'shadow' => '',

			    'icon_style' => 'style-1',
				'video_url' => '',

			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			if ( ! empty( $left ) ) $css .= 'left:'. $left .';';
			if ( ! empty( $right ) ) $css .= 'left:auto;right:'. $right .';';
			if ( ! empty( $top ) ) $css .= 'margin-top:'. $top .';';
			if ( $image ) $image_html .= '<img class="parallax-image" src="'. wp_get_attachment_image_src( $image, 'full' )[0] .'" alt="image">';
			
			if ( $image_width ) {
				$cls = 'has-width';
				$css .= 'width:'. $image_width .';';
			}
			if ( $class ) $cls .= ' ' . $class;

			if ( $image_rounded ) $css .= 'border-radius:'. $image_rounded .';';

			if ( $shadow )
			    $css .= 'box-shadow:' . $shadow . ';';

			if ( $video_url ) {
				$icon_cls = $icon_style;

				wp_enqueue_script( 'magnificpopup' );
				$icon_html = sprintf(
					'<a class="deeper-video-icon popup-video %2$s" href="%1$s" style="%3$s">
						<span class="icon"><i class="fa fa-play"></i></span>
					</a>',

					$video_url,
					$icon_cls,
					$icon_css
				);
			}

			//Animation
			if ( $animation ) {
				$anim_cls = ' wow '. $animation_effect;
		    	$anim_data = 'data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';	

		    	return sprintf(
					'<div class="%8$s" %9$s><div class="deeper-parallax-item %7$s" %9$s style="%2$s" data-parallax=\'{"x" : %3$s,"y" : %4$s, "smoothness" : %5$s}\' data-top="%6$s">%1$s</div></div>',
					$image_html,
					$css,
					intval( $parallax_x ),
					intval( $parallax_y ),
					intval ( $smoothness ),
					$top,
					$cls,
					$anim_cls,
					$anim_data,
					$icon_html
				);   
			} else {
				return sprintf(
					'<div class="deeper-parallax-item %7$s" style="%2$s" data-parallax=\'{"x" : %3$s,"y" : %4$s, "smoothness" : %5$s}\' data-top="%6$s">%1$s %8$s</div>',
					$image_html,
					$css,
					intval( $parallax_x ),
					intval( $parallax_y ),
					intval ($smoothness ),
					$top,
					$cls,
					$icon_html
				);
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Parallax Item', 'deeper' ),
		        'description' => __( 'Parallax Item for Parallax Box.', 'deeper' ),
		        'base' => 'parallaxitem',
				'weight'	=>	180,
				'as_child' => array( 'only' => 'deeper_parallaxbox' ),
		        'icon' => plugins_url( '../../assets/icon/parallaxbox.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params'      => array(
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Image', 'deeper'),
						'param_name' => 'image',
						'value' => '',
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Width', 'deeper'),
						'param_name' => 'image_width',
						'value' => '',
						'description'	=> esc_html__('You can use % or px value. Ex: 50%.', 'deeper'),
			        ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Image Rounded', 'deeper'),
						'param_name' => 'image_rounded',
						'value' => '',
						'description'	=> esc_html__('Ex: 5px', 'deeper'),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Box Shadow', 'deeper'),
						'param_name' => 'shadow',
						'value' => '',
		            ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Parallax X', 'deeper'),
			            'param_name' => 'parallax_x',
			            'description'   => esc_html__('X axis translation.', 'deeper'),
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Parallax Y', 'deeper'),
			            'param_name' => 'parallax_y',
			            'description'   => esc_html__('Y axis translation.', 'deeper'),
			        ),
			        array(
			            'type' => 'textfield',
			            'heading' => esc_html__('Smoothness', 'deeper'),
			            'param_name' => 'smoothness',
			            'value' => '30',
			            'description'   => esc_html__('Slowdown the animation.', 'deeper'),
			        ),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Left', 'deeper'),
						'param_name' => 'left',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Right', 'deeper'),
						'param_name' => 'right',
						'value' => '',
					),
					array(
						'type' => 'textfield',
						'heading' => esc_html__('Top', 'deeper'),
						'param_name' => 'top',
						'value' => '',
					),

					// Video Icon
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Style', 'deeper' ),
						'param_name' => 'icon_style',
						'value'      => array(
							'Style 1' => 'style-1',
							'Style 2' => 'style-2',
						),
						'std'		=> 'style-1',
						'group' => esc_html__( 'Video Icon', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Link Youtube/Vimeo (URL)', 'deeper'),
						'param_name' => 'video_url',
						'value' => '',
						'group' => esc_html__( 'Video Icon', 'deeper' ),
			        ),

		            // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'nusafe' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'value'      => array( esc_html__( 'Yes, please.', 'nusafe' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'nusafe' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'nusafe'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'nusafe'),
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'nusafe'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'nusafe'),
						'group' => esc_html__( 'Animation', 'nusafe' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ), 
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'nusafe'),
						'param_name' => 'class',
						'value' => '',
		            ),   
				)
		    );
		}
	}
}

new Deeper_Parallax_Item_Shortcode;