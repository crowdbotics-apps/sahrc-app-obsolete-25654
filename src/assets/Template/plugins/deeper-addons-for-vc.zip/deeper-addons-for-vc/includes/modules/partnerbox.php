<?php
/**
 * Partner_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Partner_Box_Shortcode' ) ) {

	class Deeper_Partner_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_partnerbox', array( 'Deeper_Partner_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_partnerbox', array( 'Deeper_Partner_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			$cls = $css = '';

			extract( shortcode_atts( array(
				'hover_effect' => 'hover-effect-1',
			    'partner_logo' => '',
			    'partner_url' => '',
			    'class' => '',
			    // Design
			    'bg_color' => '',	    
			    'rounded' => '',	    
			    'shadow' => '',	    
			), $atts ) );

			$cls = $hover_effect . ' ' . $class;

			if ( $bg_color ) $css .= 'background-color:' . $bg_color . ';';
			if ( $rounded ) $css .= 'border-radius:' . $rounded . ';';
			if ( $shadow ) $css .= 'box-shadow:' . $shadow . ';';

			if ( $partner_url ) {
				return sprintf(
					'<div class="deeper-partner %3$s" style="%4$s">
						<div class="partner-logo"><a href="%2$s"><img alt="Logo" src="%1$s"></a></div>
					</div>',
					esc_url( wp_get_attachment_image_src( $partner_logo, 'full' )[0] ),
					esc_url(  vc_build_link( $partner_url )['url'] ),
					esc_attr( $cls ),
					esc_attr( $css )
				);
			} else {
				return sprintf(
					'<div class="deeper-partner %2$s" style="%3$s">
						<div class="partner-logo"><img alt="Logo" src="%1$s"></div>
					</div>',
					esc_url( wp_get_attachment_image_src( $partner_logo, 'full' )[0] ),
					esc_attr( $cls ),
					esc_attr( $css )
				);
			}			
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Partner Box', 'deeper' ),
		        'description' => __( 'Display a custom Partner Box.', 'deeper' ),
		        'base' => 'deeper_partnerbox',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/partner.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Hover Effect', 'deeper' ),
						'param_name' => 'hover_effect',
						'value'      => array(
							'Opacity' => 'hover-effect-1',
							'Scale' => 'hover-effect-2',
							'Grayscale' => 'hover-effect-3',
							'Fixed Style 1' => 'hover-effect-4',
						),
						'std'		=> 'hover-effect-1',
					),
			        array(
						'type' => 'attach_image',
						'heading' => esc_html__('Partner Logo', 'deeper'),
						'param_name' => 'partner_logo',
						'value' => '',
					),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'Partner Url', 'deeper' ),
						'param_name' => 'partner_url',
						'value' => ''
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Classes', 'deeper' ),
						'param_name' => 'class',
						'value' => ''
			        ),
			        // Design
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Background Color', 'deeper' ),
						'param_name' => 'bg_color',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Rounded', 'deeper' ),
						'param_name' => 'rounded',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Box Shadow', 'deeper' ),
						'param_name' => 'shadow',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
			        ),
		        )
		    );
		}
	}

	new Deeper_Partner_Box_Shortcode;
}
