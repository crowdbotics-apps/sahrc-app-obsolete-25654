<?php
/**
 * Progress Bar shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Progress_Bar_Shortcode' ) ) {

	class Deeper_Progress_Bar_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_progressbar', array( 'Deeper_Progress_Bar_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_progressbar', array( 'Deeper_Progress_Bar_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			// Exit if accessed directly
			if ( ! defined( 'ABSPATH' ) ) {
			    exit;
			}

			$cls = $cls1 = $wrap_css = $css = $pcls = $pcss = $css1 = $css2 = $heading = $per = '';

			extract( shortcode_atts( array(
				'heading' => '',
				'heading_color' => '',

				'desc' => '',
				'desc_color' => '',

				'percent' => '90',
				'per_color' => '',

				'space_between' => '10px',
				'height' => '10px',

				'rounded' => '',
				'bottom_margin' => '',

				'line_one' => '',
				'line_two' => '',

				'font_family' => '',
				'font_weight' => '',
				'font_size' => '',
				'per_font_family' => '',
				'per_font_weight' => '',
				'per_font_size' => '',
				'class' => '',
			), $atts ) );
			$accent = deeper_get_accent_color();

			$cls;
			if ( $class ) $cls .= ' ' . $class;

			if ( $line_one == $accent ) { $cls1 .= ' bg-accent';
			} elseif ( $line_one ) { $css1 = 'background-color:'. $line_one .';'; }

			if ( $height ) {
				$css1 .= 'height:'. intval( $height ) .'px;';
				$css2 .= 'height:'. intval( $height ) .'px;';
			}

			if ( $line_two ) $css2 .= 'background-color:'. $line_two .';';
			if ( $rounded ) {
				$css1 .= 'border-radius:'. intval( $rounded ) .'px;';
				$css2 .= 'border-radius:'. intval( $rounded ) .'px;';
			}

			if ( $font_weight ) $css .= 'font-weight:'. $font_weight .';';
			if ( $heading_color ) $css .= 'color:'. $heading_color .';';
			if ( $font_size ) $css .= 'font-size:'. intval( $font_size ) .'px;';
			if ( $font_family ) {
				deeper_enqueue_google_font( $font_family );
				$css .= 'font-family:'. $font_family .';';
			}

			if ( $per_color == $accent ) { $pcls .= ' color-accent';
			} else if ( $per_color ) { $pcss .= 'color:'. $per_color .';'; }

			if ( ! empty( $heading ) )
				$heading = '<div class="heading" style="'. $css .'">'. esc_html( $heading ) .'</div>';
			if ( ! empty( $percent ) )
				$per = '<div class="perc-wrap" style="'. $css .'"><div class="perc '. $pcls .'" style="'. $pcss .'"><span>'. intval( $percent ) .'<span class="suffix">%</span></span></div></div>';
			if ( $desc ) 
				$desc = '<div class="desc">' . esc_html( $desc ) . '</div>'; 

			if ( $space_between ) $css2 .= 'margin-top:'. intval( $space_between ) .'px;';

			wp_enqueue_script( 'appear' );

			return sprintf( 
				'<div class="deeper-progress clearfix %7$s" style="%6$s">
					%1$s
					%2$s
					%9$s
					<div class="progress-bar" style="%4$s">
						<div class="progress-animate %8$s" data-valuemax="100" data-valuemin="0" data-valuenow="%3$s" style="%5$s" data-inviewport="yes">
						</div>
					</div>
				</div>',

				$heading,
				$per,
				intval( $percent ) . '%',
				$css2,
				$css1,
				$wrap_css,
				$cls,
				$cls1,
				$desc
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Progress Bar', 'deeper' ),
		        'description' => __( 'Displaying Progress Bar.', 'deeper' ),
		        'base' => 'progressbar',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/progressbar.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__('Heading', 'deeper'),
						'param_name' => 'heading',
						'value' => '',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Heading Color', 'deeper'),
						'param_name' => 'heading_color',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => esc_html__('Description', 'deeper'),
						'param_name' => 'desc',
						'value' => '',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Description Color', 'deeper'),
						'param_name' => 'desc_color',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Percentage', 'deeper'),
						'param_name' => 'percent',
						'value' => '90',
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Percentage Color', 'deeper'),
						'param_name' => 'per_color',
						'value' => '',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Height of Bars', 'deeper'),
						'param_name' => 'height',
						'value' => '10px',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Space between Text & Line', 'deeper'),
						'param_name' => 'space_between',
						'value' => '10px',
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Rounded', 'deeper'),
						'param_name' => 'rounded',
						'value' => '',
						'description'	=> esc_html__('Example: 5px', 'deeper'),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Bottom Margin', 'deeper'),
						'param_name' => 'bottom_margin',
						'value' => '',
						'description'	=> esc_html__('Example: 20px', 'deeper'),
			        ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Line 1', 'deeper'),
						'param_name' => 'line_one',
						'value' => '',
						'group' => esc_html__( 'Line Color', 'deeper' ),
		            ),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Line 2', 'deeper'),
						'param_name' => 'line_two',
						'value' => '',
						'group' => esc_html__( 'Line Color', 'deeper' ),
		            ),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Font Family', 'deeper' ),
						'param_name' => 'preheading_font_family',
						'group' => __( 'Typography', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Font Weight', 'deeper' ),
						'param_name' => 'font_weight',
						'value'      => array(
							'Default'		=> '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> '',
						'group' => esc_html__( 'Typography', 'deeper' ),
					),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Font Size', 'deeper'),
						'param_name' => 'font_size',
						'value' => '',
						'group' => esc_html__( 'Typography', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Extra Class', 'deeper'),
						'param_name' => 'class',
						'value' => '',
			        ),
		        )
		    );
		}
	}

	new Deeper_Progress_Bar_Shortcode;
}

