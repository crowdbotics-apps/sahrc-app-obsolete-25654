<?php
/**
 * Content Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_contentbox extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_ContentBox_Shortcode' ) ) {

	class Deeper_ContentBox_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_contentbox', array( 'Deeper_ContentBox_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_contentbox', array( 'Deeper_ContentBox_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			
			extract( shortcode_atts( array(
			    'class' => '',
			    'bg_image' => '',
			    'bg_position' => 'left top',
			    'bg_repeat' => 'no-repeat',
			    'bg_size' => '',
			    'alignment' => '',
			    'd_width' => '',
			    'd_height' => '',
			    'padding' => '0',
			    'mobile_padding' => '0',
			    'margin' => '0',
			    'mobile_margin' => '0',
			    'background_color' => '',
			    'border_color' => '',
			    'border_width' => '',
			    'border_style' => 'solid',
			    'rounded' => '',
			    'shadow' => '',
			    'background_color_hover' => '',
			    'border_color_hover' => '',
			    'border_width_hover' => '',
			    'border_style_hover' => '',
			    'rounded_hover' => '',
			    'shadow_hover' => '',
			    'translatex' => '0',
			    'translatey' => '0',
			    // Animation
			    'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );

			$cls = $css = $data = $inner_cls = $inner_css = $data_inner = $data_inner_hover = '';
			$accent = deeper_get_accent_color();
			$config = array();

			// Content Wrap
			$cls = 'ctb-' . rand();
			if ( $class ) $cls .= ' ' . $class;

			// Spacing
			$config['padding'] = $padding;
			$config['mobiPadding'] = $mobile_padding;
			$config['margin'] = $margin;
			$config['mobiMargin'] = $mobile_margin;

			// Style
			if ( $alignment == 'center' ) $cls .= ' display-flex justify-content-center align-center';
			if ( $alignment == 'right' ) $cls .= ' display-flex justify-content-flex-end';

			if ( $bg_image ) {
				$inner_css .= 'background-image:url('. wp_get_attachment_image_src( $bg_image, 'full' )[0] .');';
				$inner_css .= 'background-position:'. $bg_position .';';
				$inner_css .= 'background-repeat:'. $bg_repeat .';';
				if ( $bg_size ) $inner_css .= 'background-size:'. $bg_size .';';
			}
			
			if ( $d_width ) $css .= ' width:'. $d_width .';';
			if ( $d_height ) $css .= ' height:'. $d_height .';'; 

			// Inner
			if ( $background_color == $accent ) {
			    $inner_cls .= ' bg-accent';
			} else {
				if ( $background_color ) $config['bg'] = $background_color;
			}
				
			if ( $rounded ) {
				$config['round'] = $rounded;
				$inner_css .= 'overflow:hidden;';
			}

			if ( $border_width ) $config['border'] = $border_width;
			if ( $border_style ) $config['borderStyle'] = $border_style;
			if ( $border_color ) $config['borderColor'] = $border_color;



			if ( $shadow) $config['shadow'] = $shadow ;
		
			// Hover
			if ( $background_color_hover ) $config['bgHover'] = $background_color_hover;
			if ( $rounded_hover ) $config['roundHover'] = $rounded_hover;
			if ( $border_color_hover ) $config['borderColorHover'] = $border_color_hover;
			if ( $border_width_hover ) $config['borderWidthHover'] = $border_width_hover;
			if ( $border_style_hover ) $config['borderStyleHover'] = $border_style_hover;
			if ( $shadow_hover ) $config['shadowHover'] = $shadow_hover;

			if ( $translatex ) $config['translateXHover'] = $translatex .'px';
			if ( $translatey ) $config['translateYHover'] = $translatey .'px';	

			$data = 'data-config=\'' . json_encode( $config ) . '\'';

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			return sprintf(
				'<div class="deeper-content-box clearfix %1$s" style="%2$s" %3$s>
					<div class="inner %5$s" style="%6$s">
						%4$s
					</div>
				</div>',
				$cls,
				$css,
				$data,
				do_shortcode( $content ),
				$inner_cls,
			    $inner_css
			);					
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
				'name' => esc_html__('Content Box', 'deeper'),
				'description' => esc_html__('Content Box.', 'deeper'),
				'base' => 'contentbox',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/contentbox.png', __FILE__ ),
				'as_parent' => array('except' => 'deeper_contentbox'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
				'params' => array(
					array(
						'type' => 'attach_image',
						'heading' => esc_html__('Background Image', 'deeper'),
						'param_name' => 'bg_image',
						'value' => '',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Background Position', 'deeper' ),
						'param_name'  => 'bg_position',
						'value'       => array(
							'Left Top' 		=> 'left top',
							'Right Top' 	=> 'right top',
							'Center Top' 	=> 'center top',
							'Center Center' => 'center center',
							'Center Bottom' => 'center bottom',
							'Left Bottom' 	=> 'left bottom',
							'Right Bottom'  => 'right bottom',
						),
						'std'		=> 'left top',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Background Repeat', 'deeper' ),
						'param_name'  => 'bg_repeat',
						'value'       => array(
							'No Repeat' => 'no-repeat',
							'Repeat'   	=> 'repeat',
							'Repeat X'  => 'repeat-x',
							'Repeat Y'  => 'repeat-y',
						),
						'std'		=> 'no-repeat',
					),
					array(
						'type'        => 'dropdown',
						'heading'     => esc_html__( 'Background Size', 'deeper' ),
						'param_name'  => 'bg_size',
						'value'       => array(
							'Auto' 	   => '',
							'Cover'        => 'cover',
						),
						'std'		=> '',
					),			        
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Extra Class', 'deeper' ),
						'param_name'  => 'class',
						'description' => esc_html__( 'Addition class name to refer to it in your css file.', 'deeper' )
					),
		            // Spacing
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Alignment', 'deeper' ),
						'param_name' => 'alignment',
						'value'      => array(
							'Left' => 'left',
							'Center' => 'center',
							'Right' => 'right',
						),
						'std'		=> 'left',
						'group' => esc_html__( 'Spacing', 'deeper' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Width', 'deeper'),
						'param_name' => 'd_width',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
						'description'	=> esc_html__('Can be px or %. Ex: 600px, 50%', 'deeper'),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Height', 'deeper'),
						'param_name' => 'd_height',
						'value' => '',
						'group' => esc_html__( 'Spacing', 'deeper' ),
						'description'	=> esc_html__('Can be px or %. Ex: 400px, 100%', 'deeper'),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Padding', 'deeper'),
						'param_name' => 'padding',
						'value' => '0',
						'description'	=> esc_html__('Top Right Bottom Left. You can use % or px value.', 'deeper'),
						'group' => esc_html__( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Padding on mobile', 'deeper'),
						'param_name' => 'mobile_padding',
						'value' => '0',
						'description'	=> esc_html__('Top Right Bottom Left. You can use % or px value.', 'deeper'),
						'group' => esc_html__( 'Spacing', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Margin', 'deeper'),
						'param_name' => 'margin',
						'value' => '0',
						'group' => esc_html__( 'Spacing', 'deeper' ),
						'description'	=> esc_html__('Top Right Bottom Left. You can use % or px value.', 'deeper'),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Margin on mobile', 'deeper'),
						'param_name' => 'mobile_margin',
						'value' => '0',
						'group' => esc_html__( 'Spacing', 'deeper' ), 
						'description'	=> esc_html__('Top Right Bottom Left. You can use % or px value.', 'deeper'),
			        ),
		            // Design
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Background', 'deeper'),
						'param_name' => 'heading_background',
						'group' => esc_html__( 'Design', 'deeper' ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Background Color', 'deeper'),
						'param_name' => 'background_color',
						'value' => '',
						'group' => esc_html__( 'Design', 'deeper' ),
		            ),
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Border', 'deeper'),
						'param_name' => 'heading_border',
						'group' => esc_html__( 'Design', 'deeper' ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Border Color', 'deeper'),
						'param_name' => 'border_color',
						'value' => '',
						'group' => esc_html__( 'Design', 'deeper' ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Border Width', 'deeper'),
						'param_name' => 'border_width',
						'value' => '',
						'description'	=> esc_html__('Top Right Bottom Left. Ex: 0px 0px 1px 0px', 'deeper'),
						'group' => esc_html__( 'Design', 'deeper' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Border Style', 'deeper' ),
						'param_name' => 'border_style',
						'value'      => array(
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> 'solid',
						'group' => esc_html__( 'Design', 'deeper' ),
					),
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Rounded', 'deeper'),
						'param_name' => 'heading_rounded',
						'group' => esc_html__( 'Design', 'deeper' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Rounded', 'deeper'),
						'param_name' => 'rounded',
						'value' => '',
						'description'	=> esc_html__('Ex: 6px', 'deeper'),
						'group' => esc_html__( 'Design', 'deeper' ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Box Shadow', 'deeper'),
						'param_name' => 'shadow',
						'value' => '',
						'group' => esc_html__( 'Design', 'deeper' ),
			        ),
			        // Hover
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Background', 'deeper'),
						'param_name' => 'heading_background_hover',
						'group' => esc_html__( 'Hover', 'deeper' ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Background Color', 'deeper'),
						'param_name' => 'background_color_hover',
						'value' => '',
						'group' => esc_html__( 'Hover', 'deeper' ),
		            ),
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Border', 'deeper'),
						'param_name' => 'heading_border_hover',
						'group' => esc_html__( 'Hover', 'deeper' ),
					),
		            array(
						'type' => 'colorpicker',
						'heading' => esc_html__('Border Color', 'deeper'),
						'param_name' => 'border_color_hover',
						'value' => '',
						'group' => esc_html__( 'Hover', 'deeper' ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Border Width', 'deeper'),
						'param_name' => 'border_width_hover',
						'value' => '',
						'description'	=> esc_html__('Top Right Bottom Left. Ex: 0px 0px 1px 0px', 'deeper'),
						'group' => esc_html__( 'Hover', 'deeper' ),
			        ),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Border Style', 'deeper' ),
						'param_name' => 'border_style_hover',
						'value'      => array(
							'None' => '',
							'Solid' => 'solid',
							'Dotted' => 'dotted',
							'Dashed' => 'dashed'
						),
						'std'		=> '',
						'group' => esc_html__( 'Hover', 'deeper' ),
					),
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Rounded', 'deeper'),
						'param_name' => 'heading_rounded_hover',
						'group' => esc_html__( 'Hover', 'deeper' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Rounded', 'deeper'),
						'param_name' => 'rounded_hover',
						'value' => '',
						'description'	=> esc_html__('Ex: 6px', 'deeper'),
						'group' => esc_html__( 'Hover', 'deeper' ),
		            ),
			        array(
						'type' => 'textfield',
						'heading' => esc_html__('Box Shadow', 'deeper'),
						'param_name' => 'shadow_hover',
						'value' => '',
						'group' => esc_html__( 'Hover', 'deeper' ),
			        ),
					array(
						'type' => 'deeper_heading',
						'text' => esc_html__('Transforms', 'deeper'),
						'param_name' => 'heading_transforms',
						'group' => esc_html__( 'Hover', 'deeper' ),
					),
					array(
						'type' => 'deeper_number',
						'heading' => esc_html__('Translate X', 'deeper'),
						'param_name' => 'translatex',
						'value' => 0,
						'suffix' => 'px',
						'group' => esc_html__( 'Hover', 'deeper' ),
				  	),
					array(
						'type' => 'deeper_number',
						'heading' => esc_html__('Translate Y', 'deeper'),
						'param_name' => 'translatey',
						'value' => 0,
						'suffix' => 'px',
						'group' => esc_html__( 'Hover', 'deeper' ),
				  	),
				  	// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}
}

new Deeper_ContentBox_Shortcode;