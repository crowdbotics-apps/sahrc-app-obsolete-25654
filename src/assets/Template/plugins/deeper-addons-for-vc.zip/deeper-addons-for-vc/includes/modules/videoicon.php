<?php
/**
 * Video_Icon shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Video_Icon_Shortcode' ) ) {

	class Deeper_Video_Icon_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_videoicon', array( 'Deeper_Video_Icon_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_videoicon', array( 'Deeper_Video_Icon_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(
			    'video_style' => 'style-1',
				'video_url' => '',	
				'video_text' => '',	
				'video_class' => '',

				// Position
				'video_pos' => '',
				'video_pos_left' => '',
				'video_pos_right' => '',
				'video_pos_top' => '',
				'video_pos_bottom' => '',
			), $atts ) );

			$cls = '';

			if ( $video_url ) {
				wp_enqueue_script( 'magnificpopup' );
				$text_html = '';
				$url_css = '';
				$cls .= $video_class;
				if( $video_text ) {
					$url_css .= 'display:flex;align-items:center;';
					$text_html = sprintf( '<span class="video-text">%1$s</span>', $video_text );
				}

				if ( $video_pos ) {
					$url_css .= ' position:absolute;';
					if ( $video_pos_left ) $url_css .= 'left:' . $video_pos_left . ';';
					if ( $video_pos_right ) $url_css .= 'right:' . $video_pos_right . ';';
					if ( $video_pos_top ) $url_css .= 'top:' . $video_pos_video_pos_top . ';';
					if ( $video_pos_bottom ) $url_css .= 'bottom:' . $video_pos_bottom . ';';
				}
				if ( $video_style == 'style-3' ) {
					$cls .= ' hover-draw';
					wp_enqueue_script('anime');

					return sprintf(
						'<div class="url-wrap align-center %5$s" style="%4$s">
							<a class="deeper-video-icon popup-video %2$s" href="%1$s">
							</a>
							%3$s		
						</div>',
						esc_url( vc_build_link( $video_url)['url'] ),
						$video_style,
						$text_html,
						$url_css,
						$cls
					);
				} else {
					return sprintf(
						'<div class="url-wrap align-center %5$s" style="%4$s">
							<a class="deeper-video-icon popup-video %2$s" href="%1$s"></a>
							%3$s		
						</div>',
						esc_url( vc_build_link( $video_url)['url'] ),
						$video_style,
						$text_html,
						$url_css,
						$cls
					);
				}
			}
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Video_Icon', 'deeper' ),
		        'description' => __( 'Video Icon with some styles', 'deeper' ),
		        'base' => 'deeper_videoicon',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/videoicon.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
					array(
						'type' => 'dropdown',
						'heading' => __( 'Style', 'deeper' ),
						'param_name' => 'video_style',
						'value' => array(
							'Style 1' 		=> 'style-1',
							'Style 2' 		=> 'style-2',
							'Style 3' 		=> 'style-3',
							'Style 4' 		=> 'style-4',
							'Style 5' 		=> 'style-5',
							'Style 6' 		=> 'style-6',
							'Style 7' 		=> 'style-7',
						),
						'std'		=> 'style-1'
					),				
					array(
						'type' => 'vc_link',
						'heading' => __( 'URL (Required):', 'deeper' ),
						'param_name' => 'video_url',
						'value' => '',
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Video Text (Optional):', 'deeper' ),
						'param_name' => 'video_text',
						'value' => '',
			        ),
			        array(
						'type' => 'dropdown',
						'heading' => __( 'Icon Position', 'deeper' ),
						'param_name' => 'video_pos',
						'value' => array(
							'Center' 		=> '',
							'Custom (Parent Containt need position-relative)' 		=> 'custom',
						),
						'std'		=> '',
					),	
					array(
						'type' => 'textfield',
						'heading' => __( 'Icon Position: Top', 'deeper' ),
						'param_name' => 'video_pos_top',
						'value' => '',
						'dependency' => array( 'element' => 'video_pos', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Position: Left', 'deeper' ),
						'param_name' => 'video_pos_left',
						'value' => '',
						'dependency' => array( 'element' => 'video_pos', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Position: Bottom', 'deeper' ),
						'param_name' => 'video_pos_bottom',
						'value' => '',
						'dependency' => array( 'element' => 'video_pos', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Icon Position: Right', 'deeper' ),
						'param_name' => 'video_pos_right',
						'value' => '',
						'dependency' => array( 'element' => 'video_pos', 'value' => 'custom' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'video_class',
						'value' => '',
			        ),
		        )
		    );
		}
	}

	new Deeper_Video_Icon_Shortcode;
}
