<?php
/**
 * Tab shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_tab extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Tab_Shortcode' ) ) {

	class Deeper_Tab_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_tab', array( 'Deeper_Tab_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_tab', array( 'Deeper_Tab_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract(shortcode_atts(array(
	            'tab_title' => 'Title',
	        ), $atts));


	        return sprintf( 
	        	'<div class="tab-content">
                	<div class="item-title"><a class="anchor-link"><span class="title">%1$s</span></a></div>
     	    		<div class="item-content">%2$s</div>
     	    	</div>',
     	    	$tab_title,
     	    	do_shortcode( $content )
	        	);  				
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
	        	"name" => esc_html__("Child Tab", 'deeper'),
				'base' => 'tab',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/tabs.png', __FILE__ ),
				'as_child' => array('only' => 'deeper_tabs'),
				'as_parent' => array('except' => 'deeper_tabs', 'deeper_tab'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
				'params' => array_merge(
					array(
						array(
							'type' => 'textfield',
							'holder' => 'div',
							'admin_label' => true,
							'heading' => esc_html__( 'Tab Title', 'deeper' ),
							'param_name' => 'tab_title',
		                    'std'       => 'Title',
						),

				    )
				)
		    );
		}
	}
}

new Deeper_Tab_Shortcode;