<?php
/**
 * Parallax_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_parallaxbox extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Parallax_Box_Shortcode' ) ) {

	class Deeper_Parallax_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_parallaxbox', array( 'Deeper_Parallax_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_parallaxbox', array( 'Deeper_Parallax_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			return sprintf(
				'<div class="deeper-parallax-box"><div class="parallax-wrap">%1$s</div></div>',
				do_shortcode( $content )
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Parallax Box', 'deeper' ),
		        'description' => __( 'Parallax Box.', 'deeper' ),
		        'base' => 'parallaxbox',
				'weight'	=>	180,
		        'icon' => plugins_url( '../../assets/icon/parallaxbox.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'as_parent' => array( 'only' => 'deeper_parallaxitem' ),
				'controls' => 'full',
				'show_settings_on_create' => false,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView'
		    );
		}
	}
}

new Deeper_Parallax_Box_Shortcode;