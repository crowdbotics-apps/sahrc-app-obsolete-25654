<?php
/**
 * Pie_Chart shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Pie_Chart_Shortcode' ) ) {

	class Deeper_Pie_Chart_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_piechart', array( 'Deeper_Pie_Chart_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_piechart', array( 'Deeper_Pie_Chart_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$cls = $css = $data = $piechart_css = '';

			extract( shortcode_atts( array(
				'align' => '',
				'class'	=> '',
				'percent'	=> '',
				'piechart_size' => '',
				'piechart_margin' => '',
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
			), $atts ) );
			$cls = $align . ' ' . $class;
			$content = wpb_js_remove_wpautop( $content, true );

			if ( $piechart_size ) $piechart_css .= 'max-width:' . intval( $piechart_size ) . 'px';
			if ( $piechart_margin ) $piechart_css .= 'margin-bottom:' . intval( $piechart_margin ) . 'px';

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			wp_enqueue_script( 'progressbar' );
			return sprintf(
				'<div class="deeper-piechart %1$s" %2$s>
					<div class="piechart" data-value="%3$s" style="%5$s">
						<div class="inner-circle"></div>
					</div>
					%4$s
				</div>',
				$cls,
				$data,
				$percent,
				$content,
				$piechart_css
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Pie Chart', 'deeper' ),
		        'description' => __( 'Animated Pie Chart.', 'deeper' ),
		        'base' => 'deeper_piechart',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/progressbar.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Alignment', 'deeper' ),
						'param_name' => 'align',
						'value'      => array(
							'Left' => 'align-left',
							'Right' => 'align-right',
							'Center' => 'align-center',
						),
						'std'		=> 'align-left',
					),
		        	array(
						'type' => 'deeper_number',
						'holder' => 'div',
						'heading' => __( 'Percent', 'deeper' ),
						'param_name' => 'percent',
						'value' => '',
						'suffix' => '%',
						'step' => '1',
				  	),
			        array(
						'type' => 'textarea_html',
						'holder' => 'div',
						'heading' => __( 'Content', 'deeper' ),
						'param_name' => 'content',
						'value' => ''
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => ''
			        ),
			        // Spacing
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pie Chart Size', 'deeper' ),
						'param_name' => 'piechart_size',
						'value' => '',
						'group' => __( 'Controls', 'deeper' ),
						'description' => esc_html__( 'Default: 150px.', 'deeper' )
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Pie Chart: Margin Bottom', 'deeper' ),
						'param_name' => 'piechart_margin',
						'value' => '',
						'group' => __( 'Controls', 'deeper' ),
						'description' => esc_html__( 'Example: 100px.', 'deeper' )
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		        )
		    );
		}
	}

	new Deeper_Pie_Chart_Shortcode;
}
