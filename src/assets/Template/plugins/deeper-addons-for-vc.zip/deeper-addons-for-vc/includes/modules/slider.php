<?php
/**
 * Slider shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_slider extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_Slider_Shortcode' ) ) {

	class Deeper_Slider_Shortcode {
		// Constructor
		public function __construct() {

			// Add shortcode
			add_shortcode( 'deeper_slider', array( 'Deeper_Slider_Shortcode', 'output' ) );
			
			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_slider', array( 'Deeper_Slider_Shortcode', 'map' ) );
			}	
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			extract(shortcode_atts(array(
	            'style' => 'style-1',
	            'nav_width' => '',
	            'content_width' => '',
	            'extra' => '',

	            // Controle
	            'autoplay'	=> '',
	            'autoplayspeed'	=> '3000',

	            'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',
	        ), $atts));

	        $css = $cls = $data = $nav_css = $content_css = '';
	        $data_nav = $data_content = '';
	        $nav_config = array();
	        $content_config = array();

	        $cls = $style;
	        if( $extra ) $cls .= ' ' . $extra;

	        // Special style - delete if don't use
	        if ( $style == 'special-style-1' ) {
	        	$nav_css .= 'float:left;';
				$content_css .= 'float:right;';
				if ( $nav_width ) $nav_css .= 'width:' . $nav_width . ';';
				if ( $content_width ) $content_css .= 'width:' . $content_width . ';';

				// Data       
		        $nav_config['centerMode'] = false;
		        $nav_config['infinite'] = false;
		        $nav_config['focusOnSelect'] = true;
		        $nav_config['centerPadding'] = 0;
		        $nav_config['slidesToShow'] = 5;
		        $nav_config['slidesToScroll'] = 5;
		        $nav_config['arrows'] = false;

		        $nav_config['responsive'][0]['breakpoint'] = 1100; 
		        $nav_config['responsive'][0]['settings']['slidesToShow'] = 5; 
		        $nav_config['responsive'][0]['settings']['slidesToScroll'] = 5; 
		        $nav_config['responsive'][0]['settings']['centerMode'] = false;

		        $nav_config['responsive'][1]['breakpoint'] = 920; 
		        $nav_config['responsive'][1]['settings']['slidesToShow'] = 5; 
		        $nav_config['responsive'][1]['settings']['slidesToScroll'] = 5; 
		        $nav_config['responsive'][1]['settings']['centerMode'] = false; 
		        $nav_config['responsive'][1]['settings']['vertical'] = false;         
		        $nav_config['responsive'][1]['settings']['verticalSwiping'] = false;         

		        $nav_config['responsive'][2]['breakpoint'] = 767; 
		        $nav_config['responsive'][2]['settings']['slidesToShow'] = 1; 
		        $nav_config['responsive'][2]['settings']['slidesToScroll'] = 1; 
		        $nav_config['responsive'][2]['settings']['centerMode'] = true; 
		        $nav_config['responsive'][2]['settings']['vertical'] = false;         
		        $nav_config['responsive'][2]['settings']['verticalSwiping'] = false;   

		        $data_nav = 'data-slick=\'' . json_encode( $nav_config ) . '\'';
		        
		        $content_config['arrows'] = false;
		        $content_config['dots'] = false;
		        $content_config['infinite'] = true;
		        $content_config['speed'] = 300;
		        
		        if ( $autoplay ) {
		        	$content_config['autoplay'] = true;
		        	$content_config['autoplaySpeed'] = $autoplayspeed;
		        }

		        $data_content = 'data-slick=\'' . json_encode( $content_config ) . '\'';

		        // Animation
		        if ( $animation ) {
				    $cls .= ' wow '. $animation_effect;
				    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
				}

				wp_enqueue_script( 'slick' );
		     	return sprintf(
		     		'<div class="deeper-slick-slider clearfix %1$s" style="%8$s" %7$s>
			            <div class="slick-container slick-content" style="%6$s">
			            	<div class="slick-slider" data-nav-target="#carousel-quotes-nav" id="carousel-quotes" %4$s>
			            		%2$s
			            	</div>
			            </div> 

			            <div class="slick-container slick-nav" style="%5$s">
			            	<div class="slick-slider-nav" id="carousel-quotes-nav" data-nav-target="#carousel-quotes" %3$s>
							</div>
			            </div>               			
			    	</div>',
			    	$cls,
			    	do_shortcode( $content ),
			    	$data_nav,
			    	$data_content,
			    	$nav_css,
			    	$content_css,
			    	$data,
			    	$css
			    );

	        }

	        // Vertical Slide
	        if ( $style == 'style-1' || $style == 'style-2' ) {
	        	// Nav Right
	        	if ( $style == 'style-1' ) {
					$nav_css .= 'float:right;';
					$content_css .= 'float:left;';
				}

				// Nav Left
				if ( $style == 'style-2' ) {
					$nav_css .= 'float:left;';
					$content_css .= 'float:right;';
				}

				if ( $nav_width ) $nav_css .= 'width:' . $nav_width . ';';
				if ( $content_width ) $content_css .= 'width:' . $content_width . ';';

				$nav_config['vertical'] = true;
	        	$nav_config['verticalSwiping'] = true;
	        }

			// Data       
	        $nav_config['centerMode'] = false;
	        $nav_config['infinite'] = true;
	        $nav_config['focusOnSelect'] = true;
	        $nav_config['centerPadding'] = 0;
	        $nav_config['slidesToShow'] = 3;
	        $nav_config['slidesToScroll'] = 1;
	        $nav_config['arrows'] = false;

	        $nav_config['responsive'][0]['breakpoint'] = 1100; 
	        $nav_config['responsive'][0]['settings']['slidesToShow'] = 2; 
	        $nav_config['responsive'][0]['settings']['slidesToScroll'] = 2; 
	        $nav_config['responsive'][0]['settings']['centerMode'] = false;

	        $nav_config['responsive'][1]['breakpoint'] = 920; 
	        $nav_config['responsive'][1]['settings']['slidesToShow'] = 2; 
	        $nav_config['responsive'][1]['settings']['slidesToScroll'] = 2; 
	        $nav_config['responsive'][1]['settings']['centerMode'] = false; 
	        $nav_config['responsive'][1]['settings']['vertical'] = false;         
	        $nav_config['responsive'][1]['settings']['verticalSwiping'] = false;         

	        $nav_config['responsive'][2]['breakpoint'] = 767; 
	        $nav_config['responsive'][2]['settings']['slidesToShow'] = 1; 
	        $nav_config['responsive'][2]['settings']['slidesToScroll'] = 1; 
	        $nav_config['responsive'][2]['settings']['centerMode'] = true; 
	        $nav_config['responsive'][2]['settings']['vertical'] = false;         
	        $nav_config['responsive'][2]['settings']['verticalSwiping'] = false;   

	        $data_nav = 'data-slick=\'' . json_encode( $nav_config ) . '\'';
	        
	        $content_config['arrows'] = false;
	        $content_config['dots'] = false;
	        $content_config['infinite'] = true;
	        
	        if ( $autoplay ) {
	        	$content_config['autoplay'] = true;
	        	$content_config['autoplaySpeed'] = $autoplayspeed;
	        }

	        $data_content = 'data-slick=\'' . json_encode( $content_config ) . '\'';

	        // Animation
	        if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}
	     	
	     	wp_enqueue_script( 'slick' );
	     	return sprintf(
	     		'<div class="deeper-slick-slider clearfix %1$s" style="%8$s" %7$s>
		            <div class="slick-container slick-content" style="%6$s">
		            	<div class="slick-slider" data-nav-target="#carousel-quotes-nav" id="carousel-quotes" %4$s>
		            		%2$s
		            	</div>
		            </div> 

		            <div class="slick-container slick-nav" style="%5$s">
		            	<div class="slick-slider-nav" id="carousel-quotes-nav" data-nav-target="#carousel-quotes" %3$s>
						</div>
		            </div>               			
		    	</div>',
		    	$cls,
		    	do_shortcode( $content ),
		    	$data_nav,
		    	$data_content,
		    	$nav_css,
		    	$content_css,
		    	$data,
		    	$css
		    );
				
		}	

		// Map shortcode to VC
		public static function map() {
		    return array(
	        	"name" => esc_html__("Advanced Slider", 'deeper'),
				'base' => 'slider',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/tabs.png', __FILE__ ),
				'as_parent' => array('only' => 'deeper_slidercontent'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
				'params' => array(
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Style', 'deeper' ),
						'param_name' => 'style',
						'value'      => array(
							'Nav Vertical Right' => 'style-1',
							'Nav Vertical Left' => 'style-2',
						),
						'std'		=> 'style-1',
					),
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Navigation Width', 'deeper' ),
						'param_name' => 'nav_width',
						'value'      => '',
						'dependency' => array( 'element' => 'style', 'value' => array( 'style-1', 'style-2' ) )
					),
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Content Width', 'deeper' ),
						'param_name' => 'content_width',
						'value'      => '',
						'dependency' => array( 'element' => 'style', 'value' => array( 'style-1', 'style-2' ) )
					),
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Extra Class', 'deeper' ),
						'param_name' => 'extra',
						'value'      => '',
					),
					// Controls
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Autoplay?', 'deeper' ),
						'param_name' => 'autoplay',
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
						'group' => __( 'Controls', 'deeper' ),
					),
					array(
						'type'       => 'textfield',
						'text'    => __( 'Auto Play Speed (miliseconds)', 'deeper' ),
						'param_name' => 'autoplayspeed',
						'value'      => '3000',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'autoplay', 'not_empty' => true ),
						'description' => esc_html__( 'Example: 3000.', 'deeper' )
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				),
		    );
		}
	}
	new Deeper_Slider_Shortcode;
}

