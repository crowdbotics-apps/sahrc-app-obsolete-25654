<?php
/**
 * Product Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Product_Box_Shortcode' ) ) {

	class Deeper_Product_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_product', array( 'Deeper_Product_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_product', array( 'Deeper_Product_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
				'product_id' => '',
				'product_image' => '',
			), $atts ) );
			$sale = $product_sc = $product_sc = '';

			$product = new WC_Product( $product_id );

			$product_sc = '[product id="' . $product_id . '"]';

			if ( $product->is_on_sale() ) {
				// Get product prices
		        $regular_price = (float) $product->get_regular_price(); // Regular price
		        $sale_price = (float) $product->get_price(); // Active price (the "Sale price" when on-sale)

		        // "Saving Percentage" calculation and formatting
		        $precision = 1; // Max number of decimals
		        $saving_percentage = round( 100 - ( $sale_price / $regular_price * 100 ), 0 ) . '%';
				$sale .= '<span class="onsale">-' . $saving_percentage . '</span>';
			}
			$image_html = sprintf( 
				'<div class="product-image">
					<a href="%2$s"><img src="%1$s" alt="Product"></a>
					%3$s
					<div class="btn-wrap">
						<a href="%4$s" class="image-popup"></a>
						<a href="%2$s" class="link"></a>
					</div>
				</div>',
				esc_url( wp_get_attachment_image_src( $product_image, 'full' )[0] ),
				esc_url( get_permalink( $product_id ) ),
				$sale,
				esc_url( wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'full' )[0] )
			);

			return sprintf(
				'<div class="deeper-product-box clearfix">
					<div class="product-image">
						%1$s
					</div>
					%2$s
				</div>',
				$image_html,
				do_shortcode( $product_sc )
			);
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Product Box', 'deeper' ),
		        'description' => __( 'Displays a product box with custom image.', 'deeper' ),
		        'base' => 'deeper_product',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/products.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
		        	array(
						'type' => 'textfield',
						'heading' => esc_html__('Product ID', 'deeper'),
						'param_name' => 'product_id',
						'value' => '',
					),
			        array(
						'type' => 'attach_image',
						'heading' => esc_html__('Product Image', 'deeper'),
						'param_name' => 'product_image',
						'value' => '',
					),
		        )
		    );
		}
	}

	new Deeper_Product_Box_Shortcode;
}
