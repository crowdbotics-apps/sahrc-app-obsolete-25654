<?php
/**
 * CarouselBox shortcode for Visual Composer
 *
 * @package Deeper Addons
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	class WPBakeryShortCode_deeper_carouselbox extends WPBakeryShortCodesContainer {}
}

if ( ! class_exists( 'Deeper_CarouselBox_Shortcode' ) ) {

	class Deeper_CarouselBox_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_carouselbox', array( 'Deeper_CarouselBox_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_carouselbox', array( 'Deeper_CarouselBox_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {
			$data = '';
			$config = array();

			extract( shortcode_atts( array(
				'gap'			=> '0',
				'autoplay' => 'false',
				'center' => 'left',
				'full_screen' => '',
				'autoplay_speed' => 3000,
			    'fullaside' => 'false',
			    'loop' => '',
			    'groupcell' => 'false',
				
				'column' => '3',
				'column2' => '2',
				'column3' => '2',
				'column4' => '1',
				
				'class'	=> '',
				// Arrows
				'show_arrows' => '',
				'arrowsvg' => 'svg1',
				'arrows_position' => 'middle',
				'arrows_offset' => 'arrow-offset-0',
				// Bullets
				'show_bullets' => '',
				'bullets_offset' => 'bullet-offset-0',
				'bullets_pos' => 'bullet-center',
				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',

			), $atts ) );

			wp_enqueue_script( 'flickity' );

			$cls = ' column-' . $column . ' column2-' . $column2 . ' column3-' . $column3 . ' column4-' . $column4 .  ' gap-' . $gap . ' arrow-' . $arrowsvg;
			if ( $class ) $cls .= ' ' . $class;
			if ( $full_screen ) $cls .= ' ' . $full_screen;

			$config['cellAlign'] = $center;
			$config['autoPlay'] = $autoplay == 'true' ? abs( (int) $autoplay_speed ) : false;
			$config['fullAside'] = $fullaside == 'true' ? true : false;
			$config['wrapAround'] = $loop == 'true' ? true : false;
			$config['groupCells'] = $groupcell == 'true' ? true : false;
			
			// Arrows
			if ( $show_arrows ) {
				$cls .= ' has-arrows arrow-' . $arrows_position . ' ' . $arrows_offset;
				$config['prevNextButtons'] = true;
				if ( $arrowsvg !== 'style-4') {
					$config['arrowShapeStyle'] = $arrowsvg;
				}
			}

			// Bullets
			if ( $show_bullets ) {
				$cls .= ' has-bullets ' . $bullets_offset . ' ' . $bullets_pos;
				$config['pageDots'] = true;
			}

			if ( $config )
				$data = 'data-config=\'' . json_encode( $config ) . '\'';

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			ob_start(); ?>

			<div class="deeper-carousel-box <?php echo $cls; ?>" <?php echo $data; ?>>
				<?php echo do_shortcode( $content ); ?>
			</div><!-- /.deeper-carousel-box -->

			<?php
			return ob_get_clean();
		}

		// Map shortcode to VC
		public static function map() {
			return array(
				'name' => esc_html__('Carousel Box', 'deeper'),
				'base' => 'carouselbox',
				'weight'	=>	180,
				'icon' => plugins_url( '../../assets/icon/carouselbox.png', __FILE__ ),
				'as_parent' => array('except' => 'deeper_carouselbox'),
				'controls' => 'full',
				'show_settings_on_create' => true,
				'category' => esc_html__('Deeper Addons', 'deeper'),
				'js_view' => 'VcColumnView',
			    'params' => array(
			    	array(
						'type'       => 'dropdown',
						'heading'    => __( 'Spacing between Items', 'deeper' ),
						'param_name' => 'gap',
						'value'      => array(
							'0px' => '0',
							'1px' => '1',
							'5px' => '5',
							'10px' => '10',
							'15px' => '15',
							'20px' => '20',
							'30px' => '30',
							'40px' => '40',
							'50px' => '50',
							'60px' => '60',
							'70px' => '70',
							'80px' => '80',
							'90px' => '90',
							'100px' => '100',
						),
						'std'		=> '0',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Auto Play?', 'deeper' ),
						'param_name' => 'autoplay',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
					),
		            array(
						'type' => 'textfield',
						'heading' => __( 'Auto Play Speed', 'deeper' ),
						'param_name' => 'autoplay_speed',
						'value' => '3000',
						'dependency' => array( 'element' => 'autoplay', 'value' => 'true' ),
		            ),      
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Full Aside?', 'deeper' ),
						'param_name' => 'fullaside',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Center Mode?', 'deeper' ),
						'param_name' => 'center',
						'value'      => array(
							'No' => 'left',
							'Yes' => 'center',
						),
						'std'		=> 'left',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Full Screen?', 'deeper' ),
						'param_name' => 'full_screen',
						'value'      => array(
							'Default' => '',
							'On Desktop ( > 1024px )' => 'full-screen',
							'On Tablet ( < 1024px )' => 'full-screen-xl',
							'On Mobile ( < 991px )' => 'full-screen-lg',
							'On Small Mobile ( < 776px )' => 'full-screen-md',
						),
						'std'		=> '',
						'dependency' => array( 'element' => 'center', 'value' => 'center' ),
						'description'	=> __( 'Used with center mode to show full screen when center mode and number of item is even.', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Infinity Loop?', 'deeper' ),
						'param_name' => 'loop',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
						'description'	=> __( 'Duplicate last and first items to get loop illusion.', 'deeper' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Group Cell?', 'deeper' ),
						'param_name' => 'groupcell',
						'value'      => array(
							'No' => 'false',
							'Yes' => 'true',
						),
						'std'		=> 'false',
						'description'	=> __( 'Groups cells together in slides. Flicking, page dots, and previous/next buttons are mapped to group slides, not individual cells.', 'deeper' ),
					),
					array(
						'type' => 'textfield',
						'heading' => __( 'Extra Class', 'deeper' ),
						'param_name' => 'class',
						'value' => '',
		            ),
		            // Controls
		            array(
						'type' => 'deeper_heading',
						'text' => __( 'Arrows', 'deeper' ),
						'param_name' => 'deeper_heading_arrow',
						'group' => __( 'Controls', 'deeper' ),
		            ),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Arrows?', 'deeper' ),
						'param_name' => 'show_arrows',
						'group' => __( 'Controls', 'deeper' ),
						'value'      => array(
							'No' => '',
							'Yes' => 'yes',
						),
						'std'		=> '',
					),
		            array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrow Style?', 'deeper' ),
						'param_name' => 'arrowsvg',
						'value'      => array(
							'Style 1' => 'svg1',
							'Style 2' => 'svg2',
							'Style 3' => 'svg3',
							'Style 4' => 'style-4',
						),
						'std'		=> 'svg1',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Position', 'deeper' ),
						'param_name' => 'arrows_position',
						'value'      => array(
							'Middle' => 'middle',
							'Top' => 'top',
						),
						'std'		=> 'middle',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_arrows', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Arrows Offset', 'deeper' ),
						'param_name' => 'arrows_offset',
						'value'      => array(
							'0px' 	=> 'arrow-offset-0',
							'10px' 	=> 'arrow-offset-10',
							'20px' 	=> 'arrow-offset-20',
							'30px' 	=> 'arrow-offset-30',
							'40px' 	=> 'arrow-offset-40',
							'50px' 	=> 'arrow-offset-50',
							'60px' 	=> 'arrow-offset-60',
							'70px' 	=> 'arrow-offset-70',
							'80px' 	=> 'arrow-offset-80',
							'90px' 	=> 'arrow-offset-90',
							'100px' 	=> 'arrow-offset-100',
							'-10px' 	=> 'arrow-offset-x10',
							'-20px' 	=> 'arrow-offset-x20',
							'-30px' 	=> 'arrow-offset-x30',
							'-40px' 	=> 'arrow-offset-x40',
							'-50px' 	=> 'arrow-offset-x50',
							'-60px' 	=> 'arrow-offset-x60',
							'-70px' 	=> 'arrow-offset-x70',
							'-80px' 	=> 'arrow-offset-x80',
							'-90px' 	=> 'arrow-offset-x90',
							'-100px' 	=> 'arrow-offset-x100',
						),
						'std'		=> 'arrow-offset-0',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'arrows_position', 'value' => 'top' )
					),
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Bullets', 'deeper' ),
						'param_name' => 'deeper_heading_bullets',
						'group' => __( 'Controls', 'deeper' ),
		            ),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Show Bullets?', 'deeper' ),
						'param_name' => 'show_bullets',
						'group' => __( 'Controls', 'deeper' ),
						'value'      => array(
							'No' => '',
							'Yes' => 'yes',
						),
						'std'		=> '',
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Bullets Position', 'deeper' ),
						'param_name' => 'bullets_pos',
						'value'      => array(
							'Left' 		=> 'bullet-left',
							'Center' 	=> 'bullet-center',
							'Right' 	=> 'bullet-right',
						),
						'std'		=> 'bullet-center',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_bullets', 'value' => 'yes' )
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Bullets Offset', 'deeper' ),
						'param_name' => 'bullets_offset',
						'value'      => array(
							'0px' 	=> 'bullet-offset-0',
							'10px' 	=> 'bullet-offset-10',
							'20px' 	=> 'bullet-offset-20',
							'30px' 	=> 'bullet-offset-30',
							'40px' 	=> 'bullet-offset-40',
							'50px' 	=> 'bullet-offset-50',
							'60px' 	=> 'bullet-offset-60',
							'70px' 	=> 'bullet-offset-70',
							'80px' 	=> 'bullet-offset-80',
							'90px' 	=> 'bullet-offset-90',
							'100px' 	=> 'bullet-offset-100',
						),
						'std'		=> 'bullet-offset-0',
						'group' => __( 'Controls', 'deeper' ),
						'dependency' => array( 'element' => 'show_bullets', 'value' => 'yes' )
					),
					// Column
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Desktop ( > 1024px )', 'deeper' ),
						'param_name' => 'column',
						'value'      => array(
							'5 Columns' => '5',
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '3',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Tablet ( From 991px to 1024px )', 'deeper' ),
						'param_name' => 'column2',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '2',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Mobile ( From 767px to 991px )', 'deeper' ),
						'param_name' => 'column3',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '2',
						'group' => __( 'Columns', 'deeper' ),
					),
					array (
						'type'       => 'dropdown',
						'heading'    => __( 'Column: Small Mobile ( < 767px )', 'deeper' ),
						'param_name' => 'column4',
						'value'      => array(
							'4 Columns' => '4',
							'3 Columns' => '3',
							'2 Columns' => '2',
							'1 Columns' => '1',
						),
						'std'		=> '1',
						'group' => __( 'Columns', 'deeper' ),
					),
					// Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
			    )
			);
		}
	}

	new Deeper_CarouselBox_Shortcode;
}



