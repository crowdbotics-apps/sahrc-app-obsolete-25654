<?php
/**
 * Team_Box shortcode for Visual Composer
 *
 * @package Deeper Addons
 */

if ( ! class_exists( 'Deeper_Team_Box_Shortcode' ) ) {

	class Deeper_Team_Box_Shortcode {

		// Constructor
		public function __construct() {
			
			// Add shortcode
			add_shortcode( 'deeper_teambox', array( 'Deeper_Team_Box_Shortcode', 'output' ) );

			// Map to VC
			if ( function_exists( 'vc_lean_map' ) ) {
				vc_lean_map( 'deeper_teambox', array( 'Deeper_Team_Box_Shortcode', 'map' ) );
			}
		}

		// Displays shortcodes 
		public static function output( $atts, $content ) {

			extract( shortcode_atts( array(
				'class' => '',
			    'team_avatar' => '',
			    'team_url' => '',
			    'team_name' => '',
			    'team_name_color' => '',
			    'team_pos' => '',
			    'team_pos_color' => '',

			    // Typography
				'team_name_font_family' 	=> '',
				'team_name_font_weight' 	=> '',
				'team_name_font_size' 		=> '',
				'team_name_line_height' 	=> '',
				'team_name_letter_spacing' 	=> '',
				'team_pos_font_family' 	=> '',
				'team_pos_font_weight' 	=> '',
				'team_pos_font_size' 		=> '',
				'team_pos_line_height' 	=> '',
				'team_pos_letter_spacing' 	=> '',

				// Socials
				'facebook' => '',
				'twitter' => '',
				'linkedin' => '',
				'instagram' => '',

				// Animation
				'animation' => '',
				'animation_effect' => 'fadeInUp',
				'animation_duration' => '0.75s',
				'animation_delay' => '0.3s',

				// Design 
				'rounded' => '',
				'shadow' => '',
			), $atts ) );
			$css = $cls = $data = '';
			$accent = deeper_get_accent_color();
			$cls = $class;
			$team_html = $social_html = '';

			if ( $rounded ) $css .= 'overflow:hidden;border-radius:' . $rounded . ';';
			if ( $shadow ) $css .= 'box-shadow:' . $shadow . ';';

			// Name
			if ( $team_name ) {
				$team_name_css = $team_name_cls = '';
				if ( $team_name_color == $accent ) {
					$team_name_cls .= ' accent-color';
				} elseif ( $team_name_color ) {
					$team_name_css .=  'color:' . $team_name_color . ';';
				}
				if ( $team_name_font_weight ) $team_name_css .= 'font-weight:' . $team_name_font_weight . ';';
				if ( $team_name_font_size ) $team_name_css .= 'font-size:' . intval( $team_name_font_size ) . 'px;';
				if ( $team_name_line_height ) $team_name_css .= 'line-height:' . intval( $team_name_line_height ) . 'px;';
				if ( $team_name_letter_spacing ) $team_name_css .= 'letter-spacing:' . $team_name_letter_spacing . 'px;';
				if ( $team_name_font_family ) {
					deeper_enqueue_google_font( $team_name_font_family );
					$team_name_css .= 'font-family:' . $team_name_font_family . ';';
				}
				// if ( $team_name_margin ) $team_name_css .= 'margin-bottom:' . intval( $team_name_margin ) . 'px;';

				$team_html .= sprintf( '<h3 class="team-name %3$s" style="%4$s"><a href="%2$s">%1$s</a></h3>',
					esc_attr( $team_name ),
					esc_url(  vc_build_link( $team_url )['url'] ),
					esc_attr( $team_name_cls ),
					esc_attr( $team_name_css )
				);
			}

			// Position
			if ( $team_pos ) {
				$team_pos_css = $team_pos_cls = '';
				if ( $team_pos_color == $accent ) {
					$team_pos_cls .= ' accent-color';
				} elseif ( $team_pos_color ) {
					$team_pos_css .=  'color:' . $team_pos_color . ';';
				}
				if ( $team_pos_font_weight ) $team_pos_css .= 'font-weight:' . $team_pos_font_weight . ';';
				if ( $team_pos_font_size ) $team_pos_css .= 'font-size:' . intval( $team_pos_font_size ) . 'px;';
				if ( $team_pos_line_height ) $team_pos_css .= 'line-height:' . intval( $team_pos_line_height ) . 'px;';
				if ( $team_pos_letter_spacing ) $team_pos_css .= 'letter-spacing:' . $team_pos_letter_spacing . 'px;';
				if ( $team_pos_font_family ) {
					deeper_enqueue_google_font( $team_pos_font_family );
					$team_pos_css .= 'font-family:' . $team_pos_font_family . ';';
				}
				// if ( $team_pos_margin ) $team_pos_css .= 'margin-bottom:' . intval( $team_pos_margin ) . 'px;';

				$team_html .= sprintf( '<span class="team-pos %2$s" style="%3$s">%1$s</span>',
					esc_attr( $team_pos ),
					esc_attr( $team_pos_cls ),
					esc_attr( $team_pos_css )
				);
			}

			// Socials
			if ( $facebook || $twitter || $linkedin || $instagram ) {
				if ( $facebook ) $social_html .= sprintf( '<a href="'.  esc_url( $facebook ) .'" class="fa fa-facebook"></a>', esc_url( $facebook ) );
				if ( $twitter ) $social_html .= sprintf( '<a href="'.  esc_url( $twitter ) .'" class="fa fa-twitter"></a>', esc_url( $twitter ) );
				if ( $linkedin ) $social_html .= sprintf( '<a href="'.  esc_url( $linkedin ) .'" class="fa fa-linkedin"></a>', esc_url( $linkedin ) );
				if ( $instagram ) $social_html .= sprintf( '<a href="'.  esc_url( $instagram ) .'" class="fa fa-instagram"></a>', esc_url( $instagram ) );
			}

			//Animation
			if ( $animation ) {
			    $cls .= ' wow '. $animation_effect;
			    $data .= ' data-wow-duration="'. $animation_duration .'" data-wow-delay="'. $animation_delay .'"';
			}

			return sprintf(
				'<div class="deeper-team-box %4$s" style="%5$s" %6$s>
					<div class="avatar">
						<img alt="Avatar" src="%1$s">

						<div class="team-socials">
							%3$s
						</div>
					</div>

					<div class="info-wrap">
						%2$s
					</div>
				</div>',
				esc_url( wp_get_attachment_image_src( $team_avatar, 'full' )[0] ),
				$team_html,
				$social_html,
				$cls,
				$css,
				$data
			);			
		}

		// Map shortcode to VC
		public static function map() {
		    return array(
		        'name' => __( 'Team Box', 'deeper' ),
		        'description' => __( 'Display a Custom Team Box.', 'deeper' ),
		        'base' => 'deeper_teambox',
				'weight' =>	180,
		        'icon' => plugins_url( '../../assets/icon/team.png', __FILE__ ),
		        'category' => __( 'Deeper Addons', 'deeper' ),
		        'params' => array(
			        array(
						'type' => 'attach_image',
						'heading' => esc_html__('Avatar', 'deeper'),
						'param_name' => 'team_avatar',
						'value' => '',
					),
			        array(
						'type' => 'vc_link',
						'heading' => __( 'Link to bio page', 'deeper' ),
						'param_name' => 'team_url',
						'value' => ''
			        ),
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Team Information', 'deeper' ),
						'param_name' => 'team_info',
					),
			        array(
						'type' => 'textfield',
						'holder' => 'div',
						'heading' => __( 'Name', 'deeper' ),
						'param_name' => 'team_name',
						'value' => ''
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Name: Color', 'deeper' ),
						'param_name' => 'team_name_color',
						'value' => ''
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Position', 'deeper' ),
						'param_name' => 'team_pos',
						'value' => ''
			        ),
			        array(
						'type' => 'colorpicker',
						'heading' => __( 'Position: Color', 'deeper' ),
						'param_name' => 'team_pos_color',
						'value' => ''
			        ),
			        // Typography
			        array(
						'type' => 'deeper_heading',
						'text' => __( 'Name', 'deeper' ),
						'param_name' => 'team_name_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_name', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Name: Font Family', 'deeper' ),
						'param_name' => 'team_name_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_name', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Name: Font Weight', 'deeper' ),
						'param_name' => 'team_name_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_name', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Name: Font Size', 'deeper' ),
						'param_name' => 'team_name_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_name', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Name: Line Height', 'deeper' ),
						'param_name' => 'team_name_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_name', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Name: Letter Spacing', 'deeper' ),
						'param_name' => 'team_name_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_name', 'not_empty' => true ),
				  	),
				  	array(
						'type' => 'deeper_heading',
						'text' => __( 'Name', 'deeper' ),
						'param_name' => 'team_pos_typograpy',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_pos', 'not_empty' => true ),
					),
					array(
						'type'       => 'deeper_font_family',
						'heading'    => __( 'Position: Font Family', 'deeper' ),
						'param_name' => 'team_pos_font_family',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_pos', 'not_empty' => true ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => __( 'Position: Font Weight', 'deeper' ),
						'param_name' => 'team_pos_font_weight',
						'value'      => array(
							'Default' => '',
							'300' => '300',
							'400' => '400',
							'500' => '500',
							'600' => '600',
							'700' => '700',
							'800' => '800',
							'900' => '900',
						),
						'std'		=> 'Default',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_pos', 'not_empty' => true ),
					),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Position: Font Size', 'deeper' ),
						'param_name' => 'team_pos_font_size',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_pos', 'not_empty' => true ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Position: Line Height', 'deeper' ),
						'param_name' => 'team_pos_line_height',
						'value' => '',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_pos', 'not_empty' => true ),
			        ),
					array(
						'type' => 'deeper_number',
						'heading' => __( 'Position: Letter Spacing', 'deeper' ),
						'param_name' => 'team_pos_letter_spacing',
						'value' => '',
						'suffix' => 'px',
						'step' => '0.1',
						'group' => __( 'Typography', 'deeper' ),
						'dependency' => array( 'element' => 'team_pos', 'not_empty' => true ),
				  	),
					// Socials
					array(
						'type' => 'deeper_heading',
						'text' => __( 'Socials Url', 'deeper' ),
						'param_name' => 'social_url',
						'group' => __( 'Socials', 'deeper' ),
					),
				  	array(
						'type' => 'textfield',
						'heading' => __( 'Facebook', 'deeper' ),
						'param_name' => 'facebook',
						'value' => '',
						'group' => __( 'Socials', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Twitter', 'deeper' ),
						'param_name' => 'twitter',
						'value' => '',
						'group' => __( 'Socials', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Linkedin', 'deeper' ),
						'param_name' => 'linkedin',
						'value' => '',
						'group' => __( 'Socials', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Instagram', 'deeper' ),
						'param_name' => 'instagram',
						'value' => '',
						'group' => __( 'Socials', 'deeper' ),
			        ),
			        // Design
			        array(
						'type' => 'textfield',
						'heading' => __( 'Rounded', 'deeper' ),
						'param_name' => 'rounded',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
			        ),
			        array(
						'type' => 'textfield',
						'heading' => __( 'Box Shadow', 'deeper' ),
						'param_name' => 'shadow',
						'value' => '',
						'group' => __( 'Design', 'deeper' ),
			        ),
			        // Animation 
					array(
						'type'       => 'checkbox',
						'heading'    => esc_html__( 'Enable Animation?', 'deeper' ),
						'param_name' => 'animation',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'value'      => array( esc_html__( 'Yes, please.', 'deeper' ) => 'yes' ),
					),
					array(
						'type'       => 'dropdown',
						'heading'    => esc_html__( 'Animation', 'deeper' ),
						'param_name' => 'animation_effect',
						'value'      => array(
							'Fade In Up' => 'fadeInUp',
							'Fade In Down' => 'fadeInDown',
							'Fade In' => 'fadeIn',
							'Fade In Left' => 'fadeInLeft',
							'Fade In Right' => 'fadeInRight',
						),
						'std'		=> 'fadeInUp',
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
					),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Duration', 'deeper'),
						'param_name' => 'animation_duration',
						'value' => '0.75s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
		            array(
						'type' => 'textfield',
						'heading' => esc_html__('Animation Delay', 'deeper'),
						'param_name' => 'animation_delay',
						'value' => '0.3s',
						'description'	=> esc_html__('Ex: 0.1s, 0.15s', 'deeper'),
						'group' => esc_html__( 'Animation', 'deeper' ),
						'dependency' => array( 'element' => 'animation', 'value' => 'yes' ),
		            ),
				  	array(
						'type' => 'colorpicker',
						'heading' => __( 'Extra Classes', 'deeper' ),
						'param_name' => 'class',
						'value' => ''
			        ),
		        )
		    );
		}
	}

	new Deeper_Team_Box_Shortcode;
}
