<?php

if ( ! class_exists( 'Deeper_VC_Addons' ) ) {
	/**
	 * Class Deeper_VC_Addons
	 */
	class Deeper_VC_Addons {

		// Constructor
		public function __construct() {
			add_action( 'after_setup_theme', array( 'Deeper_VC_Addons', 'deeper_init' ) );
			add_action( 'wp_enqueue_scripts', array( 'Deeper_VC_Addons', 'deeper_front_scripts' ), 99 );

			// Required files
			require_once __DIR__ . '/fonts.php';
			require_once __DIR__ . '/icons.php';
			require_once __DIR__ . '/svgs.php';
			require_once __DIR__ . '/hooks.php';
			require_once __DIR__ . '/function.php';
			require_once __DIR__ . '/widgets/init.php';
			require_once __DIR__ . '/google-api.php';

			// Register Custom Post Type
			require_once DEEPER_PATH . 'includes/cpt.php';
		}

		// Methods that run on init
		public static function deeper_init() {

			// Include custom 
			if ( function_exists( 'vc_lean_map' ) && class_exists( 'WPBakeryShortCode' ) ) {
				self::deeper_modules_map();
			}

			// Create new parameter types
			if ( function_exists( 'vc_add_shortcode_param' ) ) {
				self::deeper_new_param_types();
			}

			// Add new parameter to vc element 
			if ( function_exists( 'vc_add_param' ) ) {
				self::deeper_new_params_for_vc_element();
			}
		}

		// Enqueue styles and scripts for frond-end
		public static function deeper_front_scripts() {
			wp_enqueue_style( 'flickity', DEEPER_URL . 'assets/css/flickity.css', '2.2.1' );
			wp_enqueue_style( 'magnificpopup', DEEPER_URL . 'assets/css/magnific.popup.css', '1.0.0' );
			wp_enqueue_style( 'animatedHeading', DEEPER_URL . 'assets/css/animatedheadline.css', '1.0.0' );
			wp_enqueue_style( 'cubeportfolio', DEEPER_URL . 'assets/css/cubeportfolio.css', '1.0.0' );
			
			wp_register_script( 'magnificpopup', DEEPER_URL . 'assets/js/magnific.popup.js', array('jquery'), '1.0.0', true );
			wp_register_script( 'flickity', DEEPER_URL . 'assets/js/flickity.js', array('jquery'), '2.2.1', true );
			wp_register_script( 'slick', DEEPER_URL . 'assets/js/slick.min.js', '4.0.7', true );
			wp_register_script( 'countto', DEEPER_URL . 'assets/js/countto.js', array('jquery'), '1.0.0', true );
			wp_register_script( 'progressbar', DEEPER_URL . 'assets/js/progressbar.min.js', array('jquery'), '0.9.0', true );
			wp_register_script( 'animatedHeading', DEEPER_URL . 'assets/js/animatedheadline.js', array('jquery'), '1.0.0', true );
			wp_register_script( 'typed', DEEPER_URL . 'assets/js/typed.js', array('jquery'), '1.0.0', true );
			wp_register_script( 'cubeportfolio', DEEPER_URL . 'assets/js/cubeportfolio.min.js', array('jquery'), '4.0.0', true );
			wp_register_script( 'anime', DEEPER_URL . 'assets/js/anime.min.js', array('jquery'), '3.1.0', true );

			wp_enqueue_script( 'matchMedia', DEEPER_URL . 'assets/js/matchMedia.js', array('jquery'), '1.0.0', true );
			wp_enqueue_script( 'waitForImages', DEEPER_URL . 'assets/js/waitforimages.js', array('jquery'), '1.0.0', true );
			wp_enqueue_script( 'appear', DEEPER_URL . 'assets/js/appear.js', array('jquery'), '1.0.0', true );
			wp_enqueue_script( 'parallax-scroll', DEEPER_URL . 'assets/js/parallax-scroll.js', array('jquery'), '1.0.0', true );
			wp_enqueue_script( 'wow', DEEPER_URL . 'assets/js/wow.min.js', array('jquery'), '1.0.3', true );
			wp_register_script( 'ripples', DEEPER_URL . 'assets/js/ripples.js', array('jquery'), '1.0.0', true );
			wp_register_script( 'particles', DEEPER_URL . 'assets/js/particles.js', array('jquery'), '2.0.0', true );
			wp_enqueue_script( 'google-maps-api', 'https://maps.googleapis.com/maps/api/js', array(), 'v3' );
			wp_enqueue_script( 'deeper-modules-js', DEEPER_URL . 'assets/js/deeperlayer.js', array('jquery'), '1.0.0', true );
			wp_enqueue_script( 'deeper-custom-js', DEEPER_URL . 'assets/js/custom.js', array('jquery'), '1.0.0', true );
		}

		// Maps custom shortcodes for the VC
		public static function deeper_modules_map() {
			// Array of new modules to add to VC
			$deeper_modules = array(
				'accordions',
				'button',
				'demobox',
				'carouselbox',
				'contactform',
				'contentbox',
				'counter',
				'divider',
				'gmap',
				'gridbox',
				'icon',
				'iconbox',
				'fancyimage',
				'link',
				'list',
				'eventbox',
				'eventgrid',
				'newsgrid',
				'parallaxbox',
				'parallaxitem',
				'partnercarousel',
				'piechart',
				'progressbar',
				'portfolioajax',
				'portfoliocarousel',
				'pricebox',
				'spacer',
				'slider',
				'slidercontent',
				'slidernav',
				'subscribe',
				'tab',
				'tabs',
				'teambox',
				'teamgrid',
				'testimonialbox',
				'text',
				'fancytext',
				'videoicon',
			);

			// Mapping files
			foreach ( $deeper_modules as $key => $val ) {
				$file = __DIR__ . '/modules/' . $val . '.php';
				require_once $file;
			}
		}

		// Add new attribute type for content element attributes
		public static function deeper_new_param_types() {
			
			// Heading param
			vc_add_shortcode_param( 'deeper_heading', 'deeper_heading' );
			function deeper_heading( $settings, $value ) {
				$dependency = '';
				$param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
				$class = isset( $settings['class'] ) ? $settings['class'] : '';
				$text = isset( $settings['text'] ) ? $settings['text'] : '';
				$output = '<h4 ' . $dependency . ' class="wpb_vc_param_value ' . $class . '" style="margin:10px -18px 0;padding:15px 18px;font-size:14px;background:#ebebeb;color:#5e5e5e;">' . $text . '</h4>';
				$output .= '<input type="hidden" name="' . $settings['param_name'] . '" class="wpb_vc_param_value '. $settings['param_name'] . ' ' . $settings['type'] . '_field" value="' . $value . '" ' . $dependency .'/>';
				return $output;
			}

			// Number param
			vc_add_shortcode_param( 'deeper_number', 'deeper_number' );
			function deeper_number( $settings, $value ) {
				$dependency = '';
				$param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
				$type = isset( $settings['type'] ) ? $settings['type'] : '';
				$suffix = isset( $settings['suffix'] ) ? $settings['suffix'] : '';
				$class = isset( $settings['class'] ) ? $settings['class'] : '';
				$step = isset( $settings['step'] ) ? $settings['step'] : '';
				$output = '<input type="number" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class .'" name="' . $param_name . '" value="' . $value . '" step="' . $step . '" style="max-width:100px;margin-right: 10px;" />' . $suffix;
				return $output;
			}

			// Font-Family param
			vc_add_shortcode_param( 'deeper_font_family', 'deeper_font_family' );
			function deeper_font_family( $settings, $value ) {
				$output = '<select name="'. $settings['param_name'] . '" class="wpb_vc_param_value wpb-input wpb-select '
						. $settings['param_name'] . ' ' . $settings['type'] . '">'
						. '<option value="" ' . selected( $value, '', false ) . '>' . esc_html__( 'Default', 'dpr' ) . '</option>';

				if ( $std_fonts = deeper_standard_fonts() ) {
					$output .= '<optgroup label="' . esc_html__( 'Standard Fonts', 'dpr' ) . '">';
						foreach ( $std_fonts as $font ) {
							$output .= '<option value="' . esc_html( $font ) . '" ' . selected( $font, $value, false ) . '>' . esc_html( $font ) . '</option>';
						}
					$output .= '</optgroup>';
				}

				if ( $google_fonts = deeper_google_fonts_array() ) {
					$output .= '<optgroup label="' . esc_html__( 'Google Fonts', 'dpr' ) . '">';
						foreach ( $google_fonts as $font ) {
							$output .= '<option value="' . esc_html( $font ) . '" ' . selected( $font, $value, false ) . '>' . esc_html( $font ) . '</option>';
						}
					$output .= '</optgroup>';
				}
				$output .= '</select>';
				return $output;
			}
		}

		// Add new parameter to existing content element
		public static function deeper_new_params_for_vc_element() {
			
			// Params for column inner
		    vc_add_param(
		        'vc_column_inner',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Half Background?', 'deeper' ),
		            'param_name' => 'halfbg',
		            'value' => array(
		                esc_html__( 'Disable', 'deeper' ) => '',
		                esc_html__( 'Enable', 'deeper' ) => 'enable',
		            ),
		            'description' => esc_html__( 'Put a background left or right side of row', 'deeper' ),
		        )
		    );

		    vc_add_param(
		        'vc_column_inner',
		        array(
		            'type' => 'colorpicker',
		            'heading' => esc_html__( 'Background Color', 'deeper' ),
		            'param_name' => 'halfbg_color',
		            'value' => '',
		            'dependency' => array(
		                'element' => 'halfbg',
		                'value' => array( 'enable' ),
		            ),
		        )
		    );

		    vc_add_param(
		        'vc_column_inner',
		        array(
		            'type' => 'textfield',
		            'heading' => esc_html__( 'Background Rounded', 'deeper' ),
		            'param_name' => 'halfbg_rounded',
		            'dependency' => array(
		                'element' => 'halfbg',
		                'value' => array( 'enable', 'image' ),
		            ),
		            'description' => esc_html__( 'Top Right Bottom Left.', 'deeper' ),
		        )
		    );

		    vc_add_param(
		        'vc_column_inner',
		        array(
		            'type' => 'attach_image',
		            'heading' => esc_html__( 'Background Image', 'deeper' ),
		            'param_name' => 'halfbg_image',
		            'dependency' => array(
		                'element' => 'halfbg',
		                'value' => array( 'enable', 'image' ),
		            ),
		        )
		    );
		    
		    vc_add_param(
		        'vc_column_inner',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Position', 'deeper' ),
		            'param_name' => 'halfbg_position',
		            'dependency' => array(
		                'element' => 'halfbg',
		                'value' => array( 'enable' ),
		            ),
		            'value' => array(
		                esc_html__( 'Left Top', 'deeper' ) => 'left top',
		                esc_html__( 'Right Top', 'deeper' ) => 'right top',
		                esc_html__( 'Center Top', 'deeper' ) => 'center top',
		                esc_html__( 'Center Center', 'deeper' ) => 'center center',
		                esc_html__( 'Center Bottom', 'deeper' ) => 'center bottom',
		                esc_html__( 'Left Bottom', 'deeper' ) => 'left bottom',
		                esc_html__( 'Right Bottom', 'deeper' ) => 'right bottom',
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_column_inner',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Repeat', 'deeper' ),
		            'param_name' => 'halfbg_repeat',
		            'dependency' => array(
		                'element' => 'halfbg',
		                'value' => array( 'enable' ),
		            ),
		            'value' => array(
		                esc_html__( 'No Repeat', 'deeper' ) => 'no-repeat',
		                esc_html__( 'Repeat', 'deeper' ) => 'repeat',
		                esc_html__( 'Repeat X', 'deeper' ) => 'repeat-x',
		                esc_html__( 'Repeat Y', 'deeper' ) => 'repeat-y',
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_column_inner',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Size', 'deeper' ),
		            'param_name' => 'halfbg_size',
		            'dependency' => array(
		                'element' => 'halfbg',
		                'value' => array( 'enable' ),
		            ),
		            'value' => array(
		                esc_html__( 'Auto', 'deeper' ) => '',
		                esc_html__( 'Cover', 'deeper' ) => 'cover',
		            ),
		        )
		    );
		    //for Row
		    vc_add_param(
		        'vc_row',
		        array(
		            "type" => "dropdown",
		            "heading" => esc_html__( 'Custom Spacing Columns', 'deeper' ),
		            "param_name" => "column_spacing",
		            'value' => array(
		                'Disable' => '',
		                '0px' => '0px',
		                '1px' => '1px',
		                '5px' => '5px',
		                '10px' => '10px',
		                '20px' => '20px',
		                '30px' => '30px',
		                '40px' => '40px',
		                '50px' => '50px',
		                '60px' => '60px',
		                '70px' => '70px',
		                '80px' => '80px',
		                '90px' => '90px',
		                '100px' => '100px',
		            ),
		            'std' => '',
		            'description'   => esc_html__( 'Once this option is enabled, it will override the above "Columns gap" option.', 'deeper' ),
		        )
		    );

		    // Custom Background
		    vc_add_param(
		        'vc_row',
		        array(
		            "type" => "dropdown",
		            "heading" => esc_html__( 'Custom Background Size', 'deeper' ),
		            "param_name" => "bg_custom",
		            'value' => array(
		                'Disable' => '',
		                '1300px' => 'row-1300',
		                '1400px' => 'row-1400',
		                '1500px' => 'row-1500',
		                '1600px' => 'row-1600',
		                '1700px' => 'row-1700',
		                '1800px' => 'row-1800',
		                'Full Width' => 'row-full-width',
		                'Full Screen' => 'row-full-screen'
		            )
		        )
		    );

		    vc_add_param(
		        'vc_row',
		        array(
		            'type' => 'attach_image',
		            'heading' => esc_html__( 'Background Image', 'deeper' ),
		            'param_name' => 'bg_image',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );
		    
		    vc_add_param(
		        'vc_row',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Position', 'deeper' ),
		            'param_name' => 'bg_position',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => array(
		                esc_html__( 'Left Top', 'deeper' ) => 'left top',
		                esc_html__( 'Right Top', 'deeper' ) => 'right top',
		                esc_html__( 'Center Top', 'deeper' ) => 'center top',
		                esc_html__( 'Center Center', 'deeper' ) => 'center center',
		                esc_html__( 'Center Bottom', 'deeper' ) => 'center bottom',
		                esc_html__( 'Left Bottom', 'deeper' ) => 'left bottom',
		                esc_html__( 'Right Bottom', 'deeper' ) => 'right bottom',
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Repeat', 'deeper' ),
		            'param_name' => 'bg_repeat',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => array(
		                esc_html__( 'No Repeat', 'deeper' ) => 'no-repeat',
		                esc_html__( 'Repeat', 'deeper' ) => 'repeat',
		                esc_html__( 'Repeat X', 'deeper' ) => 'repeat-x',
		                esc_html__( 'Repeat Y', 'deeper' ) => 'repeat-y',
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Size', 'deeper' ),
		            'param_name' => 'bg_size',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => array(
		                esc_html__( 'Auto', 'deeper' ) => '',
		                esc_html__( 'Cover', 'deeper' ) => 'cover',
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row',
		        array(
		            "type" => "colorpicker",
		            "heading" => esc_html__( 'Background Color: Single Color', 'deeper' ),
		            "param_name" => "bg_color",
		            'value' => '',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row',
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( 'Background : Rounded', 'deeper' ),
		            "param_name" => "bg_rounded",
		            'value' => '',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		            'description' => esc_html__( 'Ex: 10px', 'deeper' ),
		        )
		    );
		    vc_add_param(
		        'vc_row',
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( 'Background : Box Shadow', 'deeper' ),
		            "param_name" => "bg_shadow",
		            'value' => '',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );

		    vc_add_param(
		        'vc_row',
		        array(
		        	'type' => 'deeper_heading',
		        	'text' => esc_html__( 'Gradient Background Color', 'deeper' ),
		        	'param_name' => 'two_color_bg',
		        	'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Gradient Direction', 'deeper' ),
		            'param_name' => 'bg_direction',
		            'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => array(
		                esc_html__( 'To Top', 'deeper' ) => 'to top',
		                esc_html__( 'To Bottom', 'deeper' ) => 'to bottom',
		                esc_html__( 'To Left', 'deeper' ) => 'to left',
		                esc_html__( 'To Right', 'deeper' ) => 'to right',
		            ),
		            'default' => 'to right'
		        )
		    );
		    vc_add_param(
		        'vc_row',
		        array(
		        	'type' => 'colorpicker',
		        	'heading' => esc_html__( '1st Color', 'deeper' ),
		        	'param_name' => 'bg_color_one',
		        	'value' => '',
		        	'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );

		    vc_add_param(
		        'vc_row',
		        array(
		        	'type' => 'colorpicker',
		        	'heading' => esc_html__( '2nd Color', 'deeper' ),
		        	'param_name' => 'bg_color_two',
		        	'value' => '',
		        	'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );

		    vc_add_param(
		        'vc_row',
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__( '1st Color Percent', 'deeper' ),
		        	'param_name' => 'bg_color_percent',
		        	'value' => '',
		        	'description' => esc_html__( 'Put a Percent to make a Background with 2 colors separate', 'depper' ),
		        	'dependency' => array(
		                'element' => 'bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );

		    // Row - Canvas Background
		    vc_add_param(
		        'vc_row',
		        array(
		            'type' => 'param_group',
		            'value' => '',
		            'param_name' => 'canvas',
		            'group' => esc_html__( 'Canvas Background', 'deeper' ),
		            'params' => array(
		            	array(
		                    'type' => 'dropdown',
		                    'heading' => esc_html__( 'Element', 'deeper' ),
		                    'param_name' => 'element',
		                    'value'      => array(
		                    	''		=> '',
		                    	'Image' => 'image', 
		                        'Morphin Shape' => 'morphin'      
		                    ),
		                    'std'       => '',
		                ),
		                array(
				            'type' => 'dropdown',
				            'heading' => esc_html__( 'Background Shape Morphin', 'deeper' ),
				            'param_name' => 'shape',
				            'value' => array(
				                'Wave' => 'shape-1',
				                'Blob 1' => 'shape-2',
				                'Blob 2' => 'shape-3',
				            ),
				            'std' => 'shape-1',
				            'dependency' => array( 'element' => 'element', 'value' => 'morphin' ),
				        ),
						array(
				            "type" => "colorpicker",
				            "heading" => esc_html__( 'Shape Color', 'deeper' ),
				            "param_name" => "shape_color",
				            'value' => '',
				            'dependency' => array( 'element' => 'element', 'value' => 'morphin' ),
				        ),
				        array(
		                    'type' => 'attach_image',
		                    'heading' => esc_html__( 'Inner Image', 'deeper' ),
		                    'param_name' => 'inner_image',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'morphin' ),
		                ),
		                // Image
		                array(
		                    'type' => 'attach_image',
		                    'heading' => esc_html__( 'Image', 'deeper' ),
		                    'param_name' => 'image',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'dropdown',
		                    'heading' => esc_html__( 'Hide on mobile?', 'deeper' ),
		                    'param_name' => 'mobile_hide',
		                    'value'      => array(
		                    	'No' => '',
		                        'Yes' => 'hide-on-mobile',       
		                    ),
		                    'std'       => '',
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__( 'Image Width', 'deeper' ),
		                    'param_name' => 'image_width',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Left', 'deeper'),
		                    'param_name' => 'image_post_left',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Top', 'deeper'),
		                    'param_name' => 'image_post_top',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Right', 'deeper'),
		                    'param_name' => 'image_post_right',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type' => 'textfield',
		                    'heading' => esc_html__('Element Position: Bottom', 'deeper'),
		                    'param_name' => 'image_post_bottom',
		                    'value' => '',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
		                    'type'       => 'dropdown',
		                    'heading'    => esc_html__( 'Element: Effect', 'deeper' ),
		                    'param_name' => 'image_effect',
		                    'value'      => array(
		                        'Parallax' 	=> 'style-1',
		                        'Zoom' 		=> 'style-2',
		                        'Moving'   	=> 'style-3',
		                        'Shake'    	=> 'style-4',
		                        'Bounce'    => 'style-5',
		                    ),
		                    'std'       => 'style-1',
		                    'dependency' => array( 'element' => 'element', 'value' => 'image' ),
		                ),
		                array(
				            'type' => 'textfield',
				            'heading' => esc_html__('Parallax Attributes', 'deeper'),
				            'param_name' => 'parallax_atts',
				            'description'   => esc_html__('Ex: "x": 10, "y": 20. Values Possible: x, y, z, rotateX, rotateY, rotateZ, scaleX, scaleY, scaleZ, scale.', 'deeper'),
				            'dependency' => array( 'element' => 'image_effect', 'value' => 'style-1' ),
				        ),
				        array(
				            'type' => 'textfield',
				            'heading' => esc_html__('Smoothness', 'deeper'),
				            'param_name' => 'smoothness',
				            'value' => '30',
				            'description'   => esc_html__('Slowdown the animation.', 'deeper'),
				            'dependency' => array( 'element' => 'image_effect', 'value' => 'style-1' ),
				        ),
						array(
							'type' => 'textfield',
							'heading' => esc_html__('Duration', 'deeper'),
							'param_name' => 'zoom_duration',
							'value' => '',
							'dependency' => array( 'element' => 'image_effect', 'value' => array( 'style-2' ) ),
						),
						array(
							'type' => 'textfield',
							'heading' => esc_html__('Delay', 'deeper'),
							'param_name' => 'zoom_delay',
							'value' => '',
							'dependency' => array( 'element' => 'image_effect', 'value' => array( 'style-2' ) ),
						),
						array(
							'type' => 'textfield',
							'heading' => esc_html__('Extra Class', 'deeper'),
							'param_name' => 'class',
							'value' => '',
						),
		            )                
		        )
		    );

		    // for Row Inner
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            "type" => "dropdown",
		            "heading" => esc_html__( 'Spacing Between Columns', 'deeper' ),
		            "param_name" => "column_inner_spacing",
		            'value' => array(
		                'Disable' => '',
		                '0px' => '0px',
		                '1px' => '1px',
		                '5px' => '5px',
		                '10px' => '10px',
		                '20px' => '20px',
		                '30px' => '30px',
		                '40px' => '40px',
		                '50px' => '50px',
		                '60px' => '60px',
		                '70px' => '70px',
		                '80px' => '80px',
		                '90px' => '90px',
		                '100px' => '100px',
		            ),
		            'description'   => esc_html__( 'Once this option is enabled, it will override the above "Columns gap" option.', 'deeper' ),
		        )
		    );

		    // Custom Background
		    vc_add_param(
		        'vc_row',
		        array(
		            "type" => "dropdown",
		            "heading" => esc_html__( 'Custom Spacing Columns', 'deeper' ),
		            "param_name" => "column_spacing",
		            'value' => array(
		                'Disable' => '',
		                '0px' => '0px',
		                '1px' => '1px',
		                '5px' => '5px',
		                '10px' => '10px',
		                '20px' => '20px',
		                '30px' => '30px',
		                '40px' => '40px',
		                '50px' => '50px',
		                '60px' => '60px',
		                '70px' => '70px',
		                '80px' => '80px',
		                '90px' => '90px',
		                '100px' => '100px',
		            ),
		            'std' => '',
		            'description'   => esc_html__( 'Once this option is enabled, it will override the above "Columns gap" option.', 'deeper' ),
		        )
		    );

		    // Custom Background
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            "type" => "dropdown",
		            "heading" => esc_html__( 'Custom Background Size', 'deeper' ),
		            "param_name" => "inner_bg_custom",
		            'value' => array(
		                'Disable' => '',
		                '1300px' => 'row-1300',
		                '1400px' => 'row-1400',
		                '1500px' => 'row-1500',
		                '1600px' => 'row-1600',
		                '1700px' => 'row-1700',
		                '1800px' => 'row-1800',
		                'Full Width' => 'row-full-width',
		                'Full Screen' => 'row-full-screen'
		            )
		        )
		    );

		    vc_add_param(
		        'vc_row_inner',
		        array(
		            'type' => 'attach_image',
		            'heading' => esc_html__( 'Background Image', 'deeper' ),
		            'param_name' => 'inner_bg_image',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );
		    
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Position', 'deeper' ),
		            'param_name' => 'inner_bg_position',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => array(
		                esc_html__( 'Left Top', 'deeper' ) => 'left top',
		                esc_html__( 'Right Top', 'deeper' ) => 'right top',
		                esc_html__( 'Center Top', 'deeper' ) => 'center top',
		                esc_html__( 'Center Center', 'deeper' ) => 'center center',
		                esc_html__( 'Center Bottom', 'deeper' ) => 'center bottom',
		                esc_html__( 'Left Bottom', 'deeper' ) => 'left bottom',
		                esc_html__( 'Right Bottom', 'deeper' ) => 'right bottom',
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Background Repeat', 'deeper' ),
		            'param_name' => 'inner_bg_repeat',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => array(
		                esc_html__( 'No Repeat', 'deeper' ) => 'no-repeat',
		                esc_html__( 'Repeat', 'deeper' ) => 'repeat',
		                esc_html__( 'Repeat X', 'deeper' ) => 'repeat-x',
		                esc_html__( 'Repeat Y', 'deeper' ) => 'repeat-y',
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            'type' => 'textfield',
		            'heading' => esc_html__( 'Background Size', 'deeper' ),
		            'param_name' => 'inner_bg_size',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => '',
		        )
		    );
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            "type" => "colorpicker",
		            "heading" => esc_html__( 'Background Color: Single Color', 'deeper' ),
		            "param_name" => "inner_bg_color",
		            'value' => '',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( 'Background : Rounded', 'deeper' ),
		            "param_name" => "inner_bg_rounded",
		            'value' => '',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		            'description' => esc_html__( 'Ex: 10px', 'deeper' ),
		        )
		    );
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            "type" => "textfield",
		            "heading" => esc_html__( 'Background : Box Shadow', 'deeper' ),
		            "param_name" => "inner_bg_shadow",
		            'value' => '',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );

		    vc_add_param(
		        'vc_row_inner',
		        array(
		        	'type' => 'deeper_heading',
		        	'text' => esc_html__( 'Gradient Background Color', 'deeper' ),
		        	'param_name' => 'inner_two_color_bg',
		        	'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );
		    vc_add_param(
		        'vc_row_inner',
		        array(
		            'type' => 'dropdown',
		            'heading' => esc_html__( 'Gradient Direction', 'deeper' ),
		            'param_name' => 'inner_bg_direction',
		            'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		            'value' => array(
		                esc_html__( 'To Top', 'deeper' ) => 'to top',
		                esc_html__( 'To Bottom', 'deeper' ) => 'to bottom',
		                esc_html__( 'To Left', 'deeper' ) => 'to left',
		                esc_html__( 'To Right', 'deeper' ) => 'to right',
		            ),
		            'default' => 'to right'
		        )
		    );
		    vc_add_param(
		        'vc_row_inner',
		        array(
		        	'type' => 'colorpicker',
		        	'heading' => esc_html__( '1st Color', 'deeper' ),
		        	'param_name' => 'inner_bg_color_one',
		        	'value' => '',
		        	'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );

		    vc_add_param(
		        'vc_row_inner',
		        array(
		        	'type' => 'colorpicker',
		        	'heading' => esc_html__( '2nd Color', 'deeper' ),
		        	'param_name' => 'inner_bg_color_two',
		        	'value' => '',
		        	'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );

		    vc_add_param(
		        'vc_row_inner',
		        array(
		        	'type' => 'textfield',
		        	'heading' => esc_html__( '1st Color Percent', 'deeper' ),
		        	'param_name' => 'inner_bg_color_percent',
		        	'value' => '',
		        	'description' => esc_html__( 'Put a Percent to make a Background with 2 colors separate', 'depper' ),
		        	'dependency' => array(
		                'element' => 'inner_bg_custom',
		                'not_empty' => true,
		            ),
		        )
		    );
		}
	}

	new Deeper_VC_Addons();
}
