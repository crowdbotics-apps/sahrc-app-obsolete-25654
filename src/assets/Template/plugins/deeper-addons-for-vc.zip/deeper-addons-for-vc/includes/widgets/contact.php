<?php
class Deeper_Widget_Contact extends WP_Widget {
    // Holds widget settings defaults, populated in constructor.
    protected $defaults;

    // Constructor
    function __construct() {
        $this->defaults = array(
            'title'                 => 'Contact',
            'desc'            => '',
            'address'            => '',
            'phone'            => '',
            'email'            => '',
            'web'            => '',
        );

        parent::__construct(
            'widget_contact',
            esc_html__( 'Contact Information', 'deeper' ),
            array(
                'classname'   => 'widget_contact',
                'description' => esc_html__( 'Display Contact Information', 'deeper' )
            )
        );
    }

    // Display widget
    function widget( $args, $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        extract( $instance );
        extract( $args );        

        echo $before_widget;

        if ( ! empty( $title ) ) { echo $before_title . $title . $after_title; }

        if ( $desc ) 
            printf( '<p class="desc" >%s</p>', 
                esc_html( $desc )
            );
        ?>

        <ul class="clearfix" style="<?php echo esc_attr( $wrap_css ); ?>">
            <?php
            
            if ( $address ) 
                printf( '<li><span>Address:</span><span>%s</span></li>', $address, esc_attr( $cls ) );

            if ( $address ) 
                printf( '<li class="phone" ><span>Address:</span><span>%s</span></li>', $address, esc_attr( $cls ) );

            if ( $phone ) 
                printf( '<li class="phone %5$s" style="%1$s"><span style="%2$s">Phone:</span><span style="%3$s">%4$s</span></li>', esc_attr( $css ), esc_attr( $content_title_css ), esc_attr( $text_css ), esc_html( $phone ), esc_attr( $cls ) );

            if ( $email ) 
                printf( '<li class="email %5$s" style="%1$s"><span style="%2$s">Email:</span><span style="%3$s">%4$s</span></li>', esc_attr( $css ), esc_attr( $content_title_css ), esc_attr( $text_css ), esc_html( $email ), esc_attr( $cls ) );

            if ( $web ) 
                printf( '<li class="web %5$s" style="%1$s"><span style="%2$s">Web:</span><span style="%3$s">%4$s</span></li>', esc_attr( $css ), esc_attr( $content_title_css ), esc_attr( $text_css ), esc_url( $web ), esc_attr( $cls ) );
            ?>
        </ul>

		<?php echo $after_widget;
    }

    // Update widget
    function update( $new_instance, $old_instance ) {
        $instance               = $old_instance;

        $instance['title']              = strip_tags( $new_instance['title'] );
        $instance['desc']              = strip_tags( $new_instance['desc'] );
        $instance['address']         =  $new_instance['address'];
        $instance['phone']         = strip_tags( $new_instance['phone'] );
        $instance['email']         = strip_tags( $new_instance['email'] );
        $instance['web']         = strip_tags( $new_instance['web'] );
        $instance['content_title_color']         = strip_tags( $new_instance['content_title_color'] );    
        $instance['text_color']         = strip_tags( $new_instance['text_color'] );
        $instance['text_left_pad']         = strip_tags( $new_instance['text_left_pad'] );       
        $instance['bottom_margin']         = strip_tags( $new_instance['bottom_margin'] );
        $instance['margin']         = strip_tags( $new_instance['margin'] );
        
        return $instance;
    }

    // Widget setting
    function form( $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );       
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'deeper' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'desc' ) ); ?>"><?php esc_html_e( 'Description:', 'deeper' ) ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'desc' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'desc' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['desc'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'address' ) ); ?>"><?php esc_html_e('Address:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'address' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'address' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['address'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>"><?php esc_html_e('Phone:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['phone'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php esc_html_e('Email:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['email'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'web' ) ); ?>"><?php esc_html_e('Website:', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'web' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'web' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['web'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'content_title_color' ) ); ?>"><?php esc_html_e('Icon Color (ex: #ffb600):', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'content_title_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_title_color' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['content_title_color'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'text_color' ) ); ?>"><?php esc_html_e('Text Color (ex: #e3e3e3):', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text_color' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['text_color'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'text_left_pad' ) ); ?>"><?php esc_html_e('Text: Left Padding (ex: 10px):', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text_left_pad' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text_left_pad' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['text_left_pad'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'bottom_margin' ) ); ?>"><?php esc_html_e('Item Bottom Margin (ex: 15px):', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'bottom_margin' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bottom_margin' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['bottom_margin'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'margin' ) ); ?>"><?php esc_html_e('Wrap Margin: (ex: 0px 50px 0px 0px)', 'deeper') ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'margin' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'margin' ) ); ?>" type="text" size="2" value="<?php echo esc_attr( $instance['margin'] ); ?>">
        </p>
    <?php
    }
}
add_action( 'widgets_init', 'register_deeper_contact' );

// Register widget
function register_deeper_contact() {
    register_widget( 'Deeper_Widget_Contact' );
}


