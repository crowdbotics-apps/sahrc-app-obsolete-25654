<?php
class Deeper_Recent_Posts extends WP_Widget {
    // Holds widget settings defaults in constructor.
    protected $defaults;

    // Constructor
    function __construct() {
        $this->defaults = array(
            'title'             => 'Recent Posts', 
            'category'          => '',
            'count'             => 3,
        );

        parent::__construct(
            'deeper_latest_posts',
            esc_html__( 'Recent Posts', 'deeper' ),
            array(
                'classname'   => 'widget_recent_posts',
                'description' => esc_html__( 'Display latest blog posts.', 'deeper' )
            )
        );
    }

    // Display widget
    function widget( $args, $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );
        extract( $instance );

        echo $args['before_widget'];

        if ( ! empty( $title ) ) { echo $args['before_title'] . $title . $args['after_title']; }

        $thumb_css = '';

        if ( $thumb_width )
            $thumb_css .= 'width:'. intval( $thumb_width ) .'px;';

        $query_args = array(
            'post_type' => 'post',
            'posts_per_page' => intval( $count )
        );

        if ( ! empty( $category ) ) {
            $query_args['tax_query'] = array(
                array(
                    'taxonomy' => 'category',
                    'terms'    => $category
                ),
            );             
        }

        $query = new WP_Query( $query_args ); ?>

        <ul>
            <?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); ?>
            <li class="clearfix">
                <div class="texts">
                    <div class="sidebar-custom-categories"><?php echo esc_url( the_category( '', get_the_ID() ) ); ?></div>
                    <?php
                    printf( '
                        <h3 class="post-title"><a href="%s">%s</a></h3>',
                        esc_url( get_the_permalink() ),
                        get_the_title()
                    ); ?>                     
                </div>
            </li>
            <?php endwhile; wp_reset_postdata(); endif; ?>        
        </ul>
        
		<?php echo $args['after_widget'];
    }

    // Update widget
    function update( $new_instance, $old_instance ) {
        $instance                       = $old_instance;
        $instance['title']              = strip_tags( $new_instance['title'] );
        $instance['count']              = intval( $new_instance['count'] );
        $instance['category']           = array_filter( $new_instance['category'] );

        return $instance;
    }

    // Widget setting
    function form( $instance ) {
        $instance = wp_parse_args( $instance, $this->defaults );       
        ?>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html( 'Title:', 'deeper' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php echo esc_html( 'Count:', 'deeper' ); ?></label>
            <input class="widefat" type="number" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" value="<?php echo esc_attr( $instance['count'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>"><?php echo esc_html( 'Select Category:', 'deeper' ); ?></label>
            <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'category' ) ); ?>[]">
                <option value=""<?php selected( empty( $instance['category'] ) ); ?>><?php echo esc_html( 'All', 'deeper' ); ?></option>
                <?php $categories = get_categories();
                foreach ( $categories as $category ) {
                    printf(
                        '<option value="%1$s" %4$s>%2$s (%3$s)</option>',
                        esc_attr( $category->term_id ),
                        $category->name,
                        $category->count,
                        ( in_array( $category->term_id, $instance['category'] ) ) ? 'selected="selected"' : '' );
                } ?>
            </select>
        </p>
    <?php
    }
}

// Register widget
function register_deeper_latest_posts() {
    register_widget( 'Deeper_Recent_Posts' );
}

add_action( 'widgets_init', 'register_deeper_latest_posts' );